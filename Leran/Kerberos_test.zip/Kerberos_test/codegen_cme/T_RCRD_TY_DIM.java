// ORM class for table 'cme.T_RCRD_TY_DIM'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Fri Jun 30 14:48:13 EDT 2017
// For connector: org.apache.sqoop.manager.GenericJdbcManager
package codegen_cme;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import com.cloudera.sqoop.lib.JdbcWritableBridge;
import com.cloudera.sqoop.lib.DelimiterSet;
import com.cloudera.sqoop.lib.FieldFormatter;
import com.cloudera.sqoop.lib.RecordParser;
import com.cloudera.sqoop.lib.BooleanParser;
import com.cloudera.sqoop.lib.BlobRef;
import com.cloudera.sqoop.lib.ClobRef;
import com.cloudera.sqoop.lib.LargeObjectLoader;
import com.cloudera.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class T_RCRD_TY_DIM extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("RCRD_TY_SRC_SYS_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RCRD_TY_SRC_SYS_ID = (String)value;
      }
    });
    setters.put("IS_ACTV_FLG", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        IS_ACTV_FLG = (Integer)value;
      }
    });
    setters.put("CREAT_BY_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CREAT_BY_ID = (String)value;
      }
    });
    setters.put("CREAT_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CREAT_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("RCRD_TY_DESC", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RCRD_TY_DESC = (String)value;
      }
    });
    setters.put("RCRD_TY_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RCRD_TY_NM = (String)value;
      }
    });
    setters.put("DEV_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        DEV_NM = (String)value;
      }
    });
    setters.put("SUBJ_TY_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        SUBJ_TY_NM = (String)value;
      }
    });
    setters.put("LST_MOD_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        LST_MOD_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("SYS_MOD_TS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        SYS_MOD_TS = (java.sql.Timestamp)value;
      }
    });
    setters.put("LST_MOD_BY_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        LST_MOD_BY_ID = (String)value;
      }
    });
    setters.put("LOAD_DT_TM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        LOAD_DT_TM = (java.sql.Timestamp)value;
      }
    });
    setters.put("FILE_LOAD_DY_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        FILE_LOAD_DY_DT = (String)value;
      }
    });
    setters.put("PKG_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        PKG_ID = (String)value;
      }
    });
    setters.put("DATAFLOW_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        DATAFLOW_ID = (String)value;
      }
    });
    setters.put("RCRD_STAT_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RCRD_STAT_CD = (String)value;
      }
    });
    setters.put("CREAT_TS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CREAT_TS = (java.sql.Timestamp)value;
      }
    });
    setters.put("LST_UPDT_TS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        LST_UPDT_TS = (java.sql.Timestamp)value;
      }
    });
    setters.put("LST_UPDT_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        LST_UPDT_ID = (String)value;
      }
    });
  }
  public T_RCRD_TY_DIM() {
    init0();
  }
  private String RCRD_TY_SRC_SYS_ID;
  public String get_RCRD_TY_SRC_SYS_ID() {
    return RCRD_TY_SRC_SYS_ID;
  }
  public void set_RCRD_TY_SRC_SYS_ID(String RCRD_TY_SRC_SYS_ID) {
    this.RCRD_TY_SRC_SYS_ID = RCRD_TY_SRC_SYS_ID;
  }
  public T_RCRD_TY_DIM with_RCRD_TY_SRC_SYS_ID(String RCRD_TY_SRC_SYS_ID) {
    this.RCRD_TY_SRC_SYS_ID = RCRD_TY_SRC_SYS_ID;
    return this;
  }
  private Integer IS_ACTV_FLG;
  public Integer get_IS_ACTV_FLG() {
    return IS_ACTV_FLG;
  }
  public void set_IS_ACTV_FLG(Integer IS_ACTV_FLG) {
    this.IS_ACTV_FLG = IS_ACTV_FLG;
  }
  public T_RCRD_TY_DIM with_IS_ACTV_FLG(Integer IS_ACTV_FLG) {
    this.IS_ACTV_FLG = IS_ACTV_FLG;
    return this;
  }
  private String CREAT_BY_ID;
  public String get_CREAT_BY_ID() {
    return CREAT_BY_ID;
  }
  public void set_CREAT_BY_ID(String CREAT_BY_ID) {
    this.CREAT_BY_ID = CREAT_BY_ID;
  }
  public T_RCRD_TY_DIM with_CREAT_BY_ID(String CREAT_BY_ID) {
    this.CREAT_BY_ID = CREAT_BY_ID;
    return this;
  }
  private java.sql.Timestamp CREAT_DT;
  public java.sql.Timestamp get_CREAT_DT() {
    return CREAT_DT;
  }
  public void set_CREAT_DT(java.sql.Timestamp CREAT_DT) {
    this.CREAT_DT = CREAT_DT;
  }
  public T_RCRD_TY_DIM with_CREAT_DT(java.sql.Timestamp CREAT_DT) {
    this.CREAT_DT = CREAT_DT;
    return this;
  }
  private String RCRD_TY_DESC;
  public String get_RCRD_TY_DESC() {
    return RCRD_TY_DESC;
  }
  public void set_RCRD_TY_DESC(String RCRD_TY_DESC) {
    this.RCRD_TY_DESC = RCRD_TY_DESC;
  }
  public T_RCRD_TY_DIM with_RCRD_TY_DESC(String RCRD_TY_DESC) {
    this.RCRD_TY_DESC = RCRD_TY_DESC;
    return this;
  }
  private String RCRD_TY_NM;
  public String get_RCRD_TY_NM() {
    return RCRD_TY_NM;
  }
  public void set_RCRD_TY_NM(String RCRD_TY_NM) {
    this.RCRD_TY_NM = RCRD_TY_NM;
  }
  public T_RCRD_TY_DIM with_RCRD_TY_NM(String RCRD_TY_NM) {
    this.RCRD_TY_NM = RCRD_TY_NM;
    return this;
  }
  private String DEV_NM;
  public String get_DEV_NM() {
    return DEV_NM;
  }
  public void set_DEV_NM(String DEV_NM) {
    this.DEV_NM = DEV_NM;
  }
  public T_RCRD_TY_DIM with_DEV_NM(String DEV_NM) {
    this.DEV_NM = DEV_NM;
    return this;
  }
  private String SUBJ_TY_NM;
  public String get_SUBJ_TY_NM() {
    return SUBJ_TY_NM;
  }
  public void set_SUBJ_TY_NM(String SUBJ_TY_NM) {
    this.SUBJ_TY_NM = SUBJ_TY_NM;
  }
  public T_RCRD_TY_DIM with_SUBJ_TY_NM(String SUBJ_TY_NM) {
    this.SUBJ_TY_NM = SUBJ_TY_NM;
    return this;
  }
  private java.sql.Timestamp LST_MOD_DT;
  public java.sql.Timestamp get_LST_MOD_DT() {
    return LST_MOD_DT;
  }
  public void set_LST_MOD_DT(java.sql.Timestamp LST_MOD_DT) {
    this.LST_MOD_DT = LST_MOD_DT;
  }
  public T_RCRD_TY_DIM with_LST_MOD_DT(java.sql.Timestamp LST_MOD_DT) {
    this.LST_MOD_DT = LST_MOD_DT;
    return this;
  }
  private java.sql.Timestamp SYS_MOD_TS;
  public java.sql.Timestamp get_SYS_MOD_TS() {
    return SYS_MOD_TS;
  }
  public void set_SYS_MOD_TS(java.sql.Timestamp SYS_MOD_TS) {
    this.SYS_MOD_TS = SYS_MOD_TS;
  }
  public T_RCRD_TY_DIM with_SYS_MOD_TS(java.sql.Timestamp SYS_MOD_TS) {
    this.SYS_MOD_TS = SYS_MOD_TS;
    return this;
  }
  private String LST_MOD_BY_ID;
  public String get_LST_MOD_BY_ID() {
    return LST_MOD_BY_ID;
  }
  public void set_LST_MOD_BY_ID(String LST_MOD_BY_ID) {
    this.LST_MOD_BY_ID = LST_MOD_BY_ID;
  }
  public T_RCRD_TY_DIM with_LST_MOD_BY_ID(String LST_MOD_BY_ID) {
    this.LST_MOD_BY_ID = LST_MOD_BY_ID;
    return this;
  }
  private java.sql.Timestamp LOAD_DT_TM;
  public java.sql.Timestamp get_LOAD_DT_TM() {
    return LOAD_DT_TM;
  }
  public void set_LOAD_DT_TM(java.sql.Timestamp LOAD_DT_TM) {
    this.LOAD_DT_TM = LOAD_DT_TM;
  }
  public T_RCRD_TY_DIM with_LOAD_DT_TM(java.sql.Timestamp LOAD_DT_TM) {
    this.LOAD_DT_TM = LOAD_DT_TM;
    return this;
  }
  private String FILE_LOAD_DY_DT;
  public String get_FILE_LOAD_DY_DT() {
    return FILE_LOAD_DY_DT;
  }
  public void set_FILE_LOAD_DY_DT(String FILE_LOAD_DY_DT) {
    this.FILE_LOAD_DY_DT = FILE_LOAD_DY_DT;
  }
  public T_RCRD_TY_DIM with_FILE_LOAD_DY_DT(String FILE_LOAD_DY_DT) {
    this.FILE_LOAD_DY_DT = FILE_LOAD_DY_DT;
    return this;
  }
  private String PKG_ID;
  public String get_PKG_ID() {
    return PKG_ID;
  }
  public void set_PKG_ID(String PKG_ID) {
    this.PKG_ID = PKG_ID;
  }
  public T_RCRD_TY_DIM with_PKG_ID(String PKG_ID) {
    this.PKG_ID = PKG_ID;
    return this;
  }
  private String DATAFLOW_ID;
  public String get_DATAFLOW_ID() {
    return DATAFLOW_ID;
  }
  public void set_DATAFLOW_ID(String DATAFLOW_ID) {
    this.DATAFLOW_ID = DATAFLOW_ID;
  }
  public T_RCRD_TY_DIM with_DATAFLOW_ID(String DATAFLOW_ID) {
    this.DATAFLOW_ID = DATAFLOW_ID;
    return this;
  }
  private String RCRD_STAT_CD;
  public String get_RCRD_STAT_CD() {
    return RCRD_STAT_CD;
  }
  public void set_RCRD_STAT_CD(String RCRD_STAT_CD) {
    this.RCRD_STAT_CD = RCRD_STAT_CD;
  }
  public T_RCRD_TY_DIM with_RCRD_STAT_CD(String RCRD_STAT_CD) {
    this.RCRD_STAT_CD = RCRD_STAT_CD;
    return this;
  }
  private java.sql.Timestamp CREAT_TS;
  public java.sql.Timestamp get_CREAT_TS() {
    return CREAT_TS;
  }
  public void set_CREAT_TS(java.sql.Timestamp CREAT_TS) {
    this.CREAT_TS = CREAT_TS;
  }
  public T_RCRD_TY_DIM with_CREAT_TS(java.sql.Timestamp CREAT_TS) {
    this.CREAT_TS = CREAT_TS;
    return this;
  }
  private java.sql.Timestamp LST_UPDT_TS;
  public java.sql.Timestamp get_LST_UPDT_TS() {
    return LST_UPDT_TS;
  }
  public void set_LST_UPDT_TS(java.sql.Timestamp LST_UPDT_TS) {
    this.LST_UPDT_TS = LST_UPDT_TS;
  }
  public T_RCRD_TY_DIM with_LST_UPDT_TS(java.sql.Timestamp LST_UPDT_TS) {
    this.LST_UPDT_TS = LST_UPDT_TS;
    return this;
  }
  private String LST_UPDT_ID;
  public String get_LST_UPDT_ID() {
    return LST_UPDT_ID;
  }
  public void set_LST_UPDT_ID(String LST_UPDT_ID) {
    this.LST_UPDT_ID = LST_UPDT_ID;
  }
  public T_RCRD_TY_DIM with_LST_UPDT_ID(String LST_UPDT_ID) {
    this.LST_UPDT_ID = LST_UPDT_ID;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof T_RCRD_TY_DIM)) {
      return false;
    }
    T_RCRD_TY_DIM that = (T_RCRD_TY_DIM) o;
    boolean equal = true;
    equal = equal && (this.RCRD_TY_SRC_SYS_ID == null ? that.RCRD_TY_SRC_SYS_ID == null : this.RCRD_TY_SRC_SYS_ID.equals(that.RCRD_TY_SRC_SYS_ID));
    equal = equal && (this.IS_ACTV_FLG == null ? that.IS_ACTV_FLG == null : this.IS_ACTV_FLG.equals(that.IS_ACTV_FLG));
    equal = equal && (this.CREAT_BY_ID == null ? that.CREAT_BY_ID == null : this.CREAT_BY_ID.equals(that.CREAT_BY_ID));
    equal = equal && (this.CREAT_DT == null ? that.CREAT_DT == null : this.CREAT_DT.equals(that.CREAT_DT));
    equal = equal && (this.RCRD_TY_DESC == null ? that.RCRD_TY_DESC == null : this.RCRD_TY_DESC.equals(that.RCRD_TY_DESC));
    equal = equal && (this.RCRD_TY_NM == null ? that.RCRD_TY_NM == null : this.RCRD_TY_NM.equals(that.RCRD_TY_NM));
    equal = equal && (this.DEV_NM == null ? that.DEV_NM == null : this.DEV_NM.equals(that.DEV_NM));
    equal = equal && (this.SUBJ_TY_NM == null ? that.SUBJ_TY_NM == null : this.SUBJ_TY_NM.equals(that.SUBJ_TY_NM));
    equal = equal && (this.LST_MOD_DT == null ? that.LST_MOD_DT == null : this.LST_MOD_DT.equals(that.LST_MOD_DT));
    equal = equal && (this.SYS_MOD_TS == null ? that.SYS_MOD_TS == null : this.SYS_MOD_TS.equals(that.SYS_MOD_TS));
    equal = equal && (this.LST_MOD_BY_ID == null ? that.LST_MOD_BY_ID == null : this.LST_MOD_BY_ID.equals(that.LST_MOD_BY_ID));
    equal = equal && (this.LOAD_DT_TM == null ? that.LOAD_DT_TM == null : this.LOAD_DT_TM.equals(that.LOAD_DT_TM));
    equal = equal && (this.FILE_LOAD_DY_DT == null ? that.FILE_LOAD_DY_DT == null : this.FILE_LOAD_DY_DT.equals(that.FILE_LOAD_DY_DT));
    equal = equal && (this.PKG_ID == null ? that.PKG_ID == null : this.PKG_ID.equals(that.PKG_ID));
    equal = equal && (this.DATAFLOW_ID == null ? that.DATAFLOW_ID == null : this.DATAFLOW_ID.equals(that.DATAFLOW_ID));
    equal = equal && (this.RCRD_STAT_CD == null ? that.RCRD_STAT_CD == null : this.RCRD_STAT_CD.equals(that.RCRD_STAT_CD));
    equal = equal && (this.CREAT_TS == null ? that.CREAT_TS == null : this.CREAT_TS.equals(that.CREAT_TS));
    equal = equal && (this.LST_UPDT_TS == null ? that.LST_UPDT_TS == null : this.LST_UPDT_TS.equals(that.LST_UPDT_TS));
    equal = equal && (this.LST_UPDT_ID == null ? that.LST_UPDT_ID == null : this.LST_UPDT_ID.equals(that.LST_UPDT_ID));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof T_RCRD_TY_DIM)) {
      return false;
    }
    T_RCRD_TY_DIM that = (T_RCRD_TY_DIM) o;
    boolean equal = true;
    equal = equal && (this.RCRD_TY_SRC_SYS_ID == null ? that.RCRD_TY_SRC_SYS_ID == null : this.RCRD_TY_SRC_SYS_ID.equals(that.RCRD_TY_SRC_SYS_ID));
    equal = equal && (this.IS_ACTV_FLG == null ? that.IS_ACTV_FLG == null : this.IS_ACTV_FLG.equals(that.IS_ACTV_FLG));
    equal = equal && (this.CREAT_BY_ID == null ? that.CREAT_BY_ID == null : this.CREAT_BY_ID.equals(that.CREAT_BY_ID));
    equal = equal && (this.CREAT_DT == null ? that.CREAT_DT == null : this.CREAT_DT.equals(that.CREAT_DT));
    equal = equal && (this.RCRD_TY_DESC == null ? that.RCRD_TY_DESC == null : this.RCRD_TY_DESC.equals(that.RCRD_TY_DESC));
    equal = equal && (this.RCRD_TY_NM == null ? that.RCRD_TY_NM == null : this.RCRD_TY_NM.equals(that.RCRD_TY_NM));
    equal = equal && (this.DEV_NM == null ? that.DEV_NM == null : this.DEV_NM.equals(that.DEV_NM));
    equal = equal && (this.SUBJ_TY_NM == null ? that.SUBJ_TY_NM == null : this.SUBJ_TY_NM.equals(that.SUBJ_TY_NM));
    equal = equal && (this.LST_MOD_DT == null ? that.LST_MOD_DT == null : this.LST_MOD_DT.equals(that.LST_MOD_DT));
    equal = equal && (this.SYS_MOD_TS == null ? that.SYS_MOD_TS == null : this.SYS_MOD_TS.equals(that.SYS_MOD_TS));
    equal = equal && (this.LST_MOD_BY_ID == null ? that.LST_MOD_BY_ID == null : this.LST_MOD_BY_ID.equals(that.LST_MOD_BY_ID));
    equal = equal && (this.LOAD_DT_TM == null ? that.LOAD_DT_TM == null : this.LOAD_DT_TM.equals(that.LOAD_DT_TM));
    equal = equal && (this.FILE_LOAD_DY_DT == null ? that.FILE_LOAD_DY_DT == null : this.FILE_LOAD_DY_DT.equals(that.FILE_LOAD_DY_DT));
    equal = equal && (this.PKG_ID == null ? that.PKG_ID == null : this.PKG_ID.equals(that.PKG_ID));
    equal = equal && (this.DATAFLOW_ID == null ? that.DATAFLOW_ID == null : this.DATAFLOW_ID.equals(that.DATAFLOW_ID));
    equal = equal && (this.RCRD_STAT_CD == null ? that.RCRD_STAT_CD == null : this.RCRD_STAT_CD.equals(that.RCRD_STAT_CD));
    equal = equal && (this.CREAT_TS == null ? that.CREAT_TS == null : this.CREAT_TS.equals(that.CREAT_TS));
    equal = equal && (this.LST_UPDT_TS == null ? that.LST_UPDT_TS == null : this.LST_UPDT_TS.equals(that.LST_UPDT_TS));
    equal = equal && (this.LST_UPDT_ID == null ? that.LST_UPDT_ID == null : this.LST_UPDT_ID.equals(that.LST_UPDT_ID));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.RCRD_TY_SRC_SYS_ID = JdbcWritableBridge.readString(1, __dbResults);
    this.IS_ACTV_FLG = JdbcWritableBridge.readInteger(2, __dbResults);
    this.CREAT_BY_ID = JdbcWritableBridge.readString(3, __dbResults);
    this.CREAT_DT = JdbcWritableBridge.readTimestamp(4, __dbResults);
    this.RCRD_TY_DESC = JdbcWritableBridge.readString(5, __dbResults);
    this.RCRD_TY_NM = JdbcWritableBridge.readString(6, __dbResults);
    this.DEV_NM = JdbcWritableBridge.readString(7, __dbResults);
    this.SUBJ_TY_NM = JdbcWritableBridge.readString(8, __dbResults);
    this.LST_MOD_DT = JdbcWritableBridge.readTimestamp(9, __dbResults);
    this.SYS_MOD_TS = JdbcWritableBridge.readTimestamp(10, __dbResults);
    this.LST_MOD_BY_ID = JdbcWritableBridge.readString(11, __dbResults);
    this.LOAD_DT_TM = JdbcWritableBridge.readTimestamp(12, __dbResults);
    this.FILE_LOAD_DY_DT = JdbcWritableBridge.readString(13, __dbResults);
    this.PKG_ID = JdbcWritableBridge.readString(14, __dbResults);
    this.DATAFLOW_ID = JdbcWritableBridge.readString(15, __dbResults);
    this.RCRD_STAT_CD = JdbcWritableBridge.readString(16, __dbResults);
    this.CREAT_TS = JdbcWritableBridge.readTimestamp(17, __dbResults);
    this.LST_UPDT_TS = JdbcWritableBridge.readTimestamp(18, __dbResults);
    this.LST_UPDT_ID = JdbcWritableBridge.readString(19, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.RCRD_TY_SRC_SYS_ID = JdbcWritableBridge.readString(1, __dbResults);
    this.IS_ACTV_FLG = JdbcWritableBridge.readInteger(2, __dbResults);
    this.CREAT_BY_ID = JdbcWritableBridge.readString(3, __dbResults);
    this.CREAT_DT = JdbcWritableBridge.readTimestamp(4, __dbResults);
    this.RCRD_TY_DESC = JdbcWritableBridge.readString(5, __dbResults);
    this.RCRD_TY_NM = JdbcWritableBridge.readString(6, __dbResults);
    this.DEV_NM = JdbcWritableBridge.readString(7, __dbResults);
    this.SUBJ_TY_NM = JdbcWritableBridge.readString(8, __dbResults);
    this.LST_MOD_DT = JdbcWritableBridge.readTimestamp(9, __dbResults);
    this.SYS_MOD_TS = JdbcWritableBridge.readTimestamp(10, __dbResults);
    this.LST_MOD_BY_ID = JdbcWritableBridge.readString(11, __dbResults);
    this.LOAD_DT_TM = JdbcWritableBridge.readTimestamp(12, __dbResults);
    this.FILE_LOAD_DY_DT = JdbcWritableBridge.readString(13, __dbResults);
    this.PKG_ID = JdbcWritableBridge.readString(14, __dbResults);
    this.DATAFLOW_ID = JdbcWritableBridge.readString(15, __dbResults);
    this.RCRD_STAT_CD = JdbcWritableBridge.readString(16, __dbResults);
    this.CREAT_TS = JdbcWritableBridge.readTimestamp(17, __dbResults);
    this.LST_UPDT_TS = JdbcWritableBridge.readTimestamp(18, __dbResults);
    this.LST_UPDT_ID = JdbcWritableBridge.readString(19, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(RCRD_TY_SRC_SYS_ID, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeInteger(IS_ACTV_FLG, 2 + __off, 5, __dbStmt);
    JdbcWritableBridge.writeString(CREAT_BY_ID, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(CREAT_DT, 4 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(RCRD_TY_DESC, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCRD_TY_NM, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DEV_NM, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SUBJ_TY_NM, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LST_MOD_DT, 9 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SYS_MOD_TS, 10 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(LST_MOD_BY_ID, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LOAD_DT_TM, 12 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(FILE_LOAD_DY_DT, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PKG_ID, 14 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DATAFLOW_ID, 15 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCRD_STAT_CD, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(CREAT_TS, 17 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LST_UPDT_TS, 18 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(LST_UPDT_ID, 19 + __off, 1, __dbStmt);
    return 19;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(RCRD_TY_SRC_SYS_ID, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeInteger(IS_ACTV_FLG, 2 + __off, 5, __dbStmt);
    JdbcWritableBridge.writeString(CREAT_BY_ID, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(CREAT_DT, 4 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(RCRD_TY_DESC, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCRD_TY_NM, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DEV_NM, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SUBJ_TY_NM, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LST_MOD_DT, 9 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SYS_MOD_TS, 10 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(LST_MOD_BY_ID, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LOAD_DT_TM, 12 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(FILE_LOAD_DY_DT, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PKG_ID, 14 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DATAFLOW_ID, 15 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCRD_STAT_CD, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(CREAT_TS, 17 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LST_UPDT_TS, 18 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(LST_UPDT_ID, 19 + __off, 1, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.RCRD_TY_SRC_SYS_ID = null;
    } else {
    this.RCRD_TY_SRC_SYS_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.IS_ACTV_FLG = null;
    } else {
    this.IS_ACTV_FLG = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.CREAT_BY_ID = null;
    } else {
    this.CREAT_BY_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CREAT_DT = null;
    } else {
    this.CREAT_DT = new Timestamp(__dataIn.readLong());
    this.CREAT_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RCRD_TY_DESC = null;
    } else {
    this.RCRD_TY_DESC = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RCRD_TY_NM = null;
    } else {
    this.RCRD_TY_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DEV_NM = null;
    } else {
    this.DEV_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SUBJ_TY_NM = null;
    } else {
    this.SUBJ_TY_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LST_MOD_DT = null;
    } else {
    this.LST_MOD_DT = new Timestamp(__dataIn.readLong());
    this.LST_MOD_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.SYS_MOD_TS = null;
    } else {
    this.SYS_MOD_TS = new Timestamp(__dataIn.readLong());
    this.SYS_MOD_TS.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.LST_MOD_BY_ID = null;
    } else {
    this.LST_MOD_BY_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LOAD_DT_TM = null;
    } else {
    this.LOAD_DT_TM = new Timestamp(__dataIn.readLong());
    this.LOAD_DT_TM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.FILE_LOAD_DY_DT = null;
    } else {
    this.FILE_LOAD_DY_DT = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PKG_ID = null;
    } else {
    this.PKG_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DATAFLOW_ID = null;
    } else {
    this.DATAFLOW_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RCRD_STAT_CD = null;
    } else {
    this.RCRD_STAT_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CREAT_TS = null;
    } else {
    this.CREAT_TS = new Timestamp(__dataIn.readLong());
    this.CREAT_TS.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.LST_UPDT_TS = null;
    } else {
    this.LST_UPDT_TS = new Timestamp(__dataIn.readLong());
    this.LST_UPDT_TS.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.LST_UPDT_ID = null;
    } else {
    this.LST_UPDT_ID = Text.readString(__dataIn);
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.RCRD_TY_SRC_SYS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRD_TY_SRC_SYS_ID);
    }
    if (null == this.IS_ACTV_FLG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.IS_ACTV_FLG);
    }
    if (null == this.CREAT_BY_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CREAT_BY_ID);
    }
    if (null == this.CREAT_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.CREAT_DT.getTime());
    __dataOut.writeInt(this.CREAT_DT.getNanos());
    }
    if (null == this.RCRD_TY_DESC) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRD_TY_DESC);
    }
    if (null == this.RCRD_TY_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRD_TY_NM);
    }
    if (null == this.DEV_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DEV_NM);
    }
    if (null == this.SUBJ_TY_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SUBJ_TY_NM);
    }
    if (null == this.LST_MOD_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LST_MOD_DT.getTime());
    __dataOut.writeInt(this.LST_MOD_DT.getNanos());
    }
    if (null == this.SYS_MOD_TS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SYS_MOD_TS.getTime());
    __dataOut.writeInt(this.SYS_MOD_TS.getNanos());
    }
    if (null == this.LST_MOD_BY_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LST_MOD_BY_ID);
    }
    if (null == this.LOAD_DT_TM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LOAD_DT_TM.getTime());
    __dataOut.writeInt(this.LOAD_DT_TM.getNanos());
    }
    if (null == this.FILE_LOAD_DY_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FILE_LOAD_DY_DT);
    }
    if (null == this.PKG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PKG_ID);
    }
    if (null == this.DATAFLOW_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DATAFLOW_ID);
    }
    if (null == this.RCRD_STAT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRD_STAT_CD);
    }
    if (null == this.CREAT_TS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.CREAT_TS.getTime());
    __dataOut.writeInt(this.CREAT_TS.getNanos());
    }
    if (null == this.LST_UPDT_TS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LST_UPDT_TS.getTime());
    __dataOut.writeInt(this.LST_UPDT_TS.getNanos());
    }
    if (null == this.LST_UPDT_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LST_UPDT_ID);
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.RCRD_TY_SRC_SYS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRD_TY_SRC_SYS_ID);
    }
    if (null == this.IS_ACTV_FLG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.IS_ACTV_FLG);
    }
    if (null == this.CREAT_BY_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CREAT_BY_ID);
    }
    if (null == this.CREAT_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.CREAT_DT.getTime());
    __dataOut.writeInt(this.CREAT_DT.getNanos());
    }
    if (null == this.RCRD_TY_DESC) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRD_TY_DESC);
    }
    if (null == this.RCRD_TY_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRD_TY_NM);
    }
    if (null == this.DEV_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DEV_NM);
    }
    if (null == this.SUBJ_TY_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SUBJ_TY_NM);
    }
    if (null == this.LST_MOD_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LST_MOD_DT.getTime());
    __dataOut.writeInt(this.LST_MOD_DT.getNanos());
    }
    if (null == this.SYS_MOD_TS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SYS_MOD_TS.getTime());
    __dataOut.writeInt(this.SYS_MOD_TS.getNanos());
    }
    if (null == this.LST_MOD_BY_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LST_MOD_BY_ID);
    }
    if (null == this.LOAD_DT_TM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LOAD_DT_TM.getTime());
    __dataOut.writeInt(this.LOAD_DT_TM.getNanos());
    }
    if (null == this.FILE_LOAD_DY_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FILE_LOAD_DY_DT);
    }
    if (null == this.PKG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PKG_ID);
    }
    if (null == this.DATAFLOW_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DATAFLOW_ID);
    }
    if (null == this.RCRD_STAT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRD_STAT_CD);
    }
    if (null == this.CREAT_TS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.CREAT_TS.getTime());
    __dataOut.writeInt(this.CREAT_TS.getNanos());
    }
    if (null == this.LST_UPDT_TS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LST_UPDT_TS.getTime());
    __dataOut.writeInt(this.LST_UPDT_TS.getNanos());
    }
    if (null == this.LST_UPDT_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LST_UPDT_ID);
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(RCRD_TY_SRC_SYS_ID==null?"null":RCRD_TY_SRC_SYS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(IS_ACTV_FLG==null?"null":"" + IS_ACTV_FLG, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CREAT_BY_ID==null?"null":CREAT_BY_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CREAT_DT==null?"null":"" + CREAT_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRD_TY_DESC==null?"null":RCRD_TY_DESC, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRD_TY_NM==null?"null":RCRD_TY_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DEV_NM==null?"null":DEV_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SUBJ_TY_NM==null?"null":SUBJ_TY_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LST_MOD_DT==null?"null":"" + LST_MOD_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_MOD_TS==null?"null":"" + SYS_MOD_TS, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LST_MOD_BY_ID==null?"null":LST_MOD_BY_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LOAD_DT_TM==null?"null":"" + LOAD_DT_TM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FILE_LOAD_DY_DT==null?"null":FILE_LOAD_DY_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PKG_ID==null?"null":PKG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DATAFLOW_ID==null?"null":DATAFLOW_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRD_STAT_CD==null?"null":RCRD_STAT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CREAT_TS==null?"null":"" + CREAT_TS, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LST_UPDT_TS==null?"null":"" + LST_UPDT_TS, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LST_UPDT_ID==null?"null":LST_UPDT_ID, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(RCRD_TY_SRC_SYS_ID==null?"null":RCRD_TY_SRC_SYS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(IS_ACTV_FLG==null?"null":"" + IS_ACTV_FLG, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CREAT_BY_ID==null?"null":CREAT_BY_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CREAT_DT==null?"null":"" + CREAT_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRD_TY_DESC==null?"null":RCRD_TY_DESC, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRD_TY_NM==null?"null":RCRD_TY_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DEV_NM==null?"null":DEV_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SUBJ_TY_NM==null?"null":SUBJ_TY_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LST_MOD_DT==null?"null":"" + LST_MOD_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_MOD_TS==null?"null":"" + SYS_MOD_TS, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LST_MOD_BY_ID==null?"null":LST_MOD_BY_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LOAD_DT_TM==null?"null":"" + LOAD_DT_TM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FILE_LOAD_DY_DT==null?"null":FILE_LOAD_DY_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PKG_ID==null?"null":PKG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DATAFLOW_ID==null?"null":DATAFLOW_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRD_STAT_CD==null?"null":RCRD_STAT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CREAT_TS==null?"null":"" + CREAT_TS, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LST_UPDT_TS==null?"null":"" + LST_UPDT_TS, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LST_UPDT_ID==null?"null":LST_UPDT_ID, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RCRD_TY_SRC_SYS_ID = null; } else {
      this.RCRD_TY_SRC_SYS_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.IS_ACTV_FLG = null; } else {
      this.IS_ACTV_FLG = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CREAT_BY_ID = null; } else {
      this.CREAT_BY_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CREAT_DT = null; } else {
      this.CREAT_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RCRD_TY_DESC = null; } else {
      this.RCRD_TY_DESC = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RCRD_TY_NM = null; } else {
      this.RCRD_TY_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DEV_NM = null; } else {
      this.DEV_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.SUBJ_TY_NM = null; } else {
      this.SUBJ_TY_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LST_MOD_DT = null; } else {
      this.LST_MOD_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SYS_MOD_TS = null; } else {
      this.SYS_MOD_TS = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LST_MOD_BY_ID = null; } else {
      this.LST_MOD_BY_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LOAD_DT_TM = null; } else {
      this.LOAD_DT_TM = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.FILE_LOAD_DY_DT = null; } else {
      this.FILE_LOAD_DY_DT = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.PKG_ID = null; } else {
      this.PKG_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DATAFLOW_ID = null; } else {
      this.DATAFLOW_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RCRD_STAT_CD = null; } else {
      this.RCRD_STAT_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CREAT_TS = null; } else {
      this.CREAT_TS = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LST_UPDT_TS = null; } else {
      this.LST_UPDT_TS = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LST_UPDT_ID = null; } else {
      this.LST_UPDT_ID = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RCRD_TY_SRC_SYS_ID = null; } else {
      this.RCRD_TY_SRC_SYS_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.IS_ACTV_FLG = null; } else {
      this.IS_ACTV_FLG = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CREAT_BY_ID = null; } else {
      this.CREAT_BY_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CREAT_DT = null; } else {
      this.CREAT_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RCRD_TY_DESC = null; } else {
      this.RCRD_TY_DESC = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RCRD_TY_NM = null; } else {
      this.RCRD_TY_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DEV_NM = null; } else {
      this.DEV_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.SUBJ_TY_NM = null; } else {
      this.SUBJ_TY_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LST_MOD_DT = null; } else {
      this.LST_MOD_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SYS_MOD_TS = null; } else {
      this.SYS_MOD_TS = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LST_MOD_BY_ID = null; } else {
      this.LST_MOD_BY_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LOAD_DT_TM = null; } else {
      this.LOAD_DT_TM = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.FILE_LOAD_DY_DT = null; } else {
      this.FILE_LOAD_DY_DT = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.PKG_ID = null; } else {
      this.PKG_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DATAFLOW_ID = null; } else {
      this.DATAFLOW_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RCRD_STAT_CD = null; } else {
      this.RCRD_STAT_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CREAT_TS = null; } else {
      this.CREAT_TS = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LST_UPDT_TS = null; } else {
      this.LST_UPDT_TS = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LST_UPDT_ID = null; } else {
      this.LST_UPDT_ID = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    T_RCRD_TY_DIM o = (T_RCRD_TY_DIM) super.clone();
    o.CREAT_DT = (o.CREAT_DT != null) ? (java.sql.Timestamp) o.CREAT_DT.clone() : null;
    o.LST_MOD_DT = (o.LST_MOD_DT != null) ? (java.sql.Timestamp) o.LST_MOD_DT.clone() : null;
    o.SYS_MOD_TS = (o.SYS_MOD_TS != null) ? (java.sql.Timestamp) o.SYS_MOD_TS.clone() : null;
    o.LOAD_DT_TM = (o.LOAD_DT_TM != null) ? (java.sql.Timestamp) o.LOAD_DT_TM.clone() : null;
    o.CREAT_TS = (o.CREAT_TS != null) ? (java.sql.Timestamp) o.CREAT_TS.clone() : null;
    o.LST_UPDT_TS = (o.LST_UPDT_TS != null) ? (java.sql.Timestamp) o.LST_UPDT_TS.clone() : null;
    return o;
  }

  public void clone0(T_RCRD_TY_DIM o) throws CloneNotSupportedException {
    o.CREAT_DT = (o.CREAT_DT != null) ? (java.sql.Timestamp) o.CREAT_DT.clone() : null;
    o.LST_MOD_DT = (o.LST_MOD_DT != null) ? (java.sql.Timestamp) o.LST_MOD_DT.clone() : null;
    o.SYS_MOD_TS = (o.SYS_MOD_TS != null) ? (java.sql.Timestamp) o.SYS_MOD_TS.clone() : null;
    o.LOAD_DT_TM = (o.LOAD_DT_TM != null) ? (java.sql.Timestamp) o.LOAD_DT_TM.clone() : null;
    o.CREAT_TS = (o.CREAT_TS != null) ? (java.sql.Timestamp) o.CREAT_TS.clone() : null;
    o.LST_UPDT_TS = (o.LST_UPDT_TS != null) ? (java.sql.Timestamp) o.LST_UPDT_TS.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("RCRD_TY_SRC_SYS_ID", this.RCRD_TY_SRC_SYS_ID);
    __sqoop$field_map.put("IS_ACTV_FLG", this.IS_ACTV_FLG);
    __sqoop$field_map.put("CREAT_BY_ID", this.CREAT_BY_ID);
    __sqoop$field_map.put("CREAT_DT", this.CREAT_DT);
    __sqoop$field_map.put("RCRD_TY_DESC", this.RCRD_TY_DESC);
    __sqoop$field_map.put("RCRD_TY_NM", this.RCRD_TY_NM);
    __sqoop$field_map.put("DEV_NM", this.DEV_NM);
    __sqoop$field_map.put("SUBJ_TY_NM", this.SUBJ_TY_NM);
    __sqoop$field_map.put("LST_MOD_DT", this.LST_MOD_DT);
    __sqoop$field_map.put("SYS_MOD_TS", this.SYS_MOD_TS);
    __sqoop$field_map.put("LST_MOD_BY_ID", this.LST_MOD_BY_ID);
    __sqoop$field_map.put("LOAD_DT_TM", this.LOAD_DT_TM);
    __sqoop$field_map.put("FILE_LOAD_DY_DT", this.FILE_LOAD_DY_DT);
    __sqoop$field_map.put("PKG_ID", this.PKG_ID);
    __sqoop$field_map.put("DATAFLOW_ID", this.DATAFLOW_ID);
    __sqoop$field_map.put("RCRD_STAT_CD", this.RCRD_STAT_CD);
    __sqoop$field_map.put("CREAT_TS", this.CREAT_TS);
    __sqoop$field_map.put("LST_UPDT_TS", this.LST_UPDT_TS);
    __sqoop$field_map.put("LST_UPDT_ID", this.LST_UPDT_ID);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("RCRD_TY_SRC_SYS_ID", this.RCRD_TY_SRC_SYS_ID);
    __sqoop$field_map.put("IS_ACTV_FLG", this.IS_ACTV_FLG);
    __sqoop$field_map.put("CREAT_BY_ID", this.CREAT_BY_ID);
    __sqoop$field_map.put("CREAT_DT", this.CREAT_DT);
    __sqoop$field_map.put("RCRD_TY_DESC", this.RCRD_TY_DESC);
    __sqoop$field_map.put("RCRD_TY_NM", this.RCRD_TY_NM);
    __sqoop$field_map.put("DEV_NM", this.DEV_NM);
    __sqoop$field_map.put("SUBJ_TY_NM", this.SUBJ_TY_NM);
    __sqoop$field_map.put("LST_MOD_DT", this.LST_MOD_DT);
    __sqoop$field_map.put("SYS_MOD_TS", this.SYS_MOD_TS);
    __sqoop$field_map.put("LST_MOD_BY_ID", this.LST_MOD_BY_ID);
    __sqoop$field_map.put("LOAD_DT_TM", this.LOAD_DT_TM);
    __sqoop$field_map.put("FILE_LOAD_DY_DT", this.FILE_LOAD_DY_DT);
    __sqoop$field_map.put("PKG_ID", this.PKG_ID);
    __sqoop$field_map.put("DATAFLOW_ID", this.DATAFLOW_ID);
    __sqoop$field_map.put("RCRD_STAT_CD", this.RCRD_STAT_CD);
    __sqoop$field_map.put("CREAT_TS", this.CREAT_TS);
    __sqoop$field_map.put("LST_UPDT_TS", this.LST_UPDT_TS);
    __sqoop$field_map.put("LST_UPDT_ID", this.LST_UPDT_ID);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}

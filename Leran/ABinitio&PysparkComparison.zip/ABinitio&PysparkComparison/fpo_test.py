from pyspark import SparkConf, SparkContext,HiveContext
from pyspark.sql import SQLContext
import re
from pyspark.sql.functions import upper

pattern=re.compile(r'W&IM%')
 
def firstTansformation(x):
   if x in ['Commercial', 'Commercial Real Estate']:
    SFReferral='wholesale'
   elif x in ['Mortgage']:
    SFReferral='mortgage'
   elif x in ['Premier Banking']:
    SFReferral='Premier'
   elif  x in ['Endowment & Foundation']:
    SFReferral='PWM'
   elif pattern.match(x):
    SFReferral='PWM'
   elif x in ['CIB', 'EIS', 'Finance', 'Human Resources','Marketing', 'Marketing/Stoli', 'Middle Market','Other', 'Treasure Management', 'Treasury Management']:
    SFReferral='Self-Sourced'
   elif x is None :
    SFReferral='Self-Sourced'
   else:
    SFReferral=x
   if x in ('Business_Banking', 'Commercial'):
    WebReferral='WholeSale'
   elif x in ('LO', 'LM', 'RS'): 
    WebReferral='Mortgage'
   elif x in ('Branch', 'SAW'):
    WebReferral='Branch'
   elif x in ('PWM', 'PWM_Mgmt'):
    WebReferral='PWM'
   elif x is None :
    WebReferral='Self-Sourced'
   else:
     WebReferral=x
   if SFReferral!='Self-Sourced':
     refr_lob=SFReferral 
   elif (SFReferral!='Self-Sourced') and (WebReferral in ['Self-Sourced']):
     refr_lob=WebReferral
   else:
     refr_lob='Self-Sourced'
   return refr_lob


sc = SparkContext()
sqlContext = HiveContext(sc)
sqlContext.sql("use eir_sas_shared")

df_fpo_dt_relat=sqlContext.sql("select relat_id,relat_nbr,acct_mnge_id,lte_actv_dt,spcl_unt_cd,curr_flg,(from_unixtime(floor(lte_actv_dt/1000),'MM/dd/yyyy') ) as lte_date from eir_sas_shared.fpo_dt_relat_parq where curr_flg='Y'")
df_fpo_bihierflat=sqlContext.sql("select employeeid,actv_flg,employeename,teamid,sublob,group,region,teamname,jobgroupdesc from eir_sas_shared.fpo_bihierflat_parq where actv_flg ='Y'")
df_fpo_ft_relat_dly=sqlContext.sql("select dep_bal_amt,curr_mkt_val_amt,ln_bal_amt,hld_away_asset_amt,annl_ytd_revn_amt from fpo_ft_relat_dly_parq")
df_fpo_rt_insite_team=sqlContext.sql("select team_id,team_lead_id from fpo_rt_insite_team_parq")
df_fpo_t_web_refr_dtl_mth=sqlContext.sql("select refr_lob,refr_init_dt from fpo_t_web_refr_dtl_mth_parq")

df_RelatId_RelatNb_AccN=df_fpo_dt_relat.select(df_fpo_dt_relat['relat_id'],df_fpo_dt_relat['relat_nbr'],df_fpo_dt_relat['acct_mnge_id'],df_fpo_dt_relat['lte_actv_dt'])
df_RelatId_RelatNb_AccN.write.format('com.databricks.spark.avro').save('/user/uism172/FPO/DataFrames/FPO_RelatId_RelatNb_AccN')

df_pri_relat_advs_emp_nm=df_RelatId_RelatNb_AccN.join(df_fpo_bihierflat,df_RelatId_RelatNb_AccN.acct_mnge_id == df_fpo_bihierflat.employeeid,'leftouter').drop('employeeid').select(df_fpo_bihierflat.employeename.alias('pri_relat_advs_emp_nm')).dropDuplicates()
df_pri_relat_advs_emp_nm.write.format('com.databricks.spark.avro').save('/user/uism172/FPO/DataFrames/FPO_pri_relat_advs_emp_nm')

df_mnge_dir_emp_id=df_fpo_bihierflat.join(df_fpo_rt_insite_team,df_fpo_bihierflat.teamid == df_fpo_rt_insite_team.team_id,'inner').join(df_fpo_dt_relat,df_fpo_dt_relat.acct_mnge_id == df_fpo_rt_insite_team.team_lead_id,'leftouter').select(df_fpo_rt_insite_team.team_lead_id.alias('mnge_dir_emp_id')).dropDuplicates()
df_mnge_dir_emp_id.write.format('com.databricks.spark.avro').save('/user/uism172/FPO/DataFrames/FPO_mnge_dir_emp_id')

df_mnge_dir_emp_nm=df_fpo_bihierflat.join(df_fpo_rt_insite_team,df_fpo_bihierflat.teamid == df_fpo_rt_insite_team.team_id,'inner').join(df_fpo_rt_insite_team,df_fpo_rt_insite_team.team_lead_id== df_fpo_bihierflat.employeeid,'leftouter').select(df_fpo_bihierflat.employeename.alias('mnge_dir_emp_nm')).dropDuplicates()
df_mnge_dir_emp_nm.write.format('com.databricks.spark.avro').save('/user/uism172/FPO/DataFrames/FPO_mnge_dir_emp_nm')

df_bihierflat_mapping=df_fpo_bihierflat.select(df_fpo_bihierflat['sublob'],df_fpo_bihierflat['group'],df_fpo_bihierflat['region'],df_fpo_bihierflat['teamname'],df_fpo_bihierflat['jobgroupdesc']).dropDuplicates()
df_bihierflat_mapping.write.format('com.databricks.spark.avro').save('/user/uism172/FPO/DataFrames/FPO_bihierflat_mapping') 

df_fpo_ft_relat_dly_mapping=df_fpo_ft_relat_dly.select(df_fpo_ft_relat_dly['dep_bal_amt'],df_fpo_ft_relat_dly['curr_mkt_val_amt'],df_fpo_ft_relat_dly['hld_away_asset_amt'],df_fpo_ft_relat_dly['annl_ytd_revn_amt']).dropDuplicates()
df_fpo_ft_relat_dly_mapping.write.format('com.databricks.spark.avro').save('/user/uism172/FPO/DataFrames/FPO_ft_relat_dly_mapping')

df_fpo_ft_relat_dly_tot_asset_amt=df_fpo_ft_relat_dly.select((df_fpo_ft_relat_dly['curr_mkt_val_amt']+df_fpo_ft_relat_dly['ln_bal_amt']).alias('ft_relat_dly_tot_asset_amt')).dropDuplicates()
df_fpo_ft_relat_dly_tot_asset_amt.write.format('com.databricks.spark.avro').save('/user/uism172/FPO/DataFrames/FPO_ft_relat_dly_tot_asset_amt')

rdd=df_fpo_dt_relat.select(upper(df_fpo_dt_relat['spcl_unt_cd'])).map(lambda x: ['Y' if s in ['FAMILY OFFICE','GENERAL','GENERAL/OTHER','REAL ESTATE INVESTOR'] else 'N' for s in x])
df_hgh_net_wrth_flg=sqlContext.createDataFrame(rdd)
df_hgh_net_wrth_flg.write.format('com.databricks.spark.avro').save('/user/uism172/FPO/DataFrames/FPO_hgh_net_wrth_flg')

rdd_firstTansformation=df_fpo_t_web_refr_dtl_mth.select(df_fpo_t_web_refr_dtl_mth.refr_lob).map(lambda x: [firstTansformation(s) for s in x])
df_refr_lob_nm=sqlContext.createDataFrame(rdd_firstTansformation)
df_refr_lob_nm.write.format('com.databricks.spark.avro').save('/user/uism172/FPO/DataFrames/FPO_refr_lob_nm')


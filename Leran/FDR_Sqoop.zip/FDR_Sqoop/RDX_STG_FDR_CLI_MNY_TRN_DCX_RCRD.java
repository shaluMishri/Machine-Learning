// ORM class for table 'RDX_STG_FDR.CLI_MNY_TRN_DCX_RCRD'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Tue Nov 21 07:35:44 EST 2017
// For connector: org.apache.sqoop.manager.GenericJdbcManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import com.cloudera.sqoop.lib.JdbcWritableBridge;
import com.cloudera.sqoop.lib.DelimiterSet;
import com.cloudera.sqoop.lib.FieldFormatter;
import com.cloudera.sqoop.lib.RecordParser;
import com.cloudera.sqoop.lib.BooleanParser;
import com.cloudera.sqoop.lib.BlobRef;
import com.cloudera.sqoop.lib.ClobRef;
import com.cloudera.sqoop.lib.LargeObjectLoader;
import com.cloudera.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("RDT_MONETARY_DCX_SEQ_NBR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_MONETARY_DCX_SEQ_NBR = (Long)value;
      }
    });
    setters.put("RDT_REC_CODE_KEY", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_REC_CODE_KEY = (String)value;
      }
    });
    setters.put("RDT_REC_TYPE_CONTROL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_REC_TYPE_CONTROL = (String)value;
      }
    });
    setters.put("RDT_NO_POST_REASON", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_NO_POST_REASON = (Integer)value;
      }
    });
    setters.put("RDT_SC_1", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_SC_1 = (String)value;
      }
    });
    setters.put("RDT_SC_2", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_SC_2 = (String)value;
      }
    });
    setters.put("RDT_SC_3", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_SC_3 = (String)value;
      }
    });
    setters.put("RDT_SC_4", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_SC_4 = (String)value;
      }
    });
    setters.put("RDT_SC_5", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_SC_5 = (String)value;
      }
    });
    setters.put("RDT_SC_6", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_SC_6 = (String)value;
      }
    });
    setters.put("RDT_SC_7", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_SC_7 = (String)value;
      }
    });
    setters.put("RDT_SC_8", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_SC_8 = (String)value;
      }
    });
    setters.put("RDT_CHD_SYSTEM_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_CHD_SYSTEM_NO = (String)value;
      }
    });
    setters.put("RDT_CHD_PRIN_BANK", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_CHD_PRIN_BANK = (String)value;
      }
    });
    setters.put("RDT_CHD_AGENT_BANK", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_CHD_AGENT_BANK = (String)value;
      }
    });
    setters.put("RDT_CHD_ACCOUNT_NUMBER", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_CHD_ACCOUNT_NUMBER = (String)value;
      }
    });
    setters.put("RDT_TRANSACTION_CODE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_TRANSACTION_CODE = (Integer)value;
      }
    });
    setters.put("RDT_MRCH_SYSTEM_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_MRCH_SYSTEM_NO = (String)value;
      }
    });
    setters.put("RDT_MRCH_PRIN_BANK", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_MRCH_PRIN_BANK = (String)value;
      }
    });
    setters.put("RDT_MRCH_AGENT_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_MRCH_AGENT_NO = (String)value;
      }
    });
    setters.put("RDT_MRCH_ACCOUNT_NUMBER", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_MRCH_ACCOUNT_NUMBER = (String)value;
      }
    });
    setters.put("RDT_CHD_EXT_STATUS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_CHD_EXT_STATUS = (String)value;
      }
    });
    setters.put("RDT_CHD_INT_STATUS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_CHD_INT_STATUS = (String)value;
      }
    });
    setters.put("RDT_TANI", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_TANI = (String)value;
      }
    });
    setters.put("RDT_TRANSFER_FLAG", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_TRANSFER_FLAG = (String)value;
      }
    });
    setters.put("RDT_ITEM_ASSES_CODE_NUM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_ITEM_ASSES_CODE_NUM = (Integer)value;
      }
    });
    setters.put("RDT_MRCH_SIC_CODE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_MRCH_SIC_CODE = (Integer)value;
      }
    });
    setters.put("RDT_TRANSACTION_DATE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_TRANSACTION_DATE = (Integer)value;
      }
    });
    setters.put("RDT_DCX_BATCH_TYPE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_BATCH_TYPE = (Integer)value;
      }
    });
    setters.put("RDT_DCX_JULIAN_DATE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_JULIAN_DATE = (Integer)value;
      }
    });
    setters.put("RDT_DCX_TYPE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_TYPE = (String)value;
      }
    });
    setters.put("RDT_DCX_SYS_4", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_SYS_4 = (String)value;
      }
    });
    setters.put("RDT_DCX_SYS_2", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_SYS_2 = (String)value;
      }
    });
    setters.put("RDT_DCX_DATE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_DATE = (String)value;
      }
    });
    setters.put("RDT_DCX_2", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_2 = (String)value;
      }
    });
    setters.put("RDT_DCX_LAST_6", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_LAST_6 = (String)value;
      }
    });
    setters.put("RDT_DCX_ADJ_SALE_FEE_AM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_ADJ_SALE_FEE_AM = (java.math.BigDecimal)value;
      }
    });
    setters.put("FILLER_2", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        FILLER_2 = (String)value;
      }
    });
    setters.put("RDT_DCX_MON_TRAN_JOURNAL_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_MON_TRAN_JOURNAL_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("RDT_DCX_AUDIT_TRAIL_DATE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_AUDIT_TRAIL_DATE = (Integer)value;
      }
    });
    setters.put("RDT_DCX_PRIN_TOTAL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_PRIN_TOTAL = (java.math.BigDecimal)value;
      }
    });
    setters.put("RDT_DCX_PRIN_CASH", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_PRIN_CASH = (java.math.BigDecimal)value;
      }
    });
    setters.put("RDT_DCX_PRIN_MRCH", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_PRIN_MRCH = (java.math.BigDecimal)value;
      }
    });
    setters.put("RDT_DCX_STMT_FIN_CHG_OFF", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_STMT_FIN_CHG_OFF = (java.math.BigDecimal)value;
      }
    });
    setters.put("RDT_DCX_MTJ_FIN_CHG_OFF", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_MTJ_FIN_CHG_OFF = (java.math.BigDecimal)value;
      }
    });
    setters.put("RDT_DCX_BAL_TRAN_DUAL_FLAG", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_BAL_TRAN_DUAL_FLAG = (Integer)value;
      }
    });
    setters.put("RDT_DCX_PRIN_MISC_CHGS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_PRIN_MISC_CHGS = (java.math.BigDecimal)value;
      }
    });
    setters.put("RDT_DCX_CR_LIFE_CHG_OFF", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_CR_LIFE_CHG_OFF = (java.math.BigDecimal)value;
      }
    });
    setters.put("RDT_DCX_ACCRUED_CASHINT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_ACCRUED_CASHINT = (java.math.BigDecimal)value;
      }
    });
    setters.put("RDT_DCX_ACCRUED_MRCHINT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_ACCRUED_MRCHINT = (java.math.BigDecimal)value;
      }
    });
    setters.put("RDT_DCX_BALANCE_CHG_OFF", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_BALANCE_CHG_OFF = (java.math.BigDecimal)value;
      }
    });
    setters.put("RDT_DCX_OLD_OPEN_BALANCE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_OLD_OPEN_BALANCE = (java.math.BigDecimal)value;
      }
    });
    setters.put("RDT_DCX_ACCRUED_CRDINT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_ACCRUED_CRDINT = (java.math.BigDecimal)value;
      }
    });
    setters.put("FILLER_3", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        FILLER_3 = (String)value;
      }
    });
    setters.put("RDT_DCX_ADDL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RDT_DCX_ADDL = (Integer)value;
      }
    });
    setters.put("FILLER_3A", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        FILLER_3A = (String)value;
      }
    });
    setters.put("FILLER_4", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        FILLER_4 = (String)value;
      }
    });
    setters.put("DTE_TME_ROW_ADDED", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        DTE_TME_ROW_ADDED = (java.sql.Timestamp)value;
      }
    });
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD() {
    init0();
  }
  private Long RDT_MONETARY_DCX_SEQ_NBR;
  public Long get_RDT_MONETARY_DCX_SEQ_NBR() {
    return RDT_MONETARY_DCX_SEQ_NBR;
  }
  public void set_RDT_MONETARY_DCX_SEQ_NBR(Long RDT_MONETARY_DCX_SEQ_NBR) {
    this.RDT_MONETARY_DCX_SEQ_NBR = RDT_MONETARY_DCX_SEQ_NBR;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_MONETARY_DCX_SEQ_NBR(Long RDT_MONETARY_DCX_SEQ_NBR) {
    this.RDT_MONETARY_DCX_SEQ_NBR = RDT_MONETARY_DCX_SEQ_NBR;
    return this;
  }
  private String RDT_REC_CODE_KEY;
  public String get_RDT_REC_CODE_KEY() {
    return RDT_REC_CODE_KEY;
  }
  public void set_RDT_REC_CODE_KEY(String RDT_REC_CODE_KEY) {
    this.RDT_REC_CODE_KEY = RDT_REC_CODE_KEY;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_REC_CODE_KEY(String RDT_REC_CODE_KEY) {
    this.RDT_REC_CODE_KEY = RDT_REC_CODE_KEY;
    return this;
  }
  private String RDT_REC_TYPE_CONTROL;
  public String get_RDT_REC_TYPE_CONTROL() {
    return RDT_REC_TYPE_CONTROL;
  }
  public void set_RDT_REC_TYPE_CONTROL(String RDT_REC_TYPE_CONTROL) {
    this.RDT_REC_TYPE_CONTROL = RDT_REC_TYPE_CONTROL;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_REC_TYPE_CONTROL(String RDT_REC_TYPE_CONTROL) {
    this.RDT_REC_TYPE_CONTROL = RDT_REC_TYPE_CONTROL;
    return this;
  }
  private Integer RDT_NO_POST_REASON;
  public Integer get_RDT_NO_POST_REASON() {
    return RDT_NO_POST_REASON;
  }
  public void set_RDT_NO_POST_REASON(Integer RDT_NO_POST_REASON) {
    this.RDT_NO_POST_REASON = RDT_NO_POST_REASON;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_NO_POST_REASON(Integer RDT_NO_POST_REASON) {
    this.RDT_NO_POST_REASON = RDT_NO_POST_REASON;
    return this;
  }
  private String RDT_SC_1;
  public String get_RDT_SC_1() {
    return RDT_SC_1;
  }
  public void set_RDT_SC_1(String RDT_SC_1) {
    this.RDT_SC_1 = RDT_SC_1;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_SC_1(String RDT_SC_1) {
    this.RDT_SC_1 = RDT_SC_1;
    return this;
  }
  private String RDT_SC_2;
  public String get_RDT_SC_2() {
    return RDT_SC_2;
  }
  public void set_RDT_SC_2(String RDT_SC_2) {
    this.RDT_SC_2 = RDT_SC_2;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_SC_2(String RDT_SC_2) {
    this.RDT_SC_2 = RDT_SC_2;
    return this;
  }
  private String RDT_SC_3;
  public String get_RDT_SC_3() {
    return RDT_SC_3;
  }
  public void set_RDT_SC_3(String RDT_SC_3) {
    this.RDT_SC_3 = RDT_SC_3;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_SC_3(String RDT_SC_3) {
    this.RDT_SC_3 = RDT_SC_3;
    return this;
  }
  private String RDT_SC_4;
  public String get_RDT_SC_4() {
    return RDT_SC_4;
  }
  public void set_RDT_SC_4(String RDT_SC_4) {
    this.RDT_SC_4 = RDT_SC_4;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_SC_4(String RDT_SC_4) {
    this.RDT_SC_4 = RDT_SC_4;
    return this;
  }
  private String RDT_SC_5;
  public String get_RDT_SC_5() {
    return RDT_SC_5;
  }
  public void set_RDT_SC_5(String RDT_SC_5) {
    this.RDT_SC_5 = RDT_SC_5;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_SC_5(String RDT_SC_5) {
    this.RDT_SC_5 = RDT_SC_5;
    return this;
  }
  private String RDT_SC_6;
  public String get_RDT_SC_6() {
    return RDT_SC_6;
  }
  public void set_RDT_SC_6(String RDT_SC_6) {
    this.RDT_SC_6 = RDT_SC_6;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_SC_6(String RDT_SC_6) {
    this.RDT_SC_6 = RDT_SC_6;
    return this;
  }
  private String RDT_SC_7;
  public String get_RDT_SC_7() {
    return RDT_SC_7;
  }
  public void set_RDT_SC_7(String RDT_SC_7) {
    this.RDT_SC_7 = RDT_SC_7;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_SC_7(String RDT_SC_7) {
    this.RDT_SC_7 = RDT_SC_7;
    return this;
  }
  private String RDT_SC_8;
  public String get_RDT_SC_8() {
    return RDT_SC_8;
  }
  public void set_RDT_SC_8(String RDT_SC_8) {
    this.RDT_SC_8 = RDT_SC_8;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_SC_8(String RDT_SC_8) {
    this.RDT_SC_8 = RDT_SC_8;
    return this;
  }
  private String RDT_CHD_SYSTEM_NO;
  public String get_RDT_CHD_SYSTEM_NO() {
    return RDT_CHD_SYSTEM_NO;
  }
  public void set_RDT_CHD_SYSTEM_NO(String RDT_CHD_SYSTEM_NO) {
    this.RDT_CHD_SYSTEM_NO = RDT_CHD_SYSTEM_NO;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_CHD_SYSTEM_NO(String RDT_CHD_SYSTEM_NO) {
    this.RDT_CHD_SYSTEM_NO = RDT_CHD_SYSTEM_NO;
    return this;
  }
  private String RDT_CHD_PRIN_BANK;
  public String get_RDT_CHD_PRIN_BANK() {
    return RDT_CHD_PRIN_BANK;
  }
  public void set_RDT_CHD_PRIN_BANK(String RDT_CHD_PRIN_BANK) {
    this.RDT_CHD_PRIN_BANK = RDT_CHD_PRIN_BANK;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_CHD_PRIN_BANK(String RDT_CHD_PRIN_BANK) {
    this.RDT_CHD_PRIN_BANK = RDT_CHD_PRIN_BANK;
    return this;
  }
  private String RDT_CHD_AGENT_BANK;
  public String get_RDT_CHD_AGENT_BANK() {
    return RDT_CHD_AGENT_BANK;
  }
  public void set_RDT_CHD_AGENT_BANK(String RDT_CHD_AGENT_BANK) {
    this.RDT_CHD_AGENT_BANK = RDT_CHD_AGENT_BANK;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_CHD_AGENT_BANK(String RDT_CHD_AGENT_BANK) {
    this.RDT_CHD_AGENT_BANK = RDT_CHD_AGENT_BANK;
    return this;
  }
  private String RDT_CHD_ACCOUNT_NUMBER;
  public String get_RDT_CHD_ACCOUNT_NUMBER() {
    return RDT_CHD_ACCOUNT_NUMBER;
  }
  public void set_RDT_CHD_ACCOUNT_NUMBER(String RDT_CHD_ACCOUNT_NUMBER) {
    this.RDT_CHD_ACCOUNT_NUMBER = RDT_CHD_ACCOUNT_NUMBER;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_CHD_ACCOUNT_NUMBER(String RDT_CHD_ACCOUNT_NUMBER) {
    this.RDT_CHD_ACCOUNT_NUMBER = RDT_CHD_ACCOUNT_NUMBER;
    return this;
  }
  private Integer RDT_TRANSACTION_CODE;
  public Integer get_RDT_TRANSACTION_CODE() {
    return RDT_TRANSACTION_CODE;
  }
  public void set_RDT_TRANSACTION_CODE(Integer RDT_TRANSACTION_CODE) {
    this.RDT_TRANSACTION_CODE = RDT_TRANSACTION_CODE;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_TRANSACTION_CODE(Integer RDT_TRANSACTION_CODE) {
    this.RDT_TRANSACTION_CODE = RDT_TRANSACTION_CODE;
    return this;
  }
  private String RDT_MRCH_SYSTEM_NO;
  public String get_RDT_MRCH_SYSTEM_NO() {
    return RDT_MRCH_SYSTEM_NO;
  }
  public void set_RDT_MRCH_SYSTEM_NO(String RDT_MRCH_SYSTEM_NO) {
    this.RDT_MRCH_SYSTEM_NO = RDT_MRCH_SYSTEM_NO;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_MRCH_SYSTEM_NO(String RDT_MRCH_SYSTEM_NO) {
    this.RDT_MRCH_SYSTEM_NO = RDT_MRCH_SYSTEM_NO;
    return this;
  }
  private String RDT_MRCH_PRIN_BANK;
  public String get_RDT_MRCH_PRIN_BANK() {
    return RDT_MRCH_PRIN_BANK;
  }
  public void set_RDT_MRCH_PRIN_BANK(String RDT_MRCH_PRIN_BANK) {
    this.RDT_MRCH_PRIN_BANK = RDT_MRCH_PRIN_BANK;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_MRCH_PRIN_BANK(String RDT_MRCH_PRIN_BANK) {
    this.RDT_MRCH_PRIN_BANK = RDT_MRCH_PRIN_BANK;
    return this;
  }
  private String RDT_MRCH_AGENT_NO;
  public String get_RDT_MRCH_AGENT_NO() {
    return RDT_MRCH_AGENT_NO;
  }
  public void set_RDT_MRCH_AGENT_NO(String RDT_MRCH_AGENT_NO) {
    this.RDT_MRCH_AGENT_NO = RDT_MRCH_AGENT_NO;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_MRCH_AGENT_NO(String RDT_MRCH_AGENT_NO) {
    this.RDT_MRCH_AGENT_NO = RDT_MRCH_AGENT_NO;
    return this;
  }
  private String RDT_MRCH_ACCOUNT_NUMBER;
  public String get_RDT_MRCH_ACCOUNT_NUMBER() {
    return RDT_MRCH_ACCOUNT_NUMBER;
  }
  public void set_RDT_MRCH_ACCOUNT_NUMBER(String RDT_MRCH_ACCOUNT_NUMBER) {
    this.RDT_MRCH_ACCOUNT_NUMBER = RDT_MRCH_ACCOUNT_NUMBER;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_MRCH_ACCOUNT_NUMBER(String RDT_MRCH_ACCOUNT_NUMBER) {
    this.RDT_MRCH_ACCOUNT_NUMBER = RDT_MRCH_ACCOUNT_NUMBER;
    return this;
  }
  private String RDT_CHD_EXT_STATUS;
  public String get_RDT_CHD_EXT_STATUS() {
    return RDT_CHD_EXT_STATUS;
  }
  public void set_RDT_CHD_EXT_STATUS(String RDT_CHD_EXT_STATUS) {
    this.RDT_CHD_EXT_STATUS = RDT_CHD_EXT_STATUS;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_CHD_EXT_STATUS(String RDT_CHD_EXT_STATUS) {
    this.RDT_CHD_EXT_STATUS = RDT_CHD_EXT_STATUS;
    return this;
  }
  private String RDT_CHD_INT_STATUS;
  public String get_RDT_CHD_INT_STATUS() {
    return RDT_CHD_INT_STATUS;
  }
  public void set_RDT_CHD_INT_STATUS(String RDT_CHD_INT_STATUS) {
    this.RDT_CHD_INT_STATUS = RDT_CHD_INT_STATUS;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_CHD_INT_STATUS(String RDT_CHD_INT_STATUS) {
    this.RDT_CHD_INT_STATUS = RDT_CHD_INT_STATUS;
    return this;
  }
  private String RDT_TANI;
  public String get_RDT_TANI() {
    return RDT_TANI;
  }
  public void set_RDT_TANI(String RDT_TANI) {
    this.RDT_TANI = RDT_TANI;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_TANI(String RDT_TANI) {
    this.RDT_TANI = RDT_TANI;
    return this;
  }
  private String RDT_TRANSFER_FLAG;
  public String get_RDT_TRANSFER_FLAG() {
    return RDT_TRANSFER_FLAG;
  }
  public void set_RDT_TRANSFER_FLAG(String RDT_TRANSFER_FLAG) {
    this.RDT_TRANSFER_FLAG = RDT_TRANSFER_FLAG;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_TRANSFER_FLAG(String RDT_TRANSFER_FLAG) {
    this.RDT_TRANSFER_FLAG = RDT_TRANSFER_FLAG;
    return this;
  }
  private Integer RDT_ITEM_ASSES_CODE_NUM;
  public Integer get_RDT_ITEM_ASSES_CODE_NUM() {
    return RDT_ITEM_ASSES_CODE_NUM;
  }
  public void set_RDT_ITEM_ASSES_CODE_NUM(Integer RDT_ITEM_ASSES_CODE_NUM) {
    this.RDT_ITEM_ASSES_CODE_NUM = RDT_ITEM_ASSES_CODE_NUM;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_ITEM_ASSES_CODE_NUM(Integer RDT_ITEM_ASSES_CODE_NUM) {
    this.RDT_ITEM_ASSES_CODE_NUM = RDT_ITEM_ASSES_CODE_NUM;
    return this;
  }
  private Integer RDT_MRCH_SIC_CODE;
  public Integer get_RDT_MRCH_SIC_CODE() {
    return RDT_MRCH_SIC_CODE;
  }
  public void set_RDT_MRCH_SIC_CODE(Integer RDT_MRCH_SIC_CODE) {
    this.RDT_MRCH_SIC_CODE = RDT_MRCH_SIC_CODE;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_MRCH_SIC_CODE(Integer RDT_MRCH_SIC_CODE) {
    this.RDT_MRCH_SIC_CODE = RDT_MRCH_SIC_CODE;
    return this;
  }
  private Integer RDT_TRANSACTION_DATE;
  public Integer get_RDT_TRANSACTION_DATE() {
    return RDT_TRANSACTION_DATE;
  }
  public void set_RDT_TRANSACTION_DATE(Integer RDT_TRANSACTION_DATE) {
    this.RDT_TRANSACTION_DATE = RDT_TRANSACTION_DATE;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_TRANSACTION_DATE(Integer RDT_TRANSACTION_DATE) {
    this.RDT_TRANSACTION_DATE = RDT_TRANSACTION_DATE;
    return this;
  }
  private Integer RDT_DCX_BATCH_TYPE;
  public Integer get_RDT_DCX_BATCH_TYPE() {
    return RDT_DCX_BATCH_TYPE;
  }
  public void set_RDT_DCX_BATCH_TYPE(Integer RDT_DCX_BATCH_TYPE) {
    this.RDT_DCX_BATCH_TYPE = RDT_DCX_BATCH_TYPE;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_BATCH_TYPE(Integer RDT_DCX_BATCH_TYPE) {
    this.RDT_DCX_BATCH_TYPE = RDT_DCX_BATCH_TYPE;
    return this;
  }
  private Integer RDT_DCX_JULIAN_DATE;
  public Integer get_RDT_DCX_JULIAN_DATE() {
    return RDT_DCX_JULIAN_DATE;
  }
  public void set_RDT_DCX_JULIAN_DATE(Integer RDT_DCX_JULIAN_DATE) {
    this.RDT_DCX_JULIAN_DATE = RDT_DCX_JULIAN_DATE;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_JULIAN_DATE(Integer RDT_DCX_JULIAN_DATE) {
    this.RDT_DCX_JULIAN_DATE = RDT_DCX_JULIAN_DATE;
    return this;
  }
  private String RDT_DCX_TYPE;
  public String get_RDT_DCX_TYPE() {
    return RDT_DCX_TYPE;
  }
  public void set_RDT_DCX_TYPE(String RDT_DCX_TYPE) {
    this.RDT_DCX_TYPE = RDT_DCX_TYPE;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_TYPE(String RDT_DCX_TYPE) {
    this.RDT_DCX_TYPE = RDT_DCX_TYPE;
    return this;
  }
  private String RDT_DCX_SYS_4;
  public String get_RDT_DCX_SYS_4() {
    return RDT_DCX_SYS_4;
  }
  public void set_RDT_DCX_SYS_4(String RDT_DCX_SYS_4) {
    this.RDT_DCX_SYS_4 = RDT_DCX_SYS_4;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_SYS_4(String RDT_DCX_SYS_4) {
    this.RDT_DCX_SYS_4 = RDT_DCX_SYS_4;
    return this;
  }
  private String RDT_DCX_SYS_2;
  public String get_RDT_DCX_SYS_2() {
    return RDT_DCX_SYS_2;
  }
  public void set_RDT_DCX_SYS_2(String RDT_DCX_SYS_2) {
    this.RDT_DCX_SYS_2 = RDT_DCX_SYS_2;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_SYS_2(String RDT_DCX_SYS_2) {
    this.RDT_DCX_SYS_2 = RDT_DCX_SYS_2;
    return this;
  }
  private String RDT_DCX_DATE;
  public String get_RDT_DCX_DATE() {
    return RDT_DCX_DATE;
  }
  public void set_RDT_DCX_DATE(String RDT_DCX_DATE) {
    this.RDT_DCX_DATE = RDT_DCX_DATE;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_DATE(String RDT_DCX_DATE) {
    this.RDT_DCX_DATE = RDT_DCX_DATE;
    return this;
  }
  private String RDT_DCX_2;
  public String get_RDT_DCX_2() {
    return RDT_DCX_2;
  }
  public void set_RDT_DCX_2(String RDT_DCX_2) {
    this.RDT_DCX_2 = RDT_DCX_2;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_2(String RDT_DCX_2) {
    this.RDT_DCX_2 = RDT_DCX_2;
    return this;
  }
  private String RDT_DCX_LAST_6;
  public String get_RDT_DCX_LAST_6() {
    return RDT_DCX_LAST_6;
  }
  public void set_RDT_DCX_LAST_6(String RDT_DCX_LAST_6) {
    this.RDT_DCX_LAST_6 = RDT_DCX_LAST_6;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_LAST_6(String RDT_DCX_LAST_6) {
    this.RDT_DCX_LAST_6 = RDT_DCX_LAST_6;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_ADJ_SALE_FEE_AM;
  public java.math.BigDecimal get_RDT_DCX_ADJ_SALE_FEE_AM() {
    return RDT_DCX_ADJ_SALE_FEE_AM;
  }
  public void set_RDT_DCX_ADJ_SALE_FEE_AM(java.math.BigDecimal RDT_DCX_ADJ_SALE_FEE_AM) {
    this.RDT_DCX_ADJ_SALE_FEE_AM = RDT_DCX_ADJ_SALE_FEE_AM;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_ADJ_SALE_FEE_AM(java.math.BigDecimal RDT_DCX_ADJ_SALE_FEE_AM) {
    this.RDT_DCX_ADJ_SALE_FEE_AM = RDT_DCX_ADJ_SALE_FEE_AM;
    return this;
  }
  private String FILLER_2;
  public String get_FILLER_2() {
    return FILLER_2;
  }
  public void set_FILLER_2(String FILLER_2) {
    this.FILLER_2 = FILLER_2;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_FILLER_2(String FILLER_2) {
    this.FILLER_2 = FILLER_2;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_MON_TRAN_JOURNAL_AMT;
  public java.math.BigDecimal get_RDT_DCX_MON_TRAN_JOURNAL_AMT() {
    return RDT_DCX_MON_TRAN_JOURNAL_AMT;
  }
  public void set_RDT_DCX_MON_TRAN_JOURNAL_AMT(java.math.BigDecimal RDT_DCX_MON_TRAN_JOURNAL_AMT) {
    this.RDT_DCX_MON_TRAN_JOURNAL_AMT = RDT_DCX_MON_TRAN_JOURNAL_AMT;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_MON_TRAN_JOURNAL_AMT(java.math.BigDecimal RDT_DCX_MON_TRAN_JOURNAL_AMT) {
    this.RDT_DCX_MON_TRAN_JOURNAL_AMT = RDT_DCX_MON_TRAN_JOURNAL_AMT;
    return this;
  }
  private Integer RDT_DCX_AUDIT_TRAIL_DATE;
  public Integer get_RDT_DCX_AUDIT_TRAIL_DATE() {
    return RDT_DCX_AUDIT_TRAIL_DATE;
  }
  public void set_RDT_DCX_AUDIT_TRAIL_DATE(Integer RDT_DCX_AUDIT_TRAIL_DATE) {
    this.RDT_DCX_AUDIT_TRAIL_DATE = RDT_DCX_AUDIT_TRAIL_DATE;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_AUDIT_TRAIL_DATE(Integer RDT_DCX_AUDIT_TRAIL_DATE) {
    this.RDT_DCX_AUDIT_TRAIL_DATE = RDT_DCX_AUDIT_TRAIL_DATE;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_PRIN_TOTAL;
  public java.math.BigDecimal get_RDT_DCX_PRIN_TOTAL() {
    return RDT_DCX_PRIN_TOTAL;
  }
  public void set_RDT_DCX_PRIN_TOTAL(java.math.BigDecimal RDT_DCX_PRIN_TOTAL) {
    this.RDT_DCX_PRIN_TOTAL = RDT_DCX_PRIN_TOTAL;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_PRIN_TOTAL(java.math.BigDecimal RDT_DCX_PRIN_TOTAL) {
    this.RDT_DCX_PRIN_TOTAL = RDT_DCX_PRIN_TOTAL;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_PRIN_CASH;
  public java.math.BigDecimal get_RDT_DCX_PRIN_CASH() {
    return RDT_DCX_PRIN_CASH;
  }
  public void set_RDT_DCX_PRIN_CASH(java.math.BigDecimal RDT_DCX_PRIN_CASH) {
    this.RDT_DCX_PRIN_CASH = RDT_DCX_PRIN_CASH;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_PRIN_CASH(java.math.BigDecimal RDT_DCX_PRIN_CASH) {
    this.RDT_DCX_PRIN_CASH = RDT_DCX_PRIN_CASH;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_PRIN_MRCH;
  public java.math.BigDecimal get_RDT_DCX_PRIN_MRCH() {
    return RDT_DCX_PRIN_MRCH;
  }
  public void set_RDT_DCX_PRIN_MRCH(java.math.BigDecimal RDT_DCX_PRIN_MRCH) {
    this.RDT_DCX_PRIN_MRCH = RDT_DCX_PRIN_MRCH;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_PRIN_MRCH(java.math.BigDecimal RDT_DCX_PRIN_MRCH) {
    this.RDT_DCX_PRIN_MRCH = RDT_DCX_PRIN_MRCH;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_STMT_FIN_CHG_OFF;
  public java.math.BigDecimal get_RDT_DCX_STMT_FIN_CHG_OFF() {
    return RDT_DCX_STMT_FIN_CHG_OFF;
  }
  public void set_RDT_DCX_STMT_FIN_CHG_OFF(java.math.BigDecimal RDT_DCX_STMT_FIN_CHG_OFF) {
    this.RDT_DCX_STMT_FIN_CHG_OFF = RDT_DCX_STMT_FIN_CHG_OFF;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_STMT_FIN_CHG_OFF(java.math.BigDecimal RDT_DCX_STMT_FIN_CHG_OFF) {
    this.RDT_DCX_STMT_FIN_CHG_OFF = RDT_DCX_STMT_FIN_CHG_OFF;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_MTJ_FIN_CHG_OFF;
  public java.math.BigDecimal get_RDT_DCX_MTJ_FIN_CHG_OFF() {
    return RDT_DCX_MTJ_FIN_CHG_OFF;
  }
  public void set_RDT_DCX_MTJ_FIN_CHG_OFF(java.math.BigDecimal RDT_DCX_MTJ_FIN_CHG_OFF) {
    this.RDT_DCX_MTJ_FIN_CHG_OFF = RDT_DCX_MTJ_FIN_CHG_OFF;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_MTJ_FIN_CHG_OFF(java.math.BigDecimal RDT_DCX_MTJ_FIN_CHG_OFF) {
    this.RDT_DCX_MTJ_FIN_CHG_OFF = RDT_DCX_MTJ_FIN_CHG_OFF;
    return this;
  }
  private Integer RDT_DCX_BAL_TRAN_DUAL_FLAG;
  public Integer get_RDT_DCX_BAL_TRAN_DUAL_FLAG() {
    return RDT_DCX_BAL_TRAN_DUAL_FLAG;
  }
  public void set_RDT_DCX_BAL_TRAN_DUAL_FLAG(Integer RDT_DCX_BAL_TRAN_DUAL_FLAG) {
    this.RDT_DCX_BAL_TRAN_DUAL_FLAG = RDT_DCX_BAL_TRAN_DUAL_FLAG;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_BAL_TRAN_DUAL_FLAG(Integer RDT_DCX_BAL_TRAN_DUAL_FLAG) {
    this.RDT_DCX_BAL_TRAN_DUAL_FLAG = RDT_DCX_BAL_TRAN_DUAL_FLAG;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_PRIN_MISC_CHGS;
  public java.math.BigDecimal get_RDT_DCX_PRIN_MISC_CHGS() {
    return RDT_DCX_PRIN_MISC_CHGS;
  }
  public void set_RDT_DCX_PRIN_MISC_CHGS(java.math.BigDecimal RDT_DCX_PRIN_MISC_CHGS) {
    this.RDT_DCX_PRIN_MISC_CHGS = RDT_DCX_PRIN_MISC_CHGS;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_PRIN_MISC_CHGS(java.math.BigDecimal RDT_DCX_PRIN_MISC_CHGS) {
    this.RDT_DCX_PRIN_MISC_CHGS = RDT_DCX_PRIN_MISC_CHGS;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_CR_LIFE_CHG_OFF;
  public java.math.BigDecimal get_RDT_DCX_CR_LIFE_CHG_OFF() {
    return RDT_DCX_CR_LIFE_CHG_OFF;
  }
  public void set_RDT_DCX_CR_LIFE_CHG_OFF(java.math.BigDecimal RDT_DCX_CR_LIFE_CHG_OFF) {
    this.RDT_DCX_CR_LIFE_CHG_OFF = RDT_DCX_CR_LIFE_CHG_OFF;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_CR_LIFE_CHG_OFF(java.math.BigDecimal RDT_DCX_CR_LIFE_CHG_OFF) {
    this.RDT_DCX_CR_LIFE_CHG_OFF = RDT_DCX_CR_LIFE_CHG_OFF;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_ACCRUED_CASHINT;
  public java.math.BigDecimal get_RDT_DCX_ACCRUED_CASHINT() {
    return RDT_DCX_ACCRUED_CASHINT;
  }
  public void set_RDT_DCX_ACCRUED_CASHINT(java.math.BigDecimal RDT_DCX_ACCRUED_CASHINT) {
    this.RDT_DCX_ACCRUED_CASHINT = RDT_DCX_ACCRUED_CASHINT;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_ACCRUED_CASHINT(java.math.BigDecimal RDT_DCX_ACCRUED_CASHINT) {
    this.RDT_DCX_ACCRUED_CASHINT = RDT_DCX_ACCRUED_CASHINT;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_ACCRUED_MRCHINT;
  public java.math.BigDecimal get_RDT_DCX_ACCRUED_MRCHINT() {
    return RDT_DCX_ACCRUED_MRCHINT;
  }
  public void set_RDT_DCX_ACCRUED_MRCHINT(java.math.BigDecimal RDT_DCX_ACCRUED_MRCHINT) {
    this.RDT_DCX_ACCRUED_MRCHINT = RDT_DCX_ACCRUED_MRCHINT;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_ACCRUED_MRCHINT(java.math.BigDecimal RDT_DCX_ACCRUED_MRCHINT) {
    this.RDT_DCX_ACCRUED_MRCHINT = RDT_DCX_ACCRUED_MRCHINT;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_BALANCE_CHG_OFF;
  public java.math.BigDecimal get_RDT_DCX_BALANCE_CHG_OFF() {
    return RDT_DCX_BALANCE_CHG_OFF;
  }
  public void set_RDT_DCX_BALANCE_CHG_OFF(java.math.BigDecimal RDT_DCX_BALANCE_CHG_OFF) {
    this.RDT_DCX_BALANCE_CHG_OFF = RDT_DCX_BALANCE_CHG_OFF;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_BALANCE_CHG_OFF(java.math.BigDecimal RDT_DCX_BALANCE_CHG_OFF) {
    this.RDT_DCX_BALANCE_CHG_OFF = RDT_DCX_BALANCE_CHG_OFF;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_OLD_OPEN_BALANCE;
  public java.math.BigDecimal get_RDT_DCX_OLD_OPEN_BALANCE() {
    return RDT_DCX_OLD_OPEN_BALANCE;
  }
  public void set_RDT_DCX_OLD_OPEN_BALANCE(java.math.BigDecimal RDT_DCX_OLD_OPEN_BALANCE) {
    this.RDT_DCX_OLD_OPEN_BALANCE = RDT_DCX_OLD_OPEN_BALANCE;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_OLD_OPEN_BALANCE(java.math.BigDecimal RDT_DCX_OLD_OPEN_BALANCE) {
    this.RDT_DCX_OLD_OPEN_BALANCE = RDT_DCX_OLD_OPEN_BALANCE;
    return this;
  }
  private java.math.BigDecimal RDT_DCX_ACCRUED_CRDINT;
  public java.math.BigDecimal get_RDT_DCX_ACCRUED_CRDINT() {
    return RDT_DCX_ACCRUED_CRDINT;
  }
  public void set_RDT_DCX_ACCRUED_CRDINT(java.math.BigDecimal RDT_DCX_ACCRUED_CRDINT) {
    this.RDT_DCX_ACCRUED_CRDINT = RDT_DCX_ACCRUED_CRDINT;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_ACCRUED_CRDINT(java.math.BigDecimal RDT_DCX_ACCRUED_CRDINT) {
    this.RDT_DCX_ACCRUED_CRDINT = RDT_DCX_ACCRUED_CRDINT;
    return this;
  }
  private String FILLER_3;
  public String get_FILLER_3() {
    return FILLER_3;
  }
  public void set_FILLER_3(String FILLER_3) {
    this.FILLER_3 = FILLER_3;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_FILLER_3(String FILLER_3) {
    this.FILLER_3 = FILLER_3;
    return this;
  }
  private Integer RDT_DCX_ADDL;
  public Integer get_RDT_DCX_ADDL() {
    return RDT_DCX_ADDL;
  }
  public void set_RDT_DCX_ADDL(Integer RDT_DCX_ADDL) {
    this.RDT_DCX_ADDL = RDT_DCX_ADDL;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_RDT_DCX_ADDL(Integer RDT_DCX_ADDL) {
    this.RDT_DCX_ADDL = RDT_DCX_ADDL;
    return this;
  }
  private String FILLER_3A;
  public String get_FILLER_3A() {
    return FILLER_3A;
  }
  public void set_FILLER_3A(String FILLER_3A) {
    this.FILLER_3A = FILLER_3A;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_FILLER_3A(String FILLER_3A) {
    this.FILLER_3A = FILLER_3A;
    return this;
  }
  private String FILLER_4;
  public String get_FILLER_4() {
    return FILLER_4;
  }
  public void set_FILLER_4(String FILLER_4) {
    this.FILLER_4 = FILLER_4;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_FILLER_4(String FILLER_4) {
    this.FILLER_4 = FILLER_4;
    return this;
  }
  private java.sql.Timestamp DTE_TME_ROW_ADDED;
  public java.sql.Timestamp get_DTE_TME_ROW_ADDED() {
    return DTE_TME_ROW_ADDED;
  }
  public void set_DTE_TME_ROW_ADDED(java.sql.Timestamp DTE_TME_ROW_ADDED) {
    this.DTE_TME_ROW_ADDED = DTE_TME_ROW_ADDED;
  }
  public RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD with_DTE_TME_ROW_ADDED(java.sql.Timestamp DTE_TME_ROW_ADDED) {
    this.DTE_TME_ROW_ADDED = DTE_TME_ROW_ADDED;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD)) {
      return false;
    }
    RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD that = (RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD) o;
    boolean equal = true;
    equal = equal && (this.RDT_MONETARY_DCX_SEQ_NBR == null ? that.RDT_MONETARY_DCX_SEQ_NBR == null : this.RDT_MONETARY_DCX_SEQ_NBR.equals(that.RDT_MONETARY_DCX_SEQ_NBR));
    equal = equal && (this.RDT_REC_CODE_KEY == null ? that.RDT_REC_CODE_KEY == null : this.RDT_REC_CODE_KEY.equals(that.RDT_REC_CODE_KEY));
    equal = equal && (this.RDT_REC_TYPE_CONTROL == null ? that.RDT_REC_TYPE_CONTROL == null : this.RDT_REC_TYPE_CONTROL.equals(that.RDT_REC_TYPE_CONTROL));
    equal = equal && (this.RDT_NO_POST_REASON == null ? that.RDT_NO_POST_REASON == null : this.RDT_NO_POST_REASON.equals(that.RDT_NO_POST_REASON));
    equal = equal && (this.RDT_SC_1 == null ? that.RDT_SC_1 == null : this.RDT_SC_1.equals(that.RDT_SC_1));
    equal = equal && (this.RDT_SC_2 == null ? that.RDT_SC_2 == null : this.RDT_SC_2.equals(that.RDT_SC_2));
    equal = equal && (this.RDT_SC_3 == null ? that.RDT_SC_3 == null : this.RDT_SC_3.equals(that.RDT_SC_3));
    equal = equal && (this.RDT_SC_4 == null ? that.RDT_SC_4 == null : this.RDT_SC_4.equals(that.RDT_SC_4));
    equal = equal && (this.RDT_SC_5 == null ? that.RDT_SC_5 == null : this.RDT_SC_5.equals(that.RDT_SC_5));
    equal = equal && (this.RDT_SC_6 == null ? that.RDT_SC_6 == null : this.RDT_SC_6.equals(that.RDT_SC_6));
    equal = equal && (this.RDT_SC_7 == null ? that.RDT_SC_7 == null : this.RDT_SC_7.equals(that.RDT_SC_7));
    equal = equal && (this.RDT_SC_8 == null ? that.RDT_SC_8 == null : this.RDT_SC_8.equals(that.RDT_SC_8));
    equal = equal && (this.RDT_CHD_SYSTEM_NO == null ? that.RDT_CHD_SYSTEM_NO == null : this.RDT_CHD_SYSTEM_NO.equals(that.RDT_CHD_SYSTEM_NO));
    equal = equal && (this.RDT_CHD_PRIN_BANK == null ? that.RDT_CHD_PRIN_BANK == null : this.RDT_CHD_PRIN_BANK.equals(that.RDT_CHD_PRIN_BANK));
    equal = equal && (this.RDT_CHD_AGENT_BANK == null ? that.RDT_CHD_AGENT_BANK == null : this.RDT_CHD_AGENT_BANK.equals(that.RDT_CHD_AGENT_BANK));
    equal = equal && (this.RDT_CHD_ACCOUNT_NUMBER == null ? that.RDT_CHD_ACCOUNT_NUMBER == null : this.RDT_CHD_ACCOUNT_NUMBER.equals(that.RDT_CHD_ACCOUNT_NUMBER));
    equal = equal && (this.RDT_TRANSACTION_CODE == null ? that.RDT_TRANSACTION_CODE == null : this.RDT_TRANSACTION_CODE.equals(that.RDT_TRANSACTION_CODE));
    equal = equal && (this.RDT_MRCH_SYSTEM_NO == null ? that.RDT_MRCH_SYSTEM_NO == null : this.RDT_MRCH_SYSTEM_NO.equals(that.RDT_MRCH_SYSTEM_NO));
    equal = equal && (this.RDT_MRCH_PRIN_BANK == null ? that.RDT_MRCH_PRIN_BANK == null : this.RDT_MRCH_PRIN_BANK.equals(that.RDT_MRCH_PRIN_BANK));
    equal = equal && (this.RDT_MRCH_AGENT_NO == null ? that.RDT_MRCH_AGENT_NO == null : this.RDT_MRCH_AGENT_NO.equals(that.RDT_MRCH_AGENT_NO));
    equal = equal && (this.RDT_MRCH_ACCOUNT_NUMBER == null ? that.RDT_MRCH_ACCOUNT_NUMBER == null : this.RDT_MRCH_ACCOUNT_NUMBER.equals(that.RDT_MRCH_ACCOUNT_NUMBER));
    equal = equal && (this.RDT_CHD_EXT_STATUS == null ? that.RDT_CHD_EXT_STATUS == null : this.RDT_CHD_EXT_STATUS.equals(that.RDT_CHD_EXT_STATUS));
    equal = equal && (this.RDT_CHD_INT_STATUS == null ? that.RDT_CHD_INT_STATUS == null : this.RDT_CHD_INT_STATUS.equals(that.RDT_CHD_INT_STATUS));
    equal = equal && (this.RDT_TANI == null ? that.RDT_TANI == null : this.RDT_TANI.equals(that.RDT_TANI));
    equal = equal && (this.RDT_TRANSFER_FLAG == null ? that.RDT_TRANSFER_FLAG == null : this.RDT_TRANSFER_FLAG.equals(that.RDT_TRANSFER_FLAG));
    equal = equal && (this.RDT_ITEM_ASSES_CODE_NUM == null ? that.RDT_ITEM_ASSES_CODE_NUM == null : this.RDT_ITEM_ASSES_CODE_NUM.equals(that.RDT_ITEM_ASSES_CODE_NUM));
    equal = equal && (this.RDT_MRCH_SIC_CODE == null ? that.RDT_MRCH_SIC_CODE == null : this.RDT_MRCH_SIC_CODE.equals(that.RDT_MRCH_SIC_CODE));
    equal = equal && (this.RDT_TRANSACTION_DATE == null ? that.RDT_TRANSACTION_DATE == null : this.RDT_TRANSACTION_DATE.equals(that.RDT_TRANSACTION_DATE));
    equal = equal && (this.RDT_DCX_BATCH_TYPE == null ? that.RDT_DCX_BATCH_TYPE == null : this.RDT_DCX_BATCH_TYPE.equals(that.RDT_DCX_BATCH_TYPE));
    equal = equal && (this.RDT_DCX_JULIAN_DATE == null ? that.RDT_DCX_JULIAN_DATE == null : this.RDT_DCX_JULIAN_DATE.equals(that.RDT_DCX_JULIAN_DATE));
    equal = equal && (this.RDT_DCX_TYPE == null ? that.RDT_DCX_TYPE == null : this.RDT_DCX_TYPE.equals(that.RDT_DCX_TYPE));
    equal = equal && (this.RDT_DCX_SYS_4 == null ? that.RDT_DCX_SYS_4 == null : this.RDT_DCX_SYS_4.equals(that.RDT_DCX_SYS_4));
    equal = equal && (this.RDT_DCX_SYS_2 == null ? that.RDT_DCX_SYS_2 == null : this.RDT_DCX_SYS_2.equals(that.RDT_DCX_SYS_2));
    equal = equal && (this.RDT_DCX_DATE == null ? that.RDT_DCX_DATE == null : this.RDT_DCX_DATE.equals(that.RDT_DCX_DATE));
    equal = equal && (this.RDT_DCX_2 == null ? that.RDT_DCX_2 == null : this.RDT_DCX_2.equals(that.RDT_DCX_2));
    equal = equal && (this.RDT_DCX_LAST_6 == null ? that.RDT_DCX_LAST_6 == null : this.RDT_DCX_LAST_6.equals(that.RDT_DCX_LAST_6));
    equal = equal && (this.RDT_DCX_ADJ_SALE_FEE_AM == null ? that.RDT_DCX_ADJ_SALE_FEE_AM == null : this.RDT_DCX_ADJ_SALE_FEE_AM.equals(that.RDT_DCX_ADJ_SALE_FEE_AM));
    equal = equal && (this.FILLER_2 == null ? that.FILLER_2 == null : this.FILLER_2.equals(that.FILLER_2));
    equal = equal && (this.RDT_DCX_MON_TRAN_JOURNAL_AMT == null ? that.RDT_DCX_MON_TRAN_JOURNAL_AMT == null : this.RDT_DCX_MON_TRAN_JOURNAL_AMT.equals(that.RDT_DCX_MON_TRAN_JOURNAL_AMT));
    equal = equal && (this.RDT_DCX_AUDIT_TRAIL_DATE == null ? that.RDT_DCX_AUDIT_TRAIL_DATE == null : this.RDT_DCX_AUDIT_TRAIL_DATE.equals(that.RDT_DCX_AUDIT_TRAIL_DATE));
    equal = equal && (this.RDT_DCX_PRIN_TOTAL == null ? that.RDT_DCX_PRIN_TOTAL == null : this.RDT_DCX_PRIN_TOTAL.equals(that.RDT_DCX_PRIN_TOTAL));
    equal = equal && (this.RDT_DCX_PRIN_CASH == null ? that.RDT_DCX_PRIN_CASH == null : this.RDT_DCX_PRIN_CASH.equals(that.RDT_DCX_PRIN_CASH));
    equal = equal && (this.RDT_DCX_PRIN_MRCH == null ? that.RDT_DCX_PRIN_MRCH == null : this.RDT_DCX_PRIN_MRCH.equals(that.RDT_DCX_PRIN_MRCH));
    equal = equal && (this.RDT_DCX_STMT_FIN_CHG_OFF == null ? that.RDT_DCX_STMT_FIN_CHG_OFF == null : this.RDT_DCX_STMT_FIN_CHG_OFF.equals(that.RDT_DCX_STMT_FIN_CHG_OFF));
    equal = equal && (this.RDT_DCX_MTJ_FIN_CHG_OFF == null ? that.RDT_DCX_MTJ_FIN_CHG_OFF == null : this.RDT_DCX_MTJ_FIN_CHG_OFF.equals(that.RDT_DCX_MTJ_FIN_CHG_OFF));
    equal = equal && (this.RDT_DCX_BAL_TRAN_DUAL_FLAG == null ? that.RDT_DCX_BAL_TRAN_DUAL_FLAG == null : this.RDT_DCX_BAL_TRAN_DUAL_FLAG.equals(that.RDT_DCX_BAL_TRAN_DUAL_FLAG));
    equal = equal && (this.RDT_DCX_PRIN_MISC_CHGS == null ? that.RDT_DCX_PRIN_MISC_CHGS == null : this.RDT_DCX_PRIN_MISC_CHGS.equals(that.RDT_DCX_PRIN_MISC_CHGS));
    equal = equal && (this.RDT_DCX_CR_LIFE_CHG_OFF == null ? that.RDT_DCX_CR_LIFE_CHG_OFF == null : this.RDT_DCX_CR_LIFE_CHG_OFF.equals(that.RDT_DCX_CR_LIFE_CHG_OFF));
    equal = equal && (this.RDT_DCX_ACCRUED_CASHINT == null ? that.RDT_DCX_ACCRUED_CASHINT == null : this.RDT_DCX_ACCRUED_CASHINT.equals(that.RDT_DCX_ACCRUED_CASHINT));
    equal = equal && (this.RDT_DCX_ACCRUED_MRCHINT == null ? that.RDT_DCX_ACCRUED_MRCHINT == null : this.RDT_DCX_ACCRUED_MRCHINT.equals(that.RDT_DCX_ACCRUED_MRCHINT));
    equal = equal && (this.RDT_DCX_BALANCE_CHG_OFF == null ? that.RDT_DCX_BALANCE_CHG_OFF == null : this.RDT_DCX_BALANCE_CHG_OFF.equals(that.RDT_DCX_BALANCE_CHG_OFF));
    equal = equal && (this.RDT_DCX_OLD_OPEN_BALANCE == null ? that.RDT_DCX_OLD_OPEN_BALANCE == null : this.RDT_DCX_OLD_OPEN_BALANCE.equals(that.RDT_DCX_OLD_OPEN_BALANCE));
    equal = equal && (this.RDT_DCX_ACCRUED_CRDINT == null ? that.RDT_DCX_ACCRUED_CRDINT == null : this.RDT_DCX_ACCRUED_CRDINT.equals(that.RDT_DCX_ACCRUED_CRDINT));
    equal = equal && (this.FILLER_3 == null ? that.FILLER_3 == null : this.FILLER_3.equals(that.FILLER_3));
    equal = equal && (this.RDT_DCX_ADDL == null ? that.RDT_DCX_ADDL == null : this.RDT_DCX_ADDL.equals(that.RDT_DCX_ADDL));
    equal = equal && (this.FILLER_3A == null ? that.FILLER_3A == null : this.FILLER_3A.equals(that.FILLER_3A));
    equal = equal && (this.FILLER_4 == null ? that.FILLER_4 == null : this.FILLER_4.equals(that.FILLER_4));
    equal = equal && (this.DTE_TME_ROW_ADDED == null ? that.DTE_TME_ROW_ADDED == null : this.DTE_TME_ROW_ADDED.equals(that.DTE_TME_ROW_ADDED));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD)) {
      return false;
    }
    RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD that = (RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD) o;
    boolean equal = true;
    equal = equal && (this.RDT_MONETARY_DCX_SEQ_NBR == null ? that.RDT_MONETARY_DCX_SEQ_NBR == null : this.RDT_MONETARY_DCX_SEQ_NBR.equals(that.RDT_MONETARY_DCX_SEQ_NBR));
    equal = equal && (this.RDT_REC_CODE_KEY == null ? that.RDT_REC_CODE_KEY == null : this.RDT_REC_CODE_KEY.equals(that.RDT_REC_CODE_KEY));
    equal = equal && (this.RDT_REC_TYPE_CONTROL == null ? that.RDT_REC_TYPE_CONTROL == null : this.RDT_REC_TYPE_CONTROL.equals(that.RDT_REC_TYPE_CONTROL));
    equal = equal && (this.RDT_NO_POST_REASON == null ? that.RDT_NO_POST_REASON == null : this.RDT_NO_POST_REASON.equals(that.RDT_NO_POST_REASON));
    equal = equal && (this.RDT_SC_1 == null ? that.RDT_SC_1 == null : this.RDT_SC_1.equals(that.RDT_SC_1));
    equal = equal && (this.RDT_SC_2 == null ? that.RDT_SC_2 == null : this.RDT_SC_2.equals(that.RDT_SC_2));
    equal = equal && (this.RDT_SC_3 == null ? that.RDT_SC_3 == null : this.RDT_SC_3.equals(that.RDT_SC_3));
    equal = equal && (this.RDT_SC_4 == null ? that.RDT_SC_4 == null : this.RDT_SC_4.equals(that.RDT_SC_4));
    equal = equal && (this.RDT_SC_5 == null ? that.RDT_SC_5 == null : this.RDT_SC_5.equals(that.RDT_SC_5));
    equal = equal && (this.RDT_SC_6 == null ? that.RDT_SC_6 == null : this.RDT_SC_6.equals(that.RDT_SC_6));
    equal = equal && (this.RDT_SC_7 == null ? that.RDT_SC_7 == null : this.RDT_SC_7.equals(that.RDT_SC_7));
    equal = equal && (this.RDT_SC_8 == null ? that.RDT_SC_8 == null : this.RDT_SC_8.equals(that.RDT_SC_8));
    equal = equal && (this.RDT_CHD_SYSTEM_NO == null ? that.RDT_CHD_SYSTEM_NO == null : this.RDT_CHD_SYSTEM_NO.equals(that.RDT_CHD_SYSTEM_NO));
    equal = equal && (this.RDT_CHD_PRIN_BANK == null ? that.RDT_CHD_PRIN_BANK == null : this.RDT_CHD_PRIN_BANK.equals(that.RDT_CHD_PRIN_BANK));
    equal = equal && (this.RDT_CHD_AGENT_BANK == null ? that.RDT_CHD_AGENT_BANK == null : this.RDT_CHD_AGENT_BANK.equals(that.RDT_CHD_AGENT_BANK));
    equal = equal && (this.RDT_CHD_ACCOUNT_NUMBER == null ? that.RDT_CHD_ACCOUNT_NUMBER == null : this.RDT_CHD_ACCOUNT_NUMBER.equals(that.RDT_CHD_ACCOUNT_NUMBER));
    equal = equal && (this.RDT_TRANSACTION_CODE == null ? that.RDT_TRANSACTION_CODE == null : this.RDT_TRANSACTION_CODE.equals(that.RDT_TRANSACTION_CODE));
    equal = equal && (this.RDT_MRCH_SYSTEM_NO == null ? that.RDT_MRCH_SYSTEM_NO == null : this.RDT_MRCH_SYSTEM_NO.equals(that.RDT_MRCH_SYSTEM_NO));
    equal = equal && (this.RDT_MRCH_PRIN_BANK == null ? that.RDT_MRCH_PRIN_BANK == null : this.RDT_MRCH_PRIN_BANK.equals(that.RDT_MRCH_PRIN_BANK));
    equal = equal && (this.RDT_MRCH_AGENT_NO == null ? that.RDT_MRCH_AGENT_NO == null : this.RDT_MRCH_AGENT_NO.equals(that.RDT_MRCH_AGENT_NO));
    equal = equal && (this.RDT_MRCH_ACCOUNT_NUMBER == null ? that.RDT_MRCH_ACCOUNT_NUMBER == null : this.RDT_MRCH_ACCOUNT_NUMBER.equals(that.RDT_MRCH_ACCOUNT_NUMBER));
    equal = equal && (this.RDT_CHD_EXT_STATUS == null ? that.RDT_CHD_EXT_STATUS == null : this.RDT_CHD_EXT_STATUS.equals(that.RDT_CHD_EXT_STATUS));
    equal = equal && (this.RDT_CHD_INT_STATUS == null ? that.RDT_CHD_INT_STATUS == null : this.RDT_CHD_INT_STATUS.equals(that.RDT_CHD_INT_STATUS));
    equal = equal && (this.RDT_TANI == null ? that.RDT_TANI == null : this.RDT_TANI.equals(that.RDT_TANI));
    equal = equal && (this.RDT_TRANSFER_FLAG == null ? that.RDT_TRANSFER_FLAG == null : this.RDT_TRANSFER_FLAG.equals(that.RDT_TRANSFER_FLAG));
    equal = equal && (this.RDT_ITEM_ASSES_CODE_NUM == null ? that.RDT_ITEM_ASSES_CODE_NUM == null : this.RDT_ITEM_ASSES_CODE_NUM.equals(that.RDT_ITEM_ASSES_CODE_NUM));
    equal = equal && (this.RDT_MRCH_SIC_CODE == null ? that.RDT_MRCH_SIC_CODE == null : this.RDT_MRCH_SIC_CODE.equals(that.RDT_MRCH_SIC_CODE));
    equal = equal && (this.RDT_TRANSACTION_DATE == null ? that.RDT_TRANSACTION_DATE == null : this.RDT_TRANSACTION_DATE.equals(that.RDT_TRANSACTION_DATE));
    equal = equal && (this.RDT_DCX_BATCH_TYPE == null ? that.RDT_DCX_BATCH_TYPE == null : this.RDT_DCX_BATCH_TYPE.equals(that.RDT_DCX_BATCH_TYPE));
    equal = equal && (this.RDT_DCX_JULIAN_DATE == null ? that.RDT_DCX_JULIAN_DATE == null : this.RDT_DCX_JULIAN_DATE.equals(that.RDT_DCX_JULIAN_DATE));
    equal = equal && (this.RDT_DCX_TYPE == null ? that.RDT_DCX_TYPE == null : this.RDT_DCX_TYPE.equals(that.RDT_DCX_TYPE));
    equal = equal && (this.RDT_DCX_SYS_4 == null ? that.RDT_DCX_SYS_4 == null : this.RDT_DCX_SYS_4.equals(that.RDT_DCX_SYS_4));
    equal = equal && (this.RDT_DCX_SYS_2 == null ? that.RDT_DCX_SYS_2 == null : this.RDT_DCX_SYS_2.equals(that.RDT_DCX_SYS_2));
    equal = equal && (this.RDT_DCX_DATE == null ? that.RDT_DCX_DATE == null : this.RDT_DCX_DATE.equals(that.RDT_DCX_DATE));
    equal = equal && (this.RDT_DCX_2 == null ? that.RDT_DCX_2 == null : this.RDT_DCX_2.equals(that.RDT_DCX_2));
    equal = equal && (this.RDT_DCX_LAST_6 == null ? that.RDT_DCX_LAST_6 == null : this.RDT_DCX_LAST_6.equals(that.RDT_DCX_LAST_6));
    equal = equal && (this.RDT_DCX_ADJ_SALE_FEE_AM == null ? that.RDT_DCX_ADJ_SALE_FEE_AM == null : this.RDT_DCX_ADJ_SALE_FEE_AM.equals(that.RDT_DCX_ADJ_SALE_FEE_AM));
    equal = equal && (this.FILLER_2 == null ? that.FILLER_2 == null : this.FILLER_2.equals(that.FILLER_2));
    equal = equal && (this.RDT_DCX_MON_TRAN_JOURNAL_AMT == null ? that.RDT_DCX_MON_TRAN_JOURNAL_AMT == null : this.RDT_DCX_MON_TRAN_JOURNAL_AMT.equals(that.RDT_DCX_MON_TRAN_JOURNAL_AMT));
    equal = equal && (this.RDT_DCX_AUDIT_TRAIL_DATE == null ? that.RDT_DCX_AUDIT_TRAIL_DATE == null : this.RDT_DCX_AUDIT_TRAIL_DATE.equals(that.RDT_DCX_AUDIT_TRAIL_DATE));
    equal = equal && (this.RDT_DCX_PRIN_TOTAL == null ? that.RDT_DCX_PRIN_TOTAL == null : this.RDT_DCX_PRIN_TOTAL.equals(that.RDT_DCX_PRIN_TOTAL));
    equal = equal && (this.RDT_DCX_PRIN_CASH == null ? that.RDT_DCX_PRIN_CASH == null : this.RDT_DCX_PRIN_CASH.equals(that.RDT_DCX_PRIN_CASH));
    equal = equal && (this.RDT_DCX_PRIN_MRCH == null ? that.RDT_DCX_PRIN_MRCH == null : this.RDT_DCX_PRIN_MRCH.equals(that.RDT_DCX_PRIN_MRCH));
    equal = equal && (this.RDT_DCX_STMT_FIN_CHG_OFF == null ? that.RDT_DCX_STMT_FIN_CHG_OFF == null : this.RDT_DCX_STMT_FIN_CHG_OFF.equals(that.RDT_DCX_STMT_FIN_CHG_OFF));
    equal = equal && (this.RDT_DCX_MTJ_FIN_CHG_OFF == null ? that.RDT_DCX_MTJ_FIN_CHG_OFF == null : this.RDT_DCX_MTJ_FIN_CHG_OFF.equals(that.RDT_DCX_MTJ_FIN_CHG_OFF));
    equal = equal && (this.RDT_DCX_BAL_TRAN_DUAL_FLAG == null ? that.RDT_DCX_BAL_TRAN_DUAL_FLAG == null : this.RDT_DCX_BAL_TRAN_DUAL_FLAG.equals(that.RDT_DCX_BAL_TRAN_DUAL_FLAG));
    equal = equal && (this.RDT_DCX_PRIN_MISC_CHGS == null ? that.RDT_DCX_PRIN_MISC_CHGS == null : this.RDT_DCX_PRIN_MISC_CHGS.equals(that.RDT_DCX_PRIN_MISC_CHGS));
    equal = equal && (this.RDT_DCX_CR_LIFE_CHG_OFF == null ? that.RDT_DCX_CR_LIFE_CHG_OFF == null : this.RDT_DCX_CR_LIFE_CHG_OFF.equals(that.RDT_DCX_CR_LIFE_CHG_OFF));
    equal = equal && (this.RDT_DCX_ACCRUED_CASHINT == null ? that.RDT_DCX_ACCRUED_CASHINT == null : this.RDT_DCX_ACCRUED_CASHINT.equals(that.RDT_DCX_ACCRUED_CASHINT));
    equal = equal && (this.RDT_DCX_ACCRUED_MRCHINT == null ? that.RDT_DCX_ACCRUED_MRCHINT == null : this.RDT_DCX_ACCRUED_MRCHINT.equals(that.RDT_DCX_ACCRUED_MRCHINT));
    equal = equal && (this.RDT_DCX_BALANCE_CHG_OFF == null ? that.RDT_DCX_BALANCE_CHG_OFF == null : this.RDT_DCX_BALANCE_CHG_OFF.equals(that.RDT_DCX_BALANCE_CHG_OFF));
    equal = equal && (this.RDT_DCX_OLD_OPEN_BALANCE == null ? that.RDT_DCX_OLD_OPEN_BALANCE == null : this.RDT_DCX_OLD_OPEN_BALANCE.equals(that.RDT_DCX_OLD_OPEN_BALANCE));
    equal = equal && (this.RDT_DCX_ACCRUED_CRDINT == null ? that.RDT_DCX_ACCRUED_CRDINT == null : this.RDT_DCX_ACCRUED_CRDINT.equals(that.RDT_DCX_ACCRUED_CRDINT));
    equal = equal && (this.FILLER_3 == null ? that.FILLER_3 == null : this.FILLER_3.equals(that.FILLER_3));
    equal = equal && (this.RDT_DCX_ADDL == null ? that.RDT_DCX_ADDL == null : this.RDT_DCX_ADDL.equals(that.RDT_DCX_ADDL));
    equal = equal && (this.FILLER_3A == null ? that.FILLER_3A == null : this.FILLER_3A.equals(that.FILLER_3A));
    equal = equal && (this.FILLER_4 == null ? that.FILLER_4 == null : this.FILLER_4.equals(that.FILLER_4));
    equal = equal && (this.DTE_TME_ROW_ADDED == null ? that.DTE_TME_ROW_ADDED == null : this.DTE_TME_ROW_ADDED.equals(that.DTE_TME_ROW_ADDED));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.RDT_MONETARY_DCX_SEQ_NBR = JdbcWritableBridge.readLong(1, __dbResults);
    this.RDT_REC_CODE_KEY = JdbcWritableBridge.readString(2, __dbResults);
    this.RDT_REC_TYPE_CONTROL = JdbcWritableBridge.readString(3, __dbResults);
    this.RDT_NO_POST_REASON = JdbcWritableBridge.readInteger(4, __dbResults);
    this.RDT_SC_1 = JdbcWritableBridge.readString(5, __dbResults);
    this.RDT_SC_2 = JdbcWritableBridge.readString(6, __dbResults);
    this.RDT_SC_3 = JdbcWritableBridge.readString(7, __dbResults);
    this.RDT_SC_4 = JdbcWritableBridge.readString(8, __dbResults);
    this.RDT_SC_5 = JdbcWritableBridge.readString(9, __dbResults);
    this.RDT_SC_6 = JdbcWritableBridge.readString(10, __dbResults);
    this.RDT_SC_7 = JdbcWritableBridge.readString(11, __dbResults);
    this.RDT_SC_8 = JdbcWritableBridge.readString(12, __dbResults);
    this.RDT_CHD_SYSTEM_NO = JdbcWritableBridge.readString(13, __dbResults);
    this.RDT_CHD_PRIN_BANK = JdbcWritableBridge.readString(14, __dbResults);
    this.RDT_CHD_AGENT_BANK = JdbcWritableBridge.readString(15, __dbResults);
    this.RDT_CHD_ACCOUNT_NUMBER = JdbcWritableBridge.readString(16, __dbResults);
    this.RDT_TRANSACTION_CODE = JdbcWritableBridge.readInteger(17, __dbResults);
    this.RDT_MRCH_SYSTEM_NO = JdbcWritableBridge.readString(18, __dbResults);
    this.RDT_MRCH_PRIN_BANK = JdbcWritableBridge.readString(19, __dbResults);
    this.RDT_MRCH_AGENT_NO = JdbcWritableBridge.readString(20, __dbResults);
    this.RDT_MRCH_ACCOUNT_NUMBER = JdbcWritableBridge.readString(21, __dbResults);
    this.RDT_CHD_EXT_STATUS = JdbcWritableBridge.readString(22, __dbResults);
    this.RDT_CHD_INT_STATUS = JdbcWritableBridge.readString(23, __dbResults);
    this.RDT_TANI = JdbcWritableBridge.readString(24, __dbResults);
    this.RDT_TRANSFER_FLAG = JdbcWritableBridge.readString(25, __dbResults);
    this.RDT_ITEM_ASSES_CODE_NUM = JdbcWritableBridge.readInteger(26, __dbResults);
    this.RDT_MRCH_SIC_CODE = JdbcWritableBridge.readInteger(27, __dbResults);
    this.RDT_TRANSACTION_DATE = JdbcWritableBridge.readInteger(28, __dbResults);
    this.RDT_DCX_BATCH_TYPE = JdbcWritableBridge.readInteger(29, __dbResults);
    this.RDT_DCX_JULIAN_DATE = JdbcWritableBridge.readInteger(30, __dbResults);
    this.RDT_DCX_TYPE = JdbcWritableBridge.readString(31, __dbResults);
    this.RDT_DCX_SYS_4 = JdbcWritableBridge.readString(32, __dbResults);
    this.RDT_DCX_SYS_2 = JdbcWritableBridge.readString(33, __dbResults);
    this.RDT_DCX_DATE = JdbcWritableBridge.readString(34, __dbResults);
    this.RDT_DCX_2 = JdbcWritableBridge.readString(35, __dbResults);
    this.RDT_DCX_LAST_6 = JdbcWritableBridge.readString(36, __dbResults);
    this.RDT_DCX_ADJ_SALE_FEE_AM = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.FILLER_2 = JdbcWritableBridge.readString(38, __dbResults);
    this.RDT_DCX_MON_TRAN_JOURNAL_AMT = JdbcWritableBridge.readBigDecimal(39, __dbResults);
    this.RDT_DCX_AUDIT_TRAIL_DATE = JdbcWritableBridge.readInteger(40, __dbResults);
    this.RDT_DCX_PRIN_TOTAL = JdbcWritableBridge.readBigDecimal(41, __dbResults);
    this.RDT_DCX_PRIN_CASH = JdbcWritableBridge.readBigDecimal(42, __dbResults);
    this.RDT_DCX_PRIN_MRCH = JdbcWritableBridge.readBigDecimal(43, __dbResults);
    this.RDT_DCX_STMT_FIN_CHG_OFF = JdbcWritableBridge.readBigDecimal(44, __dbResults);
    this.RDT_DCX_MTJ_FIN_CHG_OFF = JdbcWritableBridge.readBigDecimal(45, __dbResults);
    this.RDT_DCX_BAL_TRAN_DUAL_FLAG = JdbcWritableBridge.readInteger(46, __dbResults);
    this.RDT_DCX_PRIN_MISC_CHGS = JdbcWritableBridge.readBigDecimal(47, __dbResults);
    this.RDT_DCX_CR_LIFE_CHG_OFF = JdbcWritableBridge.readBigDecimal(48, __dbResults);
    this.RDT_DCX_ACCRUED_CASHINT = JdbcWritableBridge.readBigDecimal(49, __dbResults);
    this.RDT_DCX_ACCRUED_MRCHINT = JdbcWritableBridge.readBigDecimal(50, __dbResults);
    this.RDT_DCX_BALANCE_CHG_OFF = JdbcWritableBridge.readBigDecimal(51, __dbResults);
    this.RDT_DCX_OLD_OPEN_BALANCE = JdbcWritableBridge.readBigDecimal(52, __dbResults);
    this.RDT_DCX_ACCRUED_CRDINT = JdbcWritableBridge.readBigDecimal(53, __dbResults);
    this.FILLER_3 = JdbcWritableBridge.readString(54, __dbResults);
    this.RDT_DCX_ADDL = JdbcWritableBridge.readInteger(55, __dbResults);
    this.FILLER_3A = JdbcWritableBridge.readString(56, __dbResults);
    this.FILLER_4 = JdbcWritableBridge.readString(57, __dbResults);
    this.DTE_TME_ROW_ADDED = JdbcWritableBridge.readTimestamp(58, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.RDT_MONETARY_DCX_SEQ_NBR = JdbcWritableBridge.readLong(1, __dbResults);
    this.RDT_REC_CODE_KEY = JdbcWritableBridge.readString(2, __dbResults);
    this.RDT_REC_TYPE_CONTROL = JdbcWritableBridge.readString(3, __dbResults);
    this.RDT_NO_POST_REASON = JdbcWritableBridge.readInteger(4, __dbResults);
    this.RDT_SC_1 = JdbcWritableBridge.readString(5, __dbResults);
    this.RDT_SC_2 = JdbcWritableBridge.readString(6, __dbResults);
    this.RDT_SC_3 = JdbcWritableBridge.readString(7, __dbResults);
    this.RDT_SC_4 = JdbcWritableBridge.readString(8, __dbResults);
    this.RDT_SC_5 = JdbcWritableBridge.readString(9, __dbResults);
    this.RDT_SC_6 = JdbcWritableBridge.readString(10, __dbResults);
    this.RDT_SC_7 = JdbcWritableBridge.readString(11, __dbResults);
    this.RDT_SC_8 = JdbcWritableBridge.readString(12, __dbResults);
    this.RDT_CHD_SYSTEM_NO = JdbcWritableBridge.readString(13, __dbResults);
    this.RDT_CHD_PRIN_BANK = JdbcWritableBridge.readString(14, __dbResults);
    this.RDT_CHD_AGENT_BANK = JdbcWritableBridge.readString(15, __dbResults);
    this.RDT_CHD_ACCOUNT_NUMBER = JdbcWritableBridge.readString(16, __dbResults);
    this.RDT_TRANSACTION_CODE = JdbcWritableBridge.readInteger(17, __dbResults);
    this.RDT_MRCH_SYSTEM_NO = JdbcWritableBridge.readString(18, __dbResults);
    this.RDT_MRCH_PRIN_BANK = JdbcWritableBridge.readString(19, __dbResults);
    this.RDT_MRCH_AGENT_NO = JdbcWritableBridge.readString(20, __dbResults);
    this.RDT_MRCH_ACCOUNT_NUMBER = JdbcWritableBridge.readString(21, __dbResults);
    this.RDT_CHD_EXT_STATUS = JdbcWritableBridge.readString(22, __dbResults);
    this.RDT_CHD_INT_STATUS = JdbcWritableBridge.readString(23, __dbResults);
    this.RDT_TANI = JdbcWritableBridge.readString(24, __dbResults);
    this.RDT_TRANSFER_FLAG = JdbcWritableBridge.readString(25, __dbResults);
    this.RDT_ITEM_ASSES_CODE_NUM = JdbcWritableBridge.readInteger(26, __dbResults);
    this.RDT_MRCH_SIC_CODE = JdbcWritableBridge.readInteger(27, __dbResults);
    this.RDT_TRANSACTION_DATE = JdbcWritableBridge.readInteger(28, __dbResults);
    this.RDT_DCX_BATCH_TYPE = JdbcWritableBridge.readInteger(29, __dbResults);
    this.RDT_DCX_JULIAN_DATE = JdbcWritableBridge.readInteger(30, __dbResults);
    this.RDT_DCX_TYPE = JdbcWritableBridge.readString(31, __dbResults);
    this.RDT_DCX_SYS_4 = JdbcWritableBridge.readString(32, __dbResults);
    this.RDT_DCX_SYS_2 = JdbcWritableBridge.readString(33, __dbResults);
    this.RDT_DCX_DATE = JdbcWritableBridge.readString(34, __dbResults);
    this.RDT_DCX_2 = JdbcWritableBridge.readString(35, __dbResults);
    this.RDT_DCX_LAST_6 = JdbcWritableBridge.readString(36, __dbResults);
    this.RDT_DCX_ADJ_SALE_FEE_AM = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.FILLER_2 = JdbcWritableBridge.readString(38, __dbResults);
    this.RDT_DCX_MON_TRAN_JOURNAL_AMT = JdbcWritableBridge.readBigDecimal(39, __dbResults);
    this.RDT_DCX_AUDIT_TRAIL_DATE = JdbcWritableBridge.readInteger(40, __dbResults);
    this.RDT_DCX_PRIN_TOTAL = JdbcWritableBridge.readBigDecimal(41, __dbResults);
    this.RDT_DCX_PRIN_CASH = JdbcWritableBridge.readBigDecimal(42, __dbResults);
    this.RDT_DCX_PRIN_MRCH = JdbcWritableBridge.readBigDecimal(43, __dbResults);
    this.RDT_DCX_STMT_FIN_CHG_OFF = JdbcWritableBridge.readBigDecimal(44, __dbResults);
    this.RDT_DCX_MTJ_FIN_CHG_OFF = JdbcWritableBridge.readBigDecimal(45, __dbResults);
    this.RDT_DCX_BAL_TRAN_DUAL_FLAG = JdbcWritableBridge.readInteger(46, __dbResults);
    this.RDT_DCX_PRIN_MISC_CHGS = JdbcWritableBridge.readBigDecimal(47, __dbResults);
    this.RDT_DCX_CR_LIFE_CHG_OFF = JdbcWritableBridge.readBigDecimal(48, __dbResults);
    this.RDT_DCX_ACCRUED_CASHINT = JdbcWritableBridge.readBigDecimal(49, __dbResults);
    this.RDT_DCX_ACCRUED_MRCHINT = JdbcWritableBridge.readBigDecimal(50, __dbResults);
    this.RDT_DCX_BALANCE_CHG_OFF = JdbcWritableBridge.readBigDecimal(51, __dbResults);
    this.RDT_DCX_OLD_OPEN_BALANCE = JdbcWritableBridge.readBigDecimal(52, __dbResults);
    this.RDT_DCX_ACCRUED_CRDINT = JdbcWritableBridge.readBigDecimal(53, __dbResults);
    this.FILLER_3 = JdbcWritableBridge.readString(54, __dbResults);
    this.RDT_DCX_ADDL = JdbcWritableBridge.readInteger(55, __dbResults);
    this.FILLER_3A = JdbcWritableBridge.readString(56, __dbResults);
    this.FILLER_4 = JdbcWritableBridge.readString(57, __dbResults);
    this.DTE_TME_ROW_ADDED = JdbcWritableBridge.readTimestamp(58, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeLong(RDT_MONETARY_DCX_SEQ_NBR, 1 + __off, -5, __dbStmt);
    JdbcWritableBridge.writeString(RDT_REC_CODE_KEY, 2 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_REC_TYPE_CONTROL, 3 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_NO_POST_REASON, 4 + __off, 5, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_1, 5 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_2, 6 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_3, 7 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_4, 8 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_5, 9 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_6, 10 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_7, 11 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_8, 12 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_CHD_SYSTEM_NO, 13 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_CHD_PRIN_BANK, 14 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_CHD_AGENT_BANK, 15 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_CHD_ACCOUNT_NUMBER, 16 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_TRANSACTION_CODE, 17 + __off, 5, __dbStmt);
    JdbcWritableBridge.writeString(RDT_MRCH_SYSTEM_NO, 18 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_MRCH_PRIN_BANK, 19 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_MRCH_AGENT_NO, 20 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_MRCH_ACCOUNT_NUMBER, 21 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_CHD_EXT_STATUS, 22 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_CHD_INT_STATUS, 23 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_TANI, 24 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_TRANSFER_FLAG, 25 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_ITEM_ASSES_CODE_NUM, 26 + __off, 5, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_MRCH_SIC_CODE, 27 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_TRANSACTION_DATE, 28 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_DCX_BATCH_TYPE, 29 + __off, 5, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_DCX_JULIAN_DATE, 30 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(RDT_DCX_TYPE, 31 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_DCX_SYS_4, 32 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_DCX_SYS_2, 33 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_DCX_DATE, 34 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_DCX_2, 35 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_DCX_LAST_6, 36 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_ADJ_SALE_FEE_AM, 37 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeString(FILLER_2, 38 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_MON_TRAN_JOURNAL_AMT, 39 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_DCX_AUDIT_TRAIL_DATE, 40 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_PRIN_TOTAL, 41 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_PRIN_CASH, 42 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_PRIN_MRCH, 43 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_STMT_FIN_CHG_OFF, 44 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_MTJ_FIN_CHG_OFF, 45 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_DCX_BAL_TRAN_DUAL_FLAG, 46 + __off, 5, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_PRIN_MISC_CHGS, 47 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_CR_LIFE_CHG_OFF, 48 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_ACCRUED_CASHINT, 49 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_ACCRUED_MRCHINT, 50 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_BALANCE_CHG_OFF, 51 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_OLD_OPEN_BALANCE, 52 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_ACCRUED_CRDINT, 53 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeString(FILLER_3, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_DCX_ADDL, 55 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(FILLER_3A, 56 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FILLER_4, 57 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(DTE_TME_ROW_ADDED, 58 + __off, 93, __dbStmt);
    return 58;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeLong(RDT_MONETARY_DCX_SEQ_NBR, 1 + __off, -5, __dbStmt);
    JdbcWritableBridge.writeString(RDT_REC_CODE_KEY, 2 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_REC_TYPE_CONTROL, 3 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_NO_POST_REASON, 4 + __off, 5, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_1, 5 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_2, 6 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_3, 7 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_4, 8 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_5, 9 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_6, 10 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_7, 11 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_SC_8, 12 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_CHD_SYSTEM_NO, 13 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_CHD_PRIN_BANK, 14 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_CHD_AGENT_BANK, 15 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_CHD_ACCOUNT_NUMBER, 16 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_TRANSACTION_CODE, 17 + __off, 5, __dbStmt);
    JdbcWritableBridge.writeString(RDT_MRCH_SYSTEM_NO, 18 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_MRCH_PRIN_BANK, 19 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_MRCH_AGENT_NO, 20 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_MRCH_ACCOUNT_NUMBER, 21 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_CHD_EXT_STATUS, 22 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_CHD_INT_STATUS, 23 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_TANI, 24 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_TRANSFER_FLAG, 25 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_ITEM_ASSES_CODE_NUM, 26 + __off, 5, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_MRCH_SIC_CODE, 27 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_TRANSACTION_DATE, 28 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_DCX_BATCH_TYPE, 29 + __off, 5, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_DCX_JULIAN_DATE, 30 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(RDT_DCX_TYPE, 31 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_DCX_SYS_4, 32 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_DCX_SYS_2, 33 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_DCX_DATE, 34 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_DCX_2, 35 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeString(RDT_DCX_LAST_6, 36 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_ADJ_SALE_FEE_AM, 37 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeString(FILLER_2, 38 + __off, 1, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_MON_TRAN_JOURNAL_AMT, 39 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_DCX_AUDIT_TRAIL_DATE, 40 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_PRIN_TOTAL, 41 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_PRIN_CASH, 42 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_PRIN_MRCH, 43 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_STMT_FIN_CHG_OFF, 44 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_MTJ_FIN_CHG_OFF, 45 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_DCX_BAL_TRAN_DUAL_FLAG, 46 + __off, 5, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_PRIN_MISC_CHGS, 47 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_CR_LIFE_CHG_OFF, 48 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_ACCRUED_CASHINT, 49 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_ACCRUED_MRCHINT, 50 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_BALANCE_CHG_OFF, 51 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_OLD_OPEN_BALANCE, 52 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RDT_DCX_ACCRUED_CRDINT, 53 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeString(FILLER_3, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeInteger(RDT_DCX_ADDL, 55 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(FILLER_3A, 56 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FILLER_4, 57 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(DTE_TME_ROW_ADDED, 58 + __off, 93, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.RDT_MONETARY_DCX_SEQ_NBR = null;
    } else {
    this.RDT_MONETARY_DCX_SEQ_NBR = Long.valueOf(__dataIn.readLong());
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_REC_CODE_KEY = null;
    } else {
    this.RDT_REC_CODE_KEY = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_REC_TYPE_CONTROL = null;
    } else {
    this.RDT_REC_TYPE_CONTROL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_NO_POST_REASON = null;
    } else {
    this.RDT_NO_POST_REASON = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_SC_1 = null;
    } else {
    this.RDT_SC_1 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_SC_2 = null;
    } else {
    this.RDT_SC_2 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_SC_3 = null;
    } else {
    this.RDT_SC_3 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_SC_4 = null;
    } else {
    this.RDT_SC_4 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_SC_5 = null;
    } else {
    this.RDT_SC_5 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_SC_6 = null;
    } else {
    this.RDT_SC_6 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_SC_7 = null;
    } else {
    this.RDT_SC_7 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_SC_8 = null;
    } else {
    this.RDT_SC_8 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_CHD_SYSTEM_NO = null;
    } else {
    this.RDT_CHD_SYSTEM_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_CHD_PRIN_BANK = null;
    } else {
    this.RDT_CHD_PRIN_BANK = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_CHD_AGENT_BANK = null;
    } else {
    this.RDT_CHD_AGENT_BANK = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_CHD_ACCOUNT_NUMBER = null;
    } else {
    this.RDT_CHD_ACCOUNT_NUMBER = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_TRANSACTION_CODE = null;
    } else {
    this.RDT_TRANSACTION_CODE = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_MRCH_SYSTEM_NO = null;
    } else {
    this.RDT_MRCH_SYSTEM_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_MRCH_PRIN_BANK = null;
    } else {
    this.RDT_MRCH_PRIN_BANK = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_MRCH_AGENT_NO = null;
    } else {
    this.RDT_MRCH_AGENT_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_MRCH_ACCOUNT_NUMBER = null;
    } else {
    this.RDT_MRCH_ACCOUNT_NUMBER = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_CHD_EXT_STATUS = null;
    } else {
    this.RDT_CHD_EXT_STATUS = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_CHD_INT_STATUS = null;
    } else {
    this.RDT_CHD_INT_STATUS = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_TANI = null;
    } else {
    this.RDT_TANI = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_TRANSFER_FLAG = null;
    } else {
    this.RDT_TRANSFER_FLAG = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_ITEM_ASSES_CODE_NUM = null;
    } else {
    this.RDT_ITEM_ASSES_CODE_NUM = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_MRCH_SIC_CODE = null;
    } else {
    this.RDT_MRCH_SIC_CODE = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_TRANSACTION_DATE = null;
    } else {
    this.RDT_TRANSACTION_DATE = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_BATCH_TYPE = null;
    } else {
    this.RDT_DCX_BATCH_TYPE = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_JULIAN_DATE = null;
    } else {
    this.RDT_DCX_JULIAN_DATE = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_TYPE = null;
    } else {
    this.RDT_DCX_TYPE = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_SYS_4 = null;
    } else {
    this.RDT_DCX_SYS_4 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_SYS_2 = null;
    } else {
    this.RDT_DCX_SYS_2 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_DATE = null;
    } else {
    this.RDT_DCX_DATE = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_2 = null;
    } else {
    this.RDT_DCX_2 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_LAST_6 = null;
    } else {
    this.RDT_DCX_LAST_6 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_ADJ_SALE_FEE_AM = null;
    } else {
    this.RDT_DCX_ADJ_SALE_FEE_AM = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.FILLER_2 = null;
    } else {
    this.FILLER_2 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_MON_TRAN_JOURNAL_AMT = null;
    } else {
    this.RDT_DCX_MON_TRAN_JOURNAL_AMT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_AUDIT_TRAIL_DATE = null;
    } else {
    this.RDT_DCX_AUDIT_TRAIL_DATE = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_PRIN_TOTAL = null;
    } else {
    this.RDT_DCX_PRIN_TOTAL = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_PRIN_CASH = null;
    } else {
    this.RDT_DCX_PRIN_CASH = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_PRIN_MRCH = null;
    } else {
    this.RDT_DCX_PRIN_MRCH = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_STMT_FIN_CHG_OFF = null;
    } else {
    this.RDT_DCX_STMT_FIN_CHG_OFF = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_MTJ_FIN_CHG_OFF = null;
    } else {
    this.RDT_DCX_MTJ_FIN_CHG_OFF = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_BAL_TRAN_DUAL_FLAG = null;
    } else {
    this.RDT_DCX_BAL_TRAN_DUAL_FLAG = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_PRIN_MISC_CHGS = null;
    } else {
    this.RDT_DCX_PRIN_MISC_CHGS = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_CR_LIFE_CHG_OFF = null;
    } else {
    this.RDT_DCX_CR_LIFE_CHG_OFF = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_ACCRUED_CASHINT = null;
    } else {
    this.RDT_DCX_ACCRUED_CASHINT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_ACCRUED_MRCHINT = null;
    } else {
    this.RDT_DCX_ACCRUED_MRCHINT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_BALANCE_CHG_OFF = null;
    } else {
    this.RDT_DCX_BALANCE_CHG_OFF = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_OLD_OPEN_BALANCE = null;
    } else {
    this.RDT_DCX_OLD_OPEN_BALANCE = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_ACCRUED_CRDINT = null;
    } else {
    this.RDT_DCX_ACCRUED_CRDINT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.FILLER_3 = null;
    } else {
    this.FILLER_3 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDT_DCX_ADDL = null;
    } else {
    this.RDT_DCX_ADDL = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.FILLER_3A = null;
    } else {
    this.FILLER_3A = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.FILLER_4 = null;
    } else {
    this.FILLER_4 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DTE_TME_ROW_ADDED = null;
    } else {
    this.DTE_TME_ROW_ADDED = new Timestamp(__dataIn.readLong());
    this.DTE_TME_ROW_ADDED.setNanos(__dataIn.readInt());
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.RDT_MONETARY_DCX_SEQ_NBR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.RDT_MONETARY_DCX_SEQ_NBR);
    }
    if (null == this.RDT_REC_CODE_KEY) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_REC_CODE_KEY);
    }
    if (null == this.RDT_REC_TYPE_CONTROL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_REC_TYPE_CONTROL);
    }
    if (null == this.RDT_NO_POST_REASON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_NO_POST_REASON);
    }
    if (null == this.RDT_SC_1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_1);
    }
    if (null == this.RDT_SC_2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_2);
    }
    if (null == this.RDT_SC_3) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_3);
    }
    if (null == this.RDT_SC_4) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_4);
    }
    if (null == this.RDT_SC_5) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_5);
    }
    if (null == this.RDT_SC_6) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_6);
    }
    if (null == this.RDT_SC_7) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_7);
    }
    if (null == this.RDT_SC_8) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_8);
    }
    if (null == this.RDT_CHD_SYSTEM_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_CHD_SYSTEM_NO);
    }
    if (null == this.RDT_CHD_PRIN_BANK) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_CHD_PRIN_BANK);
    }
    if (null == this.RDT_CHD_AGENT_BANK) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_CHD_AGENT_BANK);
    }
    if (null == this.RDT_CHD_ACCOUNT_NUMBER) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_CHD_ACCOUNT_NUMBER);
    }
    if (null == this.RDT_TRANSACTION_CODE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_TRANSACTION_CODE);
    }
    if (null == this.RDT_MRCH_SYSTEM_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_MRCH_SYSTEM_NO);
    }
    if (null == this.RDT_MRCH_PRIN_BANK) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_MRCH_PRIN_BANK);
    }
    if (null == this.RDT_MRCH_AGENT_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_MRCH_AGENT_NO);
    }
    if (null == this.RDT_MRCH_ACCOUNT_NUMBER) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_MRCH_ACCOUNT_NUMBER);
    }
    if (null == this.RDT_CHD_EXT_STATUS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_CHD_EXT_STATUS);
    }
    if (null == this.RDT_CHD_INT_STATUS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_CHD_INT_STATUS);
    }
    if (null == this.RDT_TANI) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_TANI);
    }
    if (null == this.RDT_TRANSFER_FLAG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_TRANSFER_FLAG);
    }
    if (null == this.RDT_ITEM_ASSES_CODE_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_ITEM_ASSES_CODE_NUM);
    }
    if (null == this.RDT_MRCH_SIC_CODE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_MRCH_SIC_CODE);
    }
    if (null == this.RDT_TRANSACTION_DATE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_TRANSACTION_DATE);
    }
    if (null == this.RDT_DCX_BATCH_TYPE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_DCX_BATCH_TYPE);
    }
    if (null == this.RDT_DCX_JULIAN_DATE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_DCX_JULIAN_DATE);
    }
    if (null == this.RDT_DCX_TYPE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_DCX_TYPE);
    }
    if (null == this.RDT_DCX_SYS_4) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_DCX_SYS_4);
    }
    if (null == this.RDT_DCX_SYS_2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_DCX_SYS_2);
    }
    if (null == this.RDT_DCX_DATE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_DCX_DATE);
    }
    if (null == this.RDT_DCX_2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_DCX_2);
    }
    if (null == this.RDT_DCX_LAST_6) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_DCX_LAST_6);
    }
    if (null == this.RDT_DCX_ADJ_SALE_FEE_AM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_ADJ_SALE_FEE_AM, __dataOut);
    }
    if (null == this.FILLER_2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FILLER_2);
    }
    if (null == this.RDT_DCX_MON_TRAN_JOURNAL_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_MON_TRAN_JOURNAL_AMT, __dataOut);
    }
    if (null == this.RDT_DCX_AUDIT_TRAIL_DATE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_DCX_AUDIT_TRAIL_DATE);
    }
    if (null == this.RDT_DCX_PRIN_TOTAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_PRIN_TOTAL, __dataOut);
    }
    if (null == this.RDT_DCX_PRIN_CASH) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_PRIN_CASH, __dataOut);
    }
    if (null == this.RDT_DCX_PRIN_MRCH) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_PRIN_MRCH, __dataOut);
    }
    if (null == this.RDT_DCX_STMT_FIN_CHG_OFF) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_STMT_FIN_CHG_OFF, __dataOut);
    }
    if (null == this.RDT_DCX_MTJ_FIN_CHG_OFF) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_MTJ_FIN_CHG_OFF, __dataOut);
    }
    if (null == this.RDT_DCX_BAL_TRAN_DUAL_FLAG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_DCX_BAL_TRAN_DUAL_FLAG);
    }
    if (null == this.RDT_DCX_PRIN_MISC_CHGS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_PRIN_MISC_CHGS, __dataOut);
    }
    if (null == this.RDT_DCX_CR_LIFE_CHG_OFF) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_CR_LIFE_CHG_OFF, __dataOut);
    }
    if (null == this.RDT_DCX_ACCRUED_CASHINT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_ACCRUED_CASHINT, __dataOut);
    }
    if (null == this.RDT_DCX_ACCRUED_MRCHINT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_ACCRUED_MRCHINT, __dataOut);
    }
    if (null == this.RDT_DCX_BALANCE_CHG_OFF) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_BALANCE_CHG_OFF, __dataOut);
    }
    if (null == this.RDT_DCX_OLD_OPEN_BALANCE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_OLD_OPEN_BALANCE, __dataOut);
    }
    if (null == this.RDT_DCX_ACCRUED_CRDINT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_ACCRUED_CRDINT, __dataOut);
    }
    if (null == this.FILLER_3) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FILLER_3);
    }
    if (null == this.RDT_DCX_ADDL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_DCX_ADDL);
    }
    if (null == this.FILLER_3A) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FILLER_3A);
    }
    if (null == this.FILLER_4) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FILLER_4);
    }
    if (null == this.DTE_TME_ROW_ADDED) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.DTE_TME_ROW_ADDED.getTime());
    __dataOut.writeInt(this.DTE_TME_ROW_ADDED.getNanos());
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.RDT_MONETARY_DCX_SEQ_NBR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.RDT_MONETARY_DCX_SEQ_NBR);
    }
    if (null == this.RDT_REC_CODE_KEY) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_REC_CODE_KEY);
    }
    if (null == this.RDT_REC_TYPE_CONTROL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_REC_TYPE_CONTROL);
    }
    if (null == this.RDT_NO_POST_REASON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_NO_POST_REASON);
    }
    if (null == this.RDT_SC_1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_1);
    }
    if (null == this.RDT_SC_2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_2);
    }
    if (null == this.RDT_SC_3) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_3);
    }
    if (null == this.RDT_SC_4) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_4);
    }
    if (null == this.RDT_SC_5) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_5);
    }
    if (null == this.RDT_SC_6) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_6);
    }
    if (null == this.RDT_SC_7) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_7);
    }
    if (null == this.RDT_SC_8) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_SC_8);
    }
    if (null == this.RDT_CHD_SYSTEM_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_CHD_SYSTEM_NO);
    }
    if (null == this.RDT_CHD_PRIN_BANK) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_CHD_PRIN_BANK);
    }
    if (null == this.RDT_CHD_AGENT_BANK) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_CHD_AGENT_BANK);
    }
    if (null == this.RDT_CHD_ACCOUNT_NUMBER) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_CHD_ACCOUNT_NUMBER);
    }
    if (null == this.RDT_TRANSACTION_CODE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_TRANSACTION_CODE);
    }
    if (null == this.RDT_MRCH_SYSTEM_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_MRCH_SYSTEM_NO);
    }
    if (null == this.RDT_MRCH_PRIN_BANK) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_MRCH_PRIN_BANK);
    }
    if (null == this.RDT_MRCH_AGENT_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_MRCH_AGENT_NO);
    }
    if (null == this.RDT_MRCH_ACCOUNT_NUMBER) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_MRCH_ACCOUNT_NUMBER);
    }
    if (null == this.RDT_CHD_EXT_STATUS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_CHD_EXT_STATUS);
    }
    if (null == this.RDT_CHD_INT_STATUS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_CHD_INT_STATUS);
    }
    if (null == this.RDT_TANI) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_TANI);
    }
    if (null == this.RDT_TRANSFER_FLAG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_TRANSFER_FLAG);
    }
    if (null == this.RDT_ITEM_ASSES_CODE_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_ITEM_ASSES_CODE_NUM);
    }
    if (null == this.RDT_MRCH_SIC_CODE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_MRCH_SIC_CODE);
    }
    if (null == this.RDT_TRANSACTION_DATE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_TRANSACTION_DATE);
    }
    if (null == this.RDT_DCX_BATCH_TYPE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_DCX_BATCH_TYPE);
    }
    if (null == this.RDT_DCX_JULIAN_DATE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_DCX_JULIAN_DATE);
    }
    if (null == this.RDT_DCX_TYPE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_DCX_TYPE);
    }
    if (null == this.RDT_DCX_SYS_4) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_DCX_SYS_4);
    }
    if (null == this.RDT_DCX_SYS_2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_DCX_SYS_2);
    }
    if (null == this.RDT_DCX_DATE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_DCX_DATE);
    }
    if (null == this.RDT_DCX_2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_DCX_2);
    }
    if (null == this.RDT_DCX_LAST_6) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDT_DCX_LAST_6);
    }
    if (null == this.RDT_DCX_ADJ_SALE_FEE_AM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_ADJ_SALE_FEE_AM, __dataOut);
    }
    if (null == this.FILLER_2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FILLER_2);
    }
    if (null == this.RDT_DCX_MON_TRAN_JOURNAL_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_MON_TRAN_JOURNAL_AMT, __dataOut);
    }
    if (null == this.RDT_DCX_AUDIT_TRAIL_DATE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_DCX_AUDIT_TRAIL_DATE);
    }
    if (null == this.RDT_DCX_PRIN_TOTAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_PRIN_TOTAL, __dataOut);
    }
    if (null == this.RDT_DCX_PRIN_CASH) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_PRIN_CASH, __dataOut);
    }
    if (null == this.RDT_DCX_PRIN_MRCH) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_PRIN_MRCH, __dataOut);
    }
    if (null == this.RDT_DCX_STMT_FIN_CHG_OFF) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_STMT_FIN_CHG_OFF, __dataOut);
    }
    if (null == this.RDT_DCX_MTJ_FIN_CHG_OFF) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_MTJ_FIN_CHG_OFF, __dataOut);
    }
    if (null == this.RDT_DCX_BAL_TRAN_DUAL_FLAG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_DCX_BAL_TRAN_DUAL_FLAG);
    }
    if (null == this.RDT_DCX_PRIN_MISC_CHGS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_PRIN_MISC_CHGS, __dataOut);
    }
    if (null == this.RDT_DCX_CR_LIFE_CHG_OFF) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_CR_LIFE_CHG_OFF, __dataOut);
    }
    if (null == this.RDT_DCX_ACCRUED_CASHINT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_ACCRUED_CASHINT, __dataOut);
    }
    if (null == this.RDT_DCX_ACCRUED_MRCHINT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_ACCRUED_MRCHINT, __dataOut);
    }
    if (null == this.RDT_DCX_BALANCE_CHG_OFF) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_BALANCE_CHG_OFF, __dataOut);
    }
    if (null == this.RDT_DCX_OLD_OPEN_BALANCE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_OLD_OPEN_BALANCE, __dataOut);
    }
    if (null == this.RDT_DCX_ACCRUED_CRDINT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.RDT_DCX_ACCRUED_CRDINT, __dataOut);
    }
    if (null == this.FILLER_3) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FILLER_3);
    }
    if (null == this.RDT_DCX_ADDL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.RDT_DCX_ADDL);
    }
    if (null == this.FILLER_3A) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FILLER_3A);
    }
    if (null == this.FILLER_4) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FILLER_4);
    }
    if (null == this.DTE_TME_ROW_ADDED) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.DTE_TME_ROW_ADDED.getTime());
    __dataOut.writeInt(this.DTE_TME_ROW_ADDED.getNanos());
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_MONETARY_DCX_SEQ_NBR==null?"null":"" + RDT_MONETARY_DCX_SEQ_NBR, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_REC_CODE_KEY==null?"null":RDT_REC_CODE_KEY, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_REC_TYPE_CONTROL==null?"null":RDT_REC_TYPE_CONTROL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_NO_POST_REASON==null?"null":"" + RDT_NO_POST_REASON, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_1==null?"null":RDT_SC_1, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_2==null?"null":RDT_SC_2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_3==null?"null":RDT_SC_3, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_4==null?"null":RDT_SC_4, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_5==null?"null":RDT_SC_5, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_6==null?"null":RDT_SC_6, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_7==null?"null":RDT_SC_7, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_8==null?"null":RDT_SC_8, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_CHD_SYSTEM_NO==null?"null":RDT_CHD_SYSTEM_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_CHD_PRIN_BANK==null?"null":RDT_CHD_PRIN_BANK, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_CHD_AGENT_BANK==null?"null":RDT_CHD_AGENT_BANK, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_CHD_ACCOUNT_NUMBER==null?"null":RDT_CHD_ACCOUNT_NUMBER, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_TRANSACTION_CODE==null?"null":"" + RDT_TRANSACTION_CODE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_MRCH_SYSTEM_NO==null?"null":RDT_MRCH_SYSTEM_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_MRCH_PRIN_BANK==null?"null":RDT_MRCH_PRIN_BANK, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_MRCH_AGENT_NO==null?"null":RDT_MRCH_AGENT_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_MRCH_ACCOUNT_NUMBER==null?"null":RDT_MRCH_ACCOUNT_NUMBER, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_CHD_EXT_STATUS==null?"null":RDT_CHD_EXT_STATUS, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_CHD_INT_STATUS==null?"null":RDT_CHD_INT_STATUS, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_TANI==null?"null":RDT_TANI, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_TRANSFER_FLAG==null?"null":RDT_TRANSFER_FLAG, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_ITEM_ASSES_CODE_NUM==null?"null":"" + RDT_ITEM_ASSES_CODE_NUM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_MRCH_SIC_CODE==null?"null":"" + RDT_MRCH_SIC_CODE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_TRANSACTION_DATE==null?"null":"" + RDT_TRANSACTION_DATE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_BATCH_TYPE==null?"null":"" + RDT_DCX_BATCH_TYPE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_JULIAN_DATE==null?"null":"" + RDT_DCX_JULIAN_DATE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_TYPE==null?"null":RDT_DCX_TYPE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_SYS_4==null?"null":RDT_DCX_SYS_4, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_SYS_2==null?"null":RDT_DCX_SYS_2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_DATE==null?"null":RDT_DCX_DATE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_2==null?"null":RDT_DCX_2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_LAST_6==null?"null":RDT_DCX_LAST_6, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_ADJ_SALE_FEE_AM==null?"null":RDT_DCX_ADJ_SALE_FEE_AM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FILLER_2==null?"null":FILLER_2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_MON_TRAN_JOURNAL_AMT==null?"null":RDT_DCX_MON_TRAN_JOURNAL_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_AUDIT_TRAIL_DATE==null?"null":"" + RDT_DCX_AUDIT_TRAIL_DATE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_PRIN_TOTAL==null?"null":RDT_DCX_PRIN_TOTAL.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_PRIN_CASH==null?"null":RDT_DCX_PRIN_CASH.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_PRIN_MRCH==null?"null":RDT_DCX_PRIN_MRCH.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_STMT_FIN_CHG_OFF==null?"null":RDT_DCX_STMT_FIN_CHG_OFF.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_MTJ_FIN_CHG_OFF==null?"null":RDT_DCX_MTJ_FIN_CHG_OFF.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_BAL_TRAN_DUAL_FLAG==null?"null":"" + RDT_DCX_BAL_TRAN_DUAL_FLAG, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_PRIN_MISC_CHGS==null?"null":RDT_DCX_PRIN_MISC_CHGS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_CR_LIFE_CHG_OFF==null?"null":RDT_DCX_CR_LIFE_CHG_OFF.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_ACCRUED_CASHINT==null?"null":RDT_DCX_ACCRUED_CASHINT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_ACCRUED_MRCHINT==null?"null":RDT_DCX_ACCRUED_MRCHINT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_BALANCE_CHG_OFF==null?"null":RDT_DCX_BALANCE_CHG_OFF.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_OLD_OPEN_BALANCE==null?"null":RDT_DCX_OLD_OPEN_BALANCE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_ACCRUED_CRDINT==null?"null":RDT_DCX_ACCRUED_CRDINT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FILLER_3==null?"null":FILLER_3, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_ADDL==null?"null":"" + RDT_DCX_ADDL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FILLER_3A==null?"null":FILLER_3A, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FILLER_4==null?"null":FILLER_4, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DTE_TME_ROW_ADDED==null?"null":"" + DTE_TME_ROW_ADDED, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_MONETARY_DCX_SEQ_NBR==null?"null":"" + RDT_MONETARY_DCX_SEQ_NBR, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_REC_CODE_KEY==null?"null":RDT_REC_CODE_KEY, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_REC_TYPE_CONTROL==null?"null":RDT_REC_TYPE_CONTROL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_NO_POST_REASON==null?"null":"" + RDT_NO_POST_REASON, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_1==null?"null":RDT_SC_1, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_2==null?"null":RDT_SC_2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_3==null?"null":RDT_SC_3, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_4==null?"null":RDT_SC_4, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_5==null?"null":RDT_SC_5, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_6==null?"null":RDT_SC_6, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_7==null?"null":RDT_SC_7, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_SC_8==null?"null":RDT_SC_8, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_CHD_SYSTEM_NO==null?"null":RDT_CHD_SYSTEM_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_CHD_PRIN_BANK==null?"null":RDT_CHD_PRIN_BANK, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_CHD_AGENT_BANK==null?"null":RDT_CHD_AGENT_BANK, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_CHD_ACCOUNT_NUMBER==null?"null":RDT_CHD_ACCOUNT_NUMBER, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_TRANSACTION_CODE==null?"null":"" + RDT_TRANSACTION_CODE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_MRCH_SYSTEM_NO==null?"null":RDT_MRCH_SYSTEM_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_MRCH_PRIN_BANK==null?"null":RDT_MRCH_PRIN_BANK, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_MRCH_AGENT_NO==null?"null":RDT_MRCH_AGENT_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_MRCH_ACCOUNT_NUMBER==null?"null":RDT_MRCH_ACCOUNT_NUMBER, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_CHD_EXT_STATUS==null?"null":RDT_CHD_EXT_STATUS, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_CHD_INT_STATUS==null?"null":RDT_CHD_INT_STATUS, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_TANI==null?"null":RDT_TANI, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_TRANSFER_FLAG==null?"null":RDT_TRANSFER_FLAG, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_ITEM_ASSES_CODE_NUM==null?"null":"" + RDT_ITEM_ASSES_CODE_NUM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_MRCH_SIC_CODE==null?"null":"" + RDT_MRCH_SIC_CODE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_TRANSACTION_DATE==null?"null":"" + RDT_TRANSACTION_DATE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_BATCH_TYPE==null?"null":"" + RDT_DCX_BATCH_TYPE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_JULIAN_DATE==null?"null":"" + RDT_DCX_JULIAN_DATE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_TYPE==null?"null":RDT_DCX_TYPE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_SYS_4==null?"null":RDT_DCX_SYS_4, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_SYS_2==null?"null":RDT_DCX_SYS_2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_DATE==null?"null":RDT_DCX_DATE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_2==null?"null":RDT_DCX_2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_LAST_6==null?"null":RDT_DCX_LAST_6, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_ADJ_SALE_FEE_AM==null?"null":RDT_DCX_ADJ_SALE_FEE_AM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FILLER_2==null?"null":FILLER_2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_MON_TRAN_JOURNAL_AMT==null?"null":RDT_DCX_MON_TRAN_JOURNAL_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_AUDIT_TRAIL_DATE==null?"null":"" + RDT_DCX_AUDIT_TRAIL_DATE, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_PRIN_TOTAL==null?"null":RDT_DCX_PRIN_TOTAL.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_PRIN_CASH==null?"null":RDT_DCX_PRIN_CASH.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_PRIN_MRCH==null?"null":RDT_DCX_PRIN_MRCH.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_STMT_FIN_CHG_OFF==null?"null":RDT_DCX_STMT_FIN_CHG_OFF.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_MTJ_FIN_CHG_OFF==null?"null":RDT_DCX_MTJ_FIN_CHG_OFF.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_BAL_TRAN_DUAL_FLAG==null?"null":"" + RDT_DCX_BAL_TRAN_DUAL_FLAG, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_PRIN_MISC_CHGS==null?"null":RDT_DCX_PRIN_MISC_CHGS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_CR_LIFE_CHG_OFF==null?"null":RDT_DCX_CR_LIFE_CHG_OFF.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_ACCRUED_CASHINT==null?"null":RDT_DCX_ACCRUED_CASHINT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_ACCRUED_MRCHINT==null?"null":RDT_DCX_ACCRUED_MRCHINT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_BALANCE_CHG_OFF==null?"null":RDT_DCX_BALANCE_CHG_OFF.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_OLD_OPEN_BALANCE==null?"null":RDT_DCX_OLD_OPEN_BALANCE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_ACCRUED_CRDINT==null?"null":RDT_DCX_ACCRUED_CRDINT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FILLER_3==null?"null":FILLER_3, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDT_DCX_ADDL==null?"null":"" + RDT_DCX_ADDL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FILLER_3A==null?"null":FILLER_3A, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FILLER_4==null?"null":FILLER_4, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DTE_TME_ROW_ADDED==null?"null":"" + DTE_TME_ROW_ADDED, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_MONETARY_DCX_SEQ_NBR = null; } else {
      this.RDT_MONETARY_DCX_SEQ_NBR = Long.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_REC_CODE_KEY = null; } else {
      this.RDT_REC_CODE_KEY = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_REC_TYPE_CONTROL = null; } else {
      this.RDT_REC_TYPE_CONTROL = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_NO_POST_REASON = null; } else {
      this.RDT_NO_POST_REASON = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_1 = null; } else {
      this.RDT_SC_1 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_2 = null; } else {
      this.RDT_SC_2 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_3 = null; } else {
      this.RDT_SC_3 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_4 = null; } else {
      this.RDT_SC_4 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_5 = null; } else {
      this.RDT_SC_5 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_6 = null; } else {
      this.RDT_SC_6 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_7 = null; } else {
      this.RDT_SC_7 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_8 = null; } else {
      this.RDT_SC_8 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_CHD_SYSTEM_NO = null; } else {
      this.RDT_CHD_SYSTEM_NO = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_CHD_PRIN_BANK = null; } else {
      this.RDT_CHD_PRIN_BANK = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_CHD_AGENT_BANK = null; } else {
      this.RDT_CHD_AGENT_BANK = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_CHD_ACCOUNT_NUMBER = null; } else {
      this.RDT_CHD_ACCOUNT_NUMBER = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_TRANSACTION_CODE = null; } else {
      this.RDT_TRANSACTION_CODE = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_MRCH_SYSTEM_NO = null; } else {
      this.RDT_MRCH_SYSTEM_NO = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_MRCH_PRIN_BANK = null; } else {
      this.RDT_MRCH_PRIN_BANK = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_MRCH_AGENT_NO = null; } else {
      this.RDT_MRCH_AGENT_NO = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_MRCH_ACCOUNT_NUMBER = null; } else {
      this.RDT_MRCH_ACCOUNT_NUMBER = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_CHD_EXT_STATUS = null; } else {
      this.RDT_CHD_EXT_STATUS = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_CHD_INT_STATUS = null; } else {
      this.RDT_CHD_INT_STATUS = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_TANI = null; } else {
      this.RDT_TANI = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_TRANSFER_FLAG = null; } else {
      this.RDT_TRANSFER_FLAG = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_ITEM_ASSES_CODE_NUM = null; } else {
      this.RDT_ITEM_ASSES_CODE_NUM = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_MRCH_SIC_CODE = null; } else {
      this.RDT_MRCH_SIC_CODE = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_TRANSACTION_DATE = null; } else {
      this.RDT_TRANSACTION_DATE = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_BATCH_TYPE = null; } else {
      this.RDT_DCX_BATCH_TYPE = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_JULIAN_DATE = null; } else {
      this.RDT_DCX_JULIAN_DATE = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_DCX_TYPE = null; } else {
      this.RDT_DCX_TYPE = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_DCX_SYS_4 = null; } else {
      this.RDT_DCX_SYS_4 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_DCX_SYS_2 = null; } else {
      this.RDT_DCX_SYS_2 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_DCX_DATE = null; } else {
      this.RDT_DCX_DATE = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_DCX_2 = null; } else {
      this.RDT_DCX_2 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_DCX_LAST_6 = null; } else {
      this.RDT_DCX_LAST_6 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_ADJ_SALE_FEE_AM = null; } else {
      this.RDT_DCX_ADJ_SALE_FEE_AM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.FILLER_2 = null; } else {
      this.FILLER_2 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_MON_TRAN_JOURNAL_AMT = null; } else {
      this.RDT_DCX_MON_TRAN_JOURNAL_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_AUDIT_TRAIL_DATE = null; } else {
      this.RDT_DCX_AUDIT_TRAIL_DATE = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_PRIN_TOTAL = null; } else {
      this.RDT_DCX_PRIN_TOTAL = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_PRIN_CASH = null; } else {
      this.RDT_DCX_PRIN_CASH = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_PRIN_MRCH = null; } else {
      this.RDT_DCX_PRIN_MRCH = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_STMT_FIN_CHG_OFF = null; } else {
      this.RDT_DCX_STMT_FIN_CHG_OFF = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_MTJ_FIN_CHG_OFF = null; } else {
      this.RDT_DCX_MTJ_FIN_CHG_OFF = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_BAL_TRAN_DUAL_FLAG = null; } else {
      this.RDT_DCX_BAL_TRAN_DUAL_FLAG = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_PRIN_MISC_CHGS = null; } else {
      this.RDT_DCX_PRIN_MISC_CHGS = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_CR_LIFE_CHG_OFF = null; } else {
      this.RDT_DCX_CR_LIFE_CHG_OFF = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_ACCRUED_CASHINT = null; } else {
      this.RDT_DCX_ACCRUED_CASHINT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_ACCRUED_MRCHINT = null; } else {
      this.RDT_DCX_ACCRUED_MRCHINT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_BALANCE_CHG_OFF = null; } else {
      this.RDT_DCX_BALANCE_CHG_OFF = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_OLD_OPEN_BALANCE = null; } else {
      this.RDT_DCX_OLD_OPEN_BALANCE = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_ACCRUED_CRDINT = null; } else {
      this.RDT_DCX_ACCRUED_CRDINT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.FILLER_3 = null; } else {
      this.FILLER_3 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_ADDL = null; } else {
      this.RDT_DCX_ADDL = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.FILLER_3A = null; } else {
      this.FILLER_3A = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.FILLER_4 = null; } else {
      this.FILLER_4 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DTE_TME_ROW_ADDED = null; } else {
      this.DTE_TME_ROW_ADDED = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_MONETARY_DCX_SEQ_NBR = null; } else {
      this.RDT_MONETARY_DCX_SEQ_NBR = Long.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_REC_CODE_KEY = null; } else {
      this.RDT_REC_CODE_KEY = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_REC_TYPE_CONTROL = null; } else {
      this.RDT_REC_TYPE_CONTROL = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_NO_POST_REASON = null; } else {
      this.RDT_NO_POST_REASON = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_1 = null; } else {
      this.RDT_SC_1 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_2 = null; } else {
      this.RDT_SC_2 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_3 = null; } else {
      this.RDT_SC_3 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_4 = null; } else {
      this.RDT_SC_4 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_5 = null; } else {
      this.RDT_SC_5 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_6 = null; } else {
      this.RDT_SC_6 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_7 = null; } else {
      this.RDT_SC_7 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_SC_8 = null; } else {
      this.RDT_SC_8 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_CHD_SYSTEM_NO = null; } else {
      this.RDT_CHD_SYSTEM_NO = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_CHD_PRIN_BANK = null; } else {
      this.RDT_CHD_PRIN_BANK = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_CHD_AGENT_BANK = null; } else {
      this.RDT_CHD_AGENT_BANK = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_CHD_ACCOUNT_NUMBER = null; } else {
      this.RDT_CHD_ACCOUNT_NUMBER = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_TRANSACTION_CODE = null; } else {
      this.RDT_TRANSACTION_CODE = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_MRCH_SYSTEM_NO = null; } else {
      this.RDT_MRCH_SYSTEM_NO = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_MRCH_PRIN_BANK = null; } else {
      this.RDT_MRCH_PRIN_BANK = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_MRCH_AGENT_NO = null; } else {
      this.RDT_MRCH_AGENT_NO = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_MRCH_ACCOUNT_NUMBER = null; } else {
      this.RDT_MRCH_ACCOUNT_NUMBER = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_CHD_EXT_STATUS = null; } else {
      this.RDT_CHD_EXT_STATUS = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_CHD_INT_STATUS = null; } else {
      this.RDT_CHD_INT_STATUS = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_TANI = null; } else {
      this.RDT_TANI = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_TRANSFER_FLAG = null; } else {
      this.RDT_TRANSFER_FLAG = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_ITEM_ASSES_CODE_NUM = null; } else {
      this.RDT_ITEM_ASSES_CODE_NUM = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_MRCH_SIC_CODE = null; } else {
      this.RDT_MRCH_SIC_CODE = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_TRANSACTION_DATE = null; } else {
      this.RDT_TRANSACTION_DATE = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_BATCH_TYPE = null; } else {
      this.RDT_DCX_BATCH_TYPE = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_JULIAN_DATE = null; } else {
      this.RDT_DCX_JULIAN_DATE = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_DCX_TYPE = null; } else {
      this.RDT_DCX_TYPE = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_DCX_SYS_4 = null; } else {
      this.RDT_DCX_SYS_4 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_DCX_SYS_2 = null; } else {
      this.RDT_DCX_SYS_2 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_DCX_DATE = null; } else {
      this.RDT_DCX_DATE = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_DCX_2 = null; } else {
      this.RDT_DCX_2 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RDT_DCX_LAST_6 = null; } else {
      this.RDT_DCX_LAST_6 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_ADJ_SALE_FEE_AM = null; } else {
      this.RDT_DCX_ADJ_SALE_FEE_AM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.FILLER_2 = null; } else {
      this.FILLER_2 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_MON_TRAN_JOURNAL_AMT = null; } else {
      this.RDT_DCX_MON_TRAN_JOURNAL_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_AUDIT_TRAIL_DATE = null; } else {
      this.RDT_DCX_AUDIT_TRAIL_DATE = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_PRIN_TOTAL = null; } else {
      this.RDT_DCX_PRIN_TOTAL = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_PRIN_CASH = null; } else {
      this.RDT_DCX_PRIN_CASH = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_PRIN_MRCH = null; } else {
      this.RDT_DCX_PRIN_MRCH = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_STMT_FIN_CHG_OFF = null; } else {
      this.RDT_DCX_STMT_FIN_CHG_OFF = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_MTJ_FIN_CHG_OFF = null; } else {
      this.RDT_DCX_MTJ_FIN_CHG_OFF = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_BAL_TRAN_DUAL_FLAG = null; } else {
      this.RDT_DCX_BAL_TRAN_DUAL_FLAG = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_PRIN_MISC_CHGS = null; } else {
      this.RDT_DCX_PRIN_MISC_CHGS = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_CR_LIFE_CHG_OFF = null; } else {
      this.RDT_DCX_CR_LIFE_CHG_OFF = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_ACCRUED_CASHINT = null; } else {
      this.RDT_DCX_ACCRUED_CASHINT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_ACCRUED_MRCHINT = null; } else {
      this.RDT_DCX_ACCRUED_MRCHINT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_BALANCE_CHG_OFF = null; } else {
      this.RDT_DCX_BALANCE_CHG_OFF = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_OLD_OPEN_BALANCE = null; } else {
      this.RDT_DCX_OLD_OPEN_BALANCE = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_ACCRUED_CRDINT = null; } else {
      this.RDT_DCX_ACCRUED_CRDINT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.FILLER_3 = null; } else {
      this.FILLER_3 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RDT_DCX_ADDL = null; } else {
      this.RDT_DCX_ADDL = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.FILLER_3A = null; } else {
      this.FILLER_3A = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.FILLER_4 = null; } else {
      this.FILLER_4 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DTE_TME_ROW_ADDED = null; } else {
      this.DTE_TME_ROW_ADDED = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD o = (RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD) super.clone();
    o.DTE_TME_ROW_ADDED = (o.DTE_TME_ROW_ADDED != null) ? (java.sql.Timestamp) o.DTE_TME_ROW_ADDED.clone() : null;
    return o;
  }

  public void clone0(RDX_STG_FDR_CLI_MNY_TRN_DCX_RCRD o) throws CloneNotSupportedException {
    o.DTE_TME_ROW_ADDED = (o.DTE_TME_ROW_ADDED != null) ? (java.sql.Timestamp) o.DTE_TME_ROW_ADDED.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("RDT_MONETARY_DCX_SEQ_NBR", this.RDT_MONETARY_DCX_SEQ_NBR);
    __sqoop$field_map.put("RDT_REC_CODE_KEY", this.RDT_REC_CODE_KEY);
    __sqoop$field_map.put("RDT_REC_TYPE_CONTROL", this.RDT_REC_TYPE_CONTROL);
    __sqoop$field_map.put("RDT_NO_POST_REASON", this.RDT_NO_POST_REASON);
    __sqoop$field_map.put("RDT_SC_1", this.RDT_SC_1);
    __sqoop$field_map.put("RDT_SC_2", this.RDT_SC_2);
    __sqoop$field_map.put("RDT_SC_3", this.RDT_SC_3);
    __sqoop$field_map.put("RDT_SC_4", this.RDT_SC_4);
    __sqoop$field_map.put("RDT_SC_5", this.RDT_SC_5);
    __sqoop$field_map.put("RDT_SC_6", this.RDT_SC_6);
    __sqoop$field_map.put("RDT_SC_7", this.RDT_SC_7);
    __sqoop$field_map.put("RDT_SC_8", this.RDT_SC_8);
    __sqoop$field_map.put("RDT_CHD_SYSTEM_NO", this.RDT_CHD_SYSTEM_NO);
    __sqoop$field_map.put("RDT_CHD_PRIN_BANK", this.RDT_CHD_PRIN_BANK);
    __sqoop$field_map.put("RDT_CHD_AGENT_BANK", this.RDT_CHD_AGENT_BANK);
    __sqoop$field_map.put("RDT_CHD_ACCOUNT_NUMBER", this.RDT_CHD_ACCOUNT_NUMBER);
    __sqoop$field_map.put("RDT_TRANSACTION_CODE", this.RDT_TRANSACTION_CODE);
    __sqoop$field_map.put("RDT_MRCH_SYSTEM_NO", this.RDT_MRCH_SYSTEM_NO);
    __sqoop$field_map.put("RDT_MRCH_PRIN_BANK", this.RDT_MRCH_PRIN_BANK);
    __sqoop$field_map.put("RDT_MRCH_AGENT_NO", this.RDT_MRCH_AGENT_NO);
    __sqoop$field_map.put("RDT_MRCH_ACCOUNT_NUMBER", this.RDT_MRCH_ACCOUNT_NUMBER);
    __sqoop$field_map.put("RDT_CHD_EXT_STATUS", this.RDT_CHD_EXT_STATUS);
    __sqoop$field_map.put("RDT_CHD_INT_STATUS", this.RDT_CHD_INT_STATUS);
    __sqoop$field_map.put("RDT_TANI", this.RDT_TANI);
    __sqoop$field_map.put("RDT_TRANSFER_FLAG", this.RDT_TRANSFER_FLAG);
    __sqoop$field_map.put("RDT_ITEM_ASSES_CODE_NUM", this.RDT_ITEM_ASSES_CODE_NUM);
    __sqoop$field_map.put("RDT_MRCH_SIC_CODE", this.RDT_MRCH_SIC_CODE);
    __sqoop$field_map.put("RDT_TRANSACTION_DATE", this.RDT_TRANSACTION_DATE);
    __sqoop$field_map.put("RDT_DCX_BATCH_TYPE", this.RDT_DCX_BATCH_TYPE);
    __sqoop$field_map.put("RDT_DCX_JULIAN_DATE", this.RDT_DCX_JULIAN_DATE);
    __sqoop$field_map.put("RDT_DCX_TYPE", this.RDT_DCX_TYPE);
    __sqoop$field_map.put("RDT_DCX_SYS_4", this.RDT_DCX_SYS_4);
    __sqoop$field_map.put("RDT_DCX_SYS_2", this.RDT_DCX_SYS_2);
    __sqoop$field_map.put("RDT_DCX_DATE", this.RDT_DCX_DATE);
    __sqoop$field_map.put("RDT_DCX_2", this.RDT_DCX_2);
    __sqoop$field_map.put("RDT_DCX_LAST_6", this.RDT_DCX_LAST_6);
    __sqoop$field_map.put("RDT_DCX_ADJ_SALE_FEE_AM", this.RDT_DCX_ADJ_SALE_FEE_AM);
    __sqoop$field_map.put("FILLER_2", this.FILLER_2);
    __sqoop$field_map.put("RDT_DCX_MON_TRAN_JOURNAL_AMT", this.RDT_DCX_MON_TRAN_JOURNAL_AMT);
    __sqoop$field_map.put("RDT_DCX_AUDIT_TRAIL_DATE", this.RDT_DCX_AUDIT_TRAIL_DATE);
    __sqoop$field_map.put("RDT_DCX_PRIN_TOTAL", this.RDT_DCX_PRIN_TOTAL);
    __sqoop$field_map.put("RDT_DCX_PRIN_CASH", this.RDT_DCX_PRIN_CASH);
    __sqoop$field_map.put("RDT_DCX_PRIN_MRCH", this.RDT_DCX_PRIN_MRCH);
    __sqoop$field_map.put("RDT_DCX_STMT_FIN_CHG_OFF", this.RDT_DCX_STMT_FIN_CHG_OFF);
    __sqoop$field_map.put("RDT_DCX_MTJ_FIN_CHG_OFF", this.RDT_DCX_MTJ_FIN_CHG_OFF);
    __sqoop$field_map.put("RDT_DCX_BAL_TRAN_DUAL_FLAG", this.RDT_DCX_BAL_TRAN_DUAL_FLAG);
    __sqoop$field_map.put("RDT_DCX_PRIN_MISC_CHGS", this.RDT_DCX_PRIN_MISC_CHGS);
    __sqoop$field_map.put("RDT_DCX_CR_LIFE_CHG_OFF", this.RDT_DCX_CR_LIFE_CHG_OFF);
    __sqoop$field_map.put("RDT_DCX_ACCRUED_CASHINT", this.RDT_DCX_ACCRUED_CASHINT);
    __sqoop$field_map.put("RDT_DCX_ACCRUED_MRCHINT", this.RDT_DCX_ACCRUED_MRCHINT);
    __sqoop$field_map.put("RDT_DCX_BALANCE_CHG_OFF", this.RDT_DCX_BALANCE_CHG_OFF);
    __sqoop$field_map.put("RDT_DCX_OLD_OPEN_BALANCE", this.RDT_DCX_OLD_OPEN_BALANCE);
    __sqoop$field_map.put("RDT_DCX_ACCRUED_CRDINT", this.RDT_DCX_ACCRUED_CRDINT);
    __sqoop$field_map.put("FILLER_3", this.FILLER_3);
    __sqoop$field_map.put("RDT_DCX_ADDL", this.RDT_DCX_ADDL);
    __sqoop$field_map.put("FILLER_3A", this.FILLER_3A);
    __sqoop$field_map.put("FILLER_4", this.FILLER_4);
    __sqoop$field_map.put("DTE_TME_ROW_ADDED", this.DTE_TME_ROW_ADDED);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("RDT_MONETARY_DCX_SEQ_NBR", this.RDT_MONETARY_DCX_SEQ_NBR);
    __sqoop$field_map.put("RDT_REC_CODE_KEY", this.RDT_REC_CODE_KEY);
    __sqoop$field_map.put("RDT_REC_TYPE_CONTROL", this.RDT_REC_TYPE_CONTROL);
    __sqoop$field_map.put("RDT_NO_POST_REASON", this.RDT_NO_POST_REASON);
    __sqoop$field_map.put("RDT_SC_1", this.RDT_SC_1);
    __sqoop$field_map.put("RDT_SC_2", this.RDT_SC_2);
    __sqoop$field_map.put("RDT_SC_3", this.RDT_SC_3);
    __sqoop$field_map.put("RDT_SC_4", this.RDT_SC_4);
    __sqoop$field_map.put("RDT_SC_5", this.RDT_SC_5);
    __sqoop$field_map.put("RDT_SC_6", this.RDT_SC_6);
    __sqoop$field_map.put("RDT_SC_7", this.RDT_SC_7);
    __sqoop$field_map.put("RDT_SC_8", this.RDT_SC_8);
    __sqoop$field_map.put("RDT_CHD_SYSTEM_NO", this.RDT_CHD_SYSTEM_NO);
    __sqoop$field_map.put("RDT_CHD_PRIN_BANK", this.RDT_CHD_PRIN_BANK);
    __sqoop$field_map.put("RDT_CHD_AGENT_BANK", this.RDT_CHD_AGENT_BANK);
    __sqoop$field_map.put("RDT_CHD_ACCOUNT_NUMBER", this.RDT_CHD_ACCOUNT_NUMBER);
    __sqoop$field_map.put("RDT_TRANSACTION_CODE", this.RDT_TRANSACTION_CODE);
    __sqoop$field_map.put("RDT_MRCH_SYSTEM_NO", this.RDT_MRCH_SYSTEM_NO);
    __sqoop$field_map.put("RDT_MRCH_PRIN_BANK", this.RDT_MRCH_PRIN_BANK);
    __sqoop$field_map.put("RDT_MRCH_AGENT_NO", this.RDT_MRCH_AGENT_NO);
    __sqoop$field_map.put("RDT_MRCH_ACCOUNT_NUMBER", this.RDT_MRCH_ACCOUNT_NUMBER);
    __sqoop$field_map.put("RDT_CHD_EXT_STATUS", this.RDT_CHD_EXT_STATUS);
    __sqoop$field_map.put("RDT_CHD_INT_STATUS", this.RDT_CHD_INT_STATUS);
    __sqoop$field_map.put("RDT_TANI", this.RDT_TANI);
    __sqoop$field_map.put("RDT_TRANSFER_FLAG", this.RDT_TRANSFER_FLAG);
    __sqoop$field_map.put("RDT_ITEM_ASSES_CODE_NUM", this.RDT_ITEM_ASSES_CODE_NUM);
    __sqoop$field_map.put("RDT_MRCH_SIC_CODE", this.RDT_MRCH_SIC_CODE);
    __sqoop$field_map.put("RDT_TRANSACTION_DATE", this.RDT_TRANSACTION_DATE);
    __sqoop$field_map.put("RDT_DCX_BATCH_TYPE", this.RDT_DCX_BATCH_TYPE);
    __sqoop$field_map.put("RDT_DCX_JULIAN_DATE", this.RDT_DCX_JULIAN_DATE);
    __sqoop$field_map.put("RDT_DCX_TYPE", this.RDT_DCX_TYPE);
    __sqoop$field_map.put("RDT_DCX_SYS_4", this.RDT_DCX_SYS_4);
    __sqoop$field_map.put("RDT_DCX_SYS_2", this.RDT_DCX_SYS_2);
    __sqoop$field_map.put("RDT_DCX_DATE", this.RDT_DCX_DATE);
    __sqoop$field_map.put("RDT_DCX_2", this.RDT_DCX_2);
    __sqoop$field_map.put("RDT_DCX_LAST_6", this.RDT_DCX_LAST_6);
    __sqoop$field_map.put("RDT_DCX_ADJ_SALE_FEE_AM", this.RDT_DCX_ADJ_SALE_FEE_AM);
    __sqoop$field_map.put("FILLER_2", this.FILLER_2);
    __sqoop$field_map.put("RDT_DCX_MON_TRAN_JOURNAL_AMT", this.RDT_DCX_MON_TRAN_JOURNAL_AMT);
    __sqoop$field_map.put("RDT_DCX_AUDIT_TRAIL_DATE", this.RDT_DCX_AUDIT_TRAIL_DATE);
    __sqoop$field_map.put("RDT_DCX_PRIN_TOTAL", this.RDT_DCX_PRIN_TOTAL);
    __sqoop$field_map.put("RDT_DCX_PRIN_CASH", this.RDT_DCX_PRIN_CASH);
    __sqoop$field_map.put("RDT_DCX_PRIN_MRCH", this.RDT_DCX_PRIN_MRCH);
    __sqoop$field_map.put("RDT_DCX_STMT_FIN_CHG_OFF", this.RDT_DCX_STMT_FIN_CHG_OFF);
    __sqoop$field_map.put("RDT_DCX_MTJ_FIN_CHG_OFF", this.RDT_DCX_MTJ_FIN_CHG_OFF);
    __sqoop$field_map.put("RDT_DCX_BAL_TRAN_DUAL_FLAG", this.RDT_DCX_BAL_TRAN_DUAL_FLAG);
    __sqoop$field_map.put("RDT_DCX_PRIN_MISC_CHGS", this.RDT_DCX_PRIN_MISC_CHGS);
    __sqoop$field_map.put("RDT_DCX_CR_LIFE_CHG_OFF", this.RDT_DCX_CR_LIFE_CHG_OFF);
    __sqoop$field_map.put("RDT_DCX_ACCRUED_CASHINT", this.RDT_DCX_ACCRUED_CASHINT);
    __sqoop$field_map.put("RDT_DCX_ACCRUED_MRCHINT", this.RDT_DCX_ACCRUED_MRCHINT);
    __sqoop$field_map.put("RDT_DCX_BALANCE_CHG_OFF", this.RDT_DCX_BALANCE_CHG_OFF);
    __sqoop$field_map.put("RDT_DCX_OLD_OPEN_BALANCE", this.RDT_DCX_OLD_OPEN_BALANCE);
    __sqoop$field_map.put("RDT_DCX_ACCRUED_CRDINT", this.RDT_DCX_ACCRUED_CRDINT);
    __sqoop$field_map.put("FILLER_3", this.FILLER_3);
    __sqoop$field_map.put("RDT_DCX_ADDL", this.RDT_DCX_ADDL);
    __sqoop$field_map.put("FILLER_3A", this.FILLER_3A);
    __sqoop$field_map.put("FILLER_4", this.FILLER_4);
    __sqoop$field_map.put("DTE_TME_ROW_ADDED", this.DTE_TME_ROW_ADDED);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}

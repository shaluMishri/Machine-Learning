#!/bin/sh

if [  $# -eq 0  ] ; then
	
start_date="$(date -u +"%Y-%m-%d")T05:00Z"
end_date="$(date  -u +"%Y-%m-%d"T05:00Z --date="next year")"

logfile="log/load_EIR_"$(date -u +"%Y-%m-%d")_*".log"


elif [ $# -eq 1 ] ; then


start_date=$1"T05:00Z"
end_date="$(date -u +"%Y-%m-%d"T05:00Z --date=$1"+next year")"
logfile="log/load_EIR_"$1_*".log"


else

start_date=$1"T05:00Z"
	if [ "$2" = "*" ] ; then
end_date="$(date -u +"%Y-%m-%d"T05:00Z --date=$1"+next year")"
logfile="log/load_EIR_"$1_*".log"

	else

end_date="$(date  -u +"%Y-%m-%d"T05:00Z --date=$1"+"$2" days")"
logfile="log/load_EIR_"$1_$2".log"

	fi
	


fi



current_time="$(date)"
echo "------Initializing load of EIR Table ------------------ " >> $logfile
echo "current_time="$current_time >> $logfile
echo "start_date="$start_date >> $logfile
echo "end_date="$end_date >> $logfile


rm -f oozie/coord.properties
cp oozie/coord.properties_template oozie/coord.properties
echo "" >> oozie/coord.properties
echo "start_date="$start_date >> oozie/coord.properties
echo "end_date="$end_date >> oozie/coord.properties

oozie job -oozie http://qbda1node04.suntrust.com:11000/oozie -config oozie/coord.properties  -run -verbose  >> $logfile

#!/bin/sh
<<COMMENT
Created by - Nikunj Patel
Created date - 05/02/2017
Created Version - 1.0

Script Parameters :


$1	       - HDFS Data Directory
$2		  - Today ( in YYYYMMDD format)



Description : 

This script saves delete_casenbr_count ,pre_delete_full_count, post_delete_full_count from temp location to count directory

COMMENT


hadoop fs -mkdir -p $1/Count/hive/$2>/dev/null


hadoop fs -rm $1/Count/hive/$2/post_delete_full_count_hive.txt>/dev/null
hadoop fs -rm $1/Count/hive/$2/delete_count_hive.txt>/dev/null
hadoop fs -rm $1/Count/hive/$2/delete_casenbr_count_hive.txt>/dev/null
hadoop fs -rm $1/Count/hive/$2/pre_delete_full_count_hive.txt>/dev/null



hadoop fs -cp  /tmp/delete_count_hive/* $1/Count/hive/$2/delete_count_hive.txt>/dev/null
hadoop fs -cp  /tmp/delete_casenbr_count_hive/* $1/Count/hive/$2/delete_casenbr_count_hive.txt>/dev/null
hadoop fs -cp  /tmp/pre_delete_full_count_hive/* $1/Count/hive/$2/pre_delete_full_count_hive.txt>/dev/null
hadoop fs -cp  /tmp/post_delete_full_count_hive/* $1/Count/hive/$2/post_delete_full_count_hive.txt>/dev/null



DeleteRecordCount=`hadoop fs -text $1/Count/hive/$2/delete_count_hive.txt | grep -Po "\d+" | tail -1`
DeleteCase_NbrCount=`hadoop fs -text $1/Count/hive/$2/delete_casenbr_count_hive.txt | grep -Po "\d+" | tail -1`
Pre_DeleteHiveCount=`hadoop fs -text $1/Count/hive/$2/pre_delete_full_count_hive.txt | grep -Po "\d+" | tail -1`
Post_DeleteHiveCount=`hadoop fs -text $1/Count/hive/$2/post_delete_full_count_hive.txt | grep -Po "\d+" | tail -1`


echo  "DeleteCase_NbrCount="$DeleteCase_NbrCount
echo "DeleteRecordCount="$DeleteRecordCount
echo "Pre_DeleteHiveCount="$Pre_DeleteHiveCount
echo "Post_DeleteHiveCount="$Post_DeleteHiveCount

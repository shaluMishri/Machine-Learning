#!/bin/sh
<<COMMENT
Created by - Nikunj Patel
Created date - 05/01/2017
Created Version - 1.0

Script Parameters :

$1         - Source Database table Name
$2	       - HDFS data Directory
$3         - Today in (YYYYMMDD format)
$4          -load_max_days_limit_enabled ? (1/0}
$5         - load_max_days_limit


Description : 

This script  generates sqoop count for specific day load.
COMMENT

echoerr() { echo "$@" 1>&2; }
max_creat_ts=$(hadoop fs -text  /tmp/max_creat_ts_eir_hive/*  | grep -Po "\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(.\d{1,6})?" | tail -1)

tmp_date=$(date -d "$max_creat_ts")

if  [   $4 -eq 1  ] ; then 
end_date=$(date +%Y-%m-%d -d "$tmp_date + $5 day")
else 
end_date=$(date +%Y-%m-%d -d "$tmp_date + 365 day")
fi

query_criteria=" creat_ts between trunc_timestamp('$max_creat_ts','SS') + 1 second and '$end_date' "
echo "query_criteria"=$query_criteria
echo "max_creat_ts="$max_creat_ts

rm /tmp/count_sqoop.txt
out=`sqoop  job -exec EIR_EVAL  -- --query "select count(1) from $1 where $query_criteria with ur"` || {  echoerr 'Sqoop Eval command Failed' ; exit 1; } 
count=`echo $out | grep -Po "\d+" | tail -1`

echo $count > /tmp/count_sqoop.txt
echo "sqoop_count="$count

hadoop fs -put  /tmp/count_sqoop.txt  $2/Count/sqoop/$3/count_sqoop.txt>/dev/null

if [ $? -ne 0 ] ; then 
echoerr "msg_1=failed to save sqoop Count" 
exit 1;
else 
echo "msg_1=sqoop count saved for month"
fi

#if  [   $count -eq 0  ] ; then 
#echoerr 'Sqoop Eval command - Zero records to fetch ...Failing workflow !!!' 
#exit 1; 
#fi

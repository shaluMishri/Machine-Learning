#!/bin/sh
<<COMMENT
Created by - Nikunj Patel
Created date - 20/03/2017
Created Version - 1.0

Script Parameters :

$1	       - Archive enabled ? ( 1 or 0)
$2          - Archive directory 
$3          - Sqoop target directory 
$4         - Today in (YYYYMMDD format)



Description : 

This script move current loaded sqoop data to archive directory if archive is enabled.  

COMMENT

echoerr() { echo "$@" 1>&2; }

if  [   $1 -eq 1  ] ; then
 
hadoop fs -cp $3 $2/$4

if [ $? -ne 0 ]; then echoerr "msg_1=Failed to archive data "; exit 1;else echo  "msg_1=Data archived "; fi 

else 

echo "Archive disabled . No operation performed"

fi
#!/bin/sh
<<COMMENT
Created by - Nikunj Patel
Created date - 05/01/2017
Created Version - 1.0

Script Parameters :

$1	       - HDFS data Directory
$2         - Today in (YYYYMMDD format)



Description : 

This script  checks if data is already loaded for same date earlier on not , If yes. Returned code from script is '1' (failure of data loading)

COMMENT

echoerr() { echo "$@" 1>&2; }

hadoop fs -mkdir -p $1/Count/sqoop/$2>/dev/null

if [ $? -ne 0 ]; then 
echoerr "msg_1=Failed to create Sqoop count directory"
exit 1;
else 
echo  "msg_1=Sqoop count directory created "
fi


hadoop fs -mkdir -p $1/Count/hive/$2>/dev/null
if [ $? -ne 0 ]; then echoerr "msg_2=Failed to create Hive count directory"; exit 1;else echo  "msg_2=Hive count directory created "; fi

hadoop fs -test -e $1/Count/sqoop/$2/count_sqoop.txt>/dev/null 

if [ $? -eq 0 ]; then 
echoerr " Load Job For , Load day = $2 Executed already earlier..Failing Job now"
exit 1; 
fi







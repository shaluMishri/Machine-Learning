#!/bin/sh
<<COMMENT
Created by - Nikunj Patel
Created date - 05/01/2017
Created Version - 1.0

Script Parameters :
$1	        - HDFS data Directory 
$2	        - Date (in YYYYMMDD format)

Description : 

This script  validates hive count against  sqoop count for specific day load, and echo counts and validation status.

COMMENT

echoerr() { echo "$@" 1>&2; }



hadoop fs -cp /tmp/count_hive/* $1/Count/hive/$2/count_hive.txt>/dev/null
if [ $? -ne 0 ]; then echoerr "msg_2=Failed to store Hive count "; exit 1;else echo "msg_2=Hive count saved "; fi


hive_count=`hadoop fs -text $1/Count/hive/$2/count_hive.txt  | grep -Po "\d+" | tail -1`
sqoop_count=`hadoop fs -text $1/Count/sqoop/$2/count_sqoop.txt  | grep -Po "\d+" | tail -1`

validation="Fail"
if  [ $hive_count  ==  $sqoop_count ]; then
validation="Success"
fi

echo "HiveCount="$hive_count
echo "SqoopCount="$sqoop_count
echo "validation="$validation
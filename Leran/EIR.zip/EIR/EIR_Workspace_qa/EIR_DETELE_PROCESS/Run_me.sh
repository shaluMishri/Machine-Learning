#!/bin/sh
if [  $# -eq 0  ] ; then
	
start_date="$(date -u +"%Y-%m-%d")T05:00Z"
end_date="$(date  -u +"%Y-%m-%d"T05:00Z --date="next day")"

logfile="log/load_EIR_Delete_"$(date -u +"%Y-%m-%d")".log"


else


start_date=$1"T05:00Z"
end_date="$(date -u +"%Y-%m-%d"T05:00Z --date=$1"+next day")"
logfile="log/load_EIR_Delete_"$1".log"



fi



current_time="$(date)"
echo "------Initializing Delete of EIR Table ------------------ " >> $logfile
echo "current_time="$current_time >> $logfile
echo "start_date="$start_date >> $logfile
echo "end_date="$end_date >> $logfile


rm -f oozie/coord.properties
cp oozie/coord.properties_template oozie/coord.properties
echo "" >> oozie/coord.properties
echo "start_date="$start_date >> oozie/coord.properties
echo "end_date="$end_date >> oozie/coord.properties

oozie job -oozie http://qbda1node04.suntrust.com:11000/oozie -config oozie/coord.properties  -run  >> $logfile

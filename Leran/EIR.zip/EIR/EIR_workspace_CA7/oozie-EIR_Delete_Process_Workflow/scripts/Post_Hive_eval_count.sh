#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54, uinp18
Created date - 09/08/2017
Created Version - 1.0

Script Parameters:

$1   - HDFS Data Directory

Description: 

This script saves delete_casenbr_count, pre_delete_full_count, post_delete_full_count from temp location to count directory

COMMENT


DeleteRecordCount=`hadoop fs -text $1/Hive_Count/delete_count_hive/000000_0 | grep -Po "\d+" | tail -1`
DeleteCase_NbrCount=`hadoop fs -text $1/Hive_Count/delete_casenbr_count_hive/000000_0 | grep -Po "\d+" | tail -1`
Pre_DeleteHiveCount=`hadoop fs -text $1/Hive_Count/pre_delete_full_count_hive/000000_0 | grep -Po "\d+" | tail -1`
Post_DeleteHiveCount=`hadoop fs -text $1/Hive_Count/post_delete_full_count_hive/000000_0 | grep -Po "\d+" | tail -1`

echo "DeleteCase_NbrCount="$DeleteCase_NbrCount
echo "DeleteRecordCount="$DeleteRecordCount
echo "Pre_DeleteHiveCount="$Pre_DeleteHiveCount
echo "Post_DeleteHiveCount="$Post_DeleteHiveCount

#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54, uinp18
Created date - 09/08/2017
Created Version - 1.0

Script Parameters:

$1       - Archive enabled? (1 or 0)
$2       - Archive directory 
$3       - Sqoop target directory 

Description: 

This script move current loaded sqoop data to archive directory if archive flag is enabled.  

COMMENT


echoerr() { echo "$@" 1>&2; }

if [ $1 -eq 1 ] ; then
 
hadoop fs -cp $3 $2

if [ $? -ne 0 ]; then echoerr "msg_1=Failed to archive data"; exit 1; else echo "msg_1=Data archived"; fi 

else echo "Archive disabled, so no operation performed"; fi

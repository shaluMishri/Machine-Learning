#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54, uinp18
Created date - 09/08/2017
Created Version - 1.0

Script Parameters:

$1       - HDFS data Directory

Description: 

This script checks if data is already loaded for the same date.
If yes, returned code from script is '1' (failure of data loading).

COMMENT


echoerr() { echo "$@" 1>&2; }

hadoop fs -mkdir -p $1/Count/sqoop>/dev/null

if [ $? -ne 0 ]; then echoerr "msg_1=Failed to create sqoop count directory"; exit 1; else echo "msg_1=Sqoop count directory created"; fi

hadoop fs -mkdir -p $1/Count/hive>/dev/null

if [ $? -ne 0 ]; then echoerr "msg_2=Failed to create hive count directory"; exit 1; else echo "msg_2=Hive count directory created"; fi

hadoop fs -test -e $1/Count/sqoop/count_sqoop.txt>/dev/null 

if  [ $? -ne 0 ]; then echo "msg_1=New load"

else echo "msg_1=Load job already executed earlier..Taking count backup of the same"
     HHMM=$(date +'%H%M')
     hadoop fs -mv $1/Count/sqoop/count_sqoop.txt $1/Count/sqoop/count_sqoop_bkp_$HHMM.txt>/dev/null
     if [ $? -ne 0 ] ; then echoerr "msg_2=Failed to Backup old sqoop count"; exit 1; fi
fi

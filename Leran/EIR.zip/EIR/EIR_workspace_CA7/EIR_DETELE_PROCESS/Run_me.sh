#!/bin/sh

logfile="/zone2/ae/marketing/eir/EIR_workspace_CA7/EIR_DETELE_PROCESS/log/load_EIR.log"

current_time="$(date)"
echo " ------------------ Initializing load of EIR Table ------------------ " >> $logfile
echo "current_time="$current_time >> $logfile

oozie job -oozie http://qbda1node04.suntrust.com:11000/oozie -config /zone2/ae/marketing/eir/EIR_workspace_CA7/EIR_DETELE_PROCESS/oozie/job.properties -run -verbose >> $logfile

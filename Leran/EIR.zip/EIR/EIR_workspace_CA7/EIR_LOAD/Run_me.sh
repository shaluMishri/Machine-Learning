#!/bin/sh

oozie_url="http://qbda1node04.suntrust.com:11000/oozie"
job_properties="/zone2/ae/marketing/eir/EIR_workspace_CA7/EIR_LOAD/oozie/job.properties"
current_time="$(date)"
echo " ------------------ Initializing load of EIR Table ------------------ "
echo "current_time="$current_time

oozie_workflow_id=$(oozie job -oozie ${oozie_url} -config ${job_properties} -run | sed -n 's/job: \(.*\)/\1/p'); 

while ( oozie job -oozie ${oozie_url} -info ${oozie_workflow_id} | grep RUNNING > /dev/null )
do
  sleep 5
  echo "running"
done

while ( oozie job -oozie ${oozie_url} -info ${oozie_workflow_id} | grep FAILED > /dev/null )
do
  echo "Failed with exit 42"
  exit 42
done

while ( oozie job -oozie ${oozie_url} -info ${oozie_workflow_id} | grep KILLED > /dev/null )
do
  echo "Failed with exit 42"
  exit 42
done 

#from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
#from sklearn.svm import SVC
from math import floor
from random import sample
#import pandas as pd
import sys
import numpy as np
import time
import pickle as pk
from pyspark.sql import *
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
from pyspark.sql import Row
from pyspark.sql.types import DataType,FloatType,StringType
from pyspark.sql.functions import *
from pyspark.sql.functions import size
from pyspark.sql import functions as F
from pyspark.sql.functions import col
from pyspark.ml.feature import CountVectorizer, IDF

def f(x): print(x)

# gets list of strings from column colname in dataframe df
def get_text(colname,df):

    #changes made
    #select the column exaple 'one' return- list
    rdd = df.select(colname).flatMap(lambda x:[xs.append(u'') if (isinstance(xs,FloatType)) else xs.replace("\n","").replace("\r","").lower() for xs in x ])
    return rdd
  

# appends strings across row from given columns colnames in dataframe df
def get_multitext(df,*colnames):
 count = 1 
    for colname in colnames:
        colstrings = get_text(colname,df) 
        if count == 0:
            zippedStringsRDD = colstrings.zip(zippedStringsRDD) 
            zippedStringsRDD = zippedStringsRDD.flatMap(lambda x:['*'.join(x)])
        else:
            zippedStringsRDD = colstrings
            count = 0
    print "zippedStringsRDD ------->"
    print zippedStringsRDD.collect()
    return zippedStringsRDD


# gets tuple of strings, dummy blank labels, and complaint ids for analysis from dataframe df
def get_unlabeled_tuple_for_prediction(df):
    stringsList = get_multitext(df,'Client Feedback','Resolution Comments','Analysis Comments')
    blankLabels = []
    for i in stringsList.count():
        blankLabels.append('')
    ids = df.select('Case Number')
    tupleList = stringsList.zip(blankLabels)
    tupleList = [x for x in tupleList if x[0] != '']
    print tupleList.collect()
    return tupleList

# general SVM classifier object, still using linear kernel
# tied for lead in accuracy and allows for confidence (0 through 1) output
def general_svm_classifier(CV,tfidfTransformer,fitTfidf,model,testList):
    # breaks tuples apart
    testText = [x[0] for x in testList]
    testLabels = [x[1] for x in testList]
    testIds = [x[2] for x in testList]
    
    correct = 0
    incorrect = 0
    incCount = 0
    exCount = 0
    predList = []

    # predicts using classifier
    for i in range(len(testText)):
        text = testText[i]
        correctLabel = testLabels[i]
        CVTransform = CV.transform([text])
        tfidfLoop = tfidfTransformer.transform(CVTransform)
        pred = generalSVCClassifier.predict_proba(tfidfLoop)[0][0]

        predList.append(pred)
        if pred > 0.5:
            pred = 'include'
        else:
            pred = 'exclude'
        
        if pred == 'include':
            incCount += 1
        elif pred == 'exclude':
            exCount += 1
        if pred == correctLabel:
            correct += 1
        else:
            incorrect += 1

    print('include: ',incCount)
    print('exclude: ',exCount)
    print('')
    return predList
sc = SparkContext()
sqlContext = SQLContext(sc)


# imports data
# df is a dataframe containing the unlabeled testing/evaluation data
# inModel is pickle file containing 4 objects from the ANAModelGenerator.py program
# the objects are CV (a CountVectorizer object), tfidfTransformer, fitTfidf, and generalSVCClassifier (the classifier itself)

inModelName = sys.argv[1]
inSpreadsheetName = "./ANA/"+sys.argv[2]
outName = sys.argv[3]
print inSpreadsheetName 
rdd =sc.textFile(inSpreadsheetName).map(lambda line:line.split("^"))
df = sqlContext.createDataFrame(rdd,['Case Number','Client Feedback','Resolution Comments','Analysis Comments'])
df.show()

inModel = open(inModelName,'rb')
CV = pk.load(inModel)
tfidfTransformer = pk.load(inModel)
fitTfidf = pk.load(inModel)
generalSVCClassifier = pk.load(inModel)
inModel.close()

# sets threshold parameters
eightTop = 0.8
eightBottom = 0.3
fiftysevenTop = 1
fiftysevenBottom = 0.4
sampleRate = 0.1

# gets data from dataframe for prediction
newTuple = get_unlabeled_tuple_for_prediction(df)

# predicts new data from model imported from pickle file
predictionOutList = general_svm_classifier(CV,tfidfTransformer,fitTfidf,generalSVCClassifier,newTuple)

#colString = get_text("one",d)
#col1String=get_multitext(d,"one","two","three")

#adds the output column to the dataframe df
df.set_index('Case Number', inplace=True)
df.insert(3,'Prediction',np.nan)

#adds prediction data to dataframe df
caseNumbers = [x[2] for x in newTuple]
for i in range(len(caseNumbers)):
    df.set_value(str(caseNumbers[i]), 'Prediction', predictionOutList[i])
 inserts review label
df.insert(4,'Review',review_complaint(df,eightTop,eightBottom,fiftysevenTop,fiftysevenBottom,sampleRate))

# writes predictions for data to excel spreadsheet
if outName[-5:] != '.csv':
    outName = outName + '.csv'
 outDict = {'Case Number': [x[2] for x in newTuple], 'Predicted ANA': predictionOutList}
 pdOut = pd.DataFrame(outDict)
 pdOut.to_excel(outName, index=False)
df.to_excel(outName)
df.to_csv(outName, sep='^', encoding='utf-8')


# import statements

# Import SparkSession
from pyspark.sql import *
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
from pyspark.sql import Row
from pyspark.sql.types import *

#conf = SparkConf().setAppName("Sample-App")
#sc = SparkContext(conf=conf)
#sqlContext = SQLContext(sc)
#df=sc.textFile('/user/a8gg7/test_wc.dat') 
#count=df.flatMap(lambda x: x.split(" ")).map(lambda x:(x,1)).reduceByKey(lambda a,b:a+b) 
#for i in count.collect(): 
 #print i 
#for i in df.collect(): 
 # print i 


def get_text(colname,df):
    stringsList = []
    columnList = list(df[colname])
    for i in range(len(columnList)):
        if type(columnList[i]) != float:
            text = columnList[i]
            stringsList.append(text.lower().replace('\n','').replace('\r',''))    
        else:
            stringsList.append(u'')
    return stringsList


conf = SparkConf().setAppName("Sample-App")
sc = SparkContext(conf=conf)
sqlContext = SQLContext(sc)
d_txt=sc.textFile('hdfs://QA-ns/user/uism172/ANA/Book2.txt')
# Construct fields with names from the header, for creating a DataFrame
header = d_txt.first()
fields = [StructField(field_name, StringType(), True)
      for field_name in header.split(',')]
fields[2].dataType = IntegerType()    
fields[3].dataType = IntegerType()    
schema = StructType(fields)

# Build the DataFrame
d_txt = d_txt.filter(lambda line: line != header) # Remove header from the txt file
temp_var = d_txt.map(lambda k: k.split(","))
df=temp_var.toDF(header.split(","))
df.show()
colstrings = get_text(df.column,df)
colstrings.show()

from pyspark.sql.functions import udf
from pyspark.sql.types import IntegerType,StringType
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
sc = SparkContext()
sqlContext = SQLContext(sc)
df = sc.parallelize([("SHALU", 2), ("mishra", 0)]).toDF(["col1", "col2"])
df.show()
replace_udf = udf(lambda x, y : s.replace(y,"else"), StringType())
max_udf = udf(lambda x, y: max(x + 1, y + 1), IntegerType())
lower_udf = udf(lambda x : x.lower(), StringType())
#df2 = df.withColumn("result", max_udf(df.col1, df.col2))
df2 = df.withColumn("result", lower_udf(df.col1))
df2 = df.withColumn("result_", replace_udf(df.col1))
df2.show()




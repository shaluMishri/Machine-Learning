
import com.databricks.spark.avro._
import org.apache.spark.sql.SQLContext




val sqlContext = new SQLContext(sc)

var df_obln = sqlContext.read.option("header", "true").option("delimiter", "|").option("inferSchema","true").avro("hdfs:///ai/raw/ln/monthly/obln_monthly/ln.obln_monthly.000000.20171227085253.snappy.avro")
var df_oblg = sqlContext.read.option("header", "true").option("delimiter", "|").option("inferSchema","true").avro("hdfs:///ai/raw/ln/monthly/oblg_monthly/ln.oblg_monthly.000000.20171227085253.snappy.avro")
var df_appl = sqlContext.read.option("header", "true").option("delimiter", "|").option("inferSchema","true").avro("hdfs:///ai/raw/ln/monthly/appl_monthly/ln.appl_monthly.000000.20171227085253.snappy.avro")
val df_newObln = df_obln.withColumn("new_obg_no",df_obln("obg_no").cast(StringType))
val df_newObgn = df_oblg.withColumn("new_obg_no",df_oblg("obg_no").cast(StringType))
val df_newAppl = df_appl.withColumn("new_obg_no",df_appl("obg_no").cast(StringType))

var df_join1 = df_newObln.join(df_newObgn,"new_obg_no")




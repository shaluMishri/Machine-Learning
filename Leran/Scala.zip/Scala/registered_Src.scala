import com.databricks.spark.avro._
import org.apache.spark.sql.SQLContext




val sqlContext = new SQLContext(sc)

var df_obln = sqlContext.read.option("header", "true").option("delimiter", "|").option("inferSchema","true").load("hdfs:///ai/data/aitc5/hdfs/rcm/rcm_com/main/m_cdp_stg_compass_obln.dat/000000.dat.gz")
var df_oblg = sqlContext.read.option("header", "true").option("delimiter", "|").option("inferSchema","true").avro("hdfs:///ai/data/aitc5/hdfs/rcm/rcm_com/main/m_cdp_stg_compass_oblg.dat/000000.dat.gz")
var df_appl = sqlContext.read.option("header", "true").option("delimiter", "|").option("inferSchema","true").avro("hdfs:///ai/data/aitc5/hdfs/rcm/rcm_com/main/m_cdp_stg_compass_appl.dat/000000.dat.gz")
val df_newObln = df_obln.withColumn("new_obg_no",df_obln("obg_no").cast(StringType))
val df_newObgn = df_oblg.withColumn("new_obg_no",df_oblg("obg_no").cast(StringType))
val df_newAppl = df_appl.withColumn("new_obg_no",df_appl("obg_no").cast(StringType))

var df_join1 = df_newObln.join(df_newObgn,"new_obg_no")




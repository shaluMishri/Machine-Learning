//

df_t_obln_comp = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/t_obln_comp_monthly/ln.t_obln_comp_monthly.000000.20171227085253.snappy.avro")
df_obln_part_data = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/obln_part_data_monthly/ln.obln_part_data_monthly.000000.20171227085253.snappy.avro")
df_obln_trbldbt_data = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/obln_trbldbt_data_monthly/ln.obln_trbldbt_data_monthly.000000.20171227085253.snappy.avro")
df_future = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/future_monthly/ln.future_monthly.000000.20171227085253.snappy.avro")
df_header = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/header_monthly/ln.header_monthly.000000.20171227085253.snappy.avro")
df_obln_user_data = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/obln_user_data_monthly/ln.obln_user_data_monthly.000000.20171227085253.snappy.avro")





df_t_obln_comp_new=df_t_obln_comp.withColumn("new_obg_no",convToInteger(df_t_obln_comp.obg_no))
df_obln_part_data_new = df_obln_part_data.withColumn("new_obg_no",convToInteger( df_obln_part_data.obg_no))
df_obln_trbldbt_data_new = df_obln_trbldbt_data.withColumn("new_obg_no",convToInteger(df_obln_trbldbt_data.obg_no))
df_future_new = df_future.withColumn("new_obg_no",convToInteger( df_future.obg_no))
df_header_new = df_header.withColumn("new_obg_no",convToInteger( df_header.obg_no))
df_obln_user_data_new = df_obln_user_data.withColumn("new_obg_no",convToInteger( df_obln_user_data.obg_no))



df_join1 = df_obln_new.join(df_oblg_new,df_obln_new.new_obg_no == df_oblg_new.new_obg_no,'inner').drop(df_oblg_new['new_obg_no']).join(df_appl_new,df_obln_new.new_obg_no == df_appl_new.new_obg_no,'inner').drop(df_appl_new['new_obg_no'])

df_join2 = df_join1.join(df_t_obln_comp_new,df_obln_new.new_obg_no == df_t_obln_comp_new.new_obg_no,'leftouter')
df_join3 = df_join2.join(df_obln_part_data_new,df_obln_new.new_obg_no == df_obln_part_data_new.new_obg_no,'leftouter')
df_join4 = df_join3.join(df_obln_trbldbt_data_new,df_obln_new.new_obg_no == df_obln_trbldbt_data_new.new_obg_no,'leftouter')
df_join5 = df_join4.join(df_future_new,df_obln_new.new_obg_no == df_future_new.new_obg_no,'leftouter')
df_join6 = df_join5.join(df_header_new,df_obln_new.new_obg_no ==  df_header_new.new_obg_no,'leftouter')
df_join7 = df_join6.join(df_obln_user_data_new,df_obln_new.new_obg_no ==  df_obln_user_data_new.new_obg_no,'leftouter')
df_join1.show(1)

df_obln.select(convToInteger(df_obln.obg_no).alias("obg_no"),convToInteger(df_obln.pur_cd).alias("pur_cd"),convToInteger(df_obln.obl_no).alias("obl_no"),convToInteger(df_obln.tkd_obg).alias("tkd_obg"),convToInteger(df_obln.tkd_obl).alias("tkd_obl"),convToInteger(df_obln.renwl_to_obl_no).alias("renwl_to_obl_no"),convToInteger(df_obln.renwl_prev_obl_no).alias("renwl_prev_obl_no"))

#df_obln = df_obln.select(*[trim(col(item[0])).alias(item[0]) for item in df_obln.dtypes if item[1]==('string')])

df_obln = df_obln.select(*[convToInteger(col(item[0])).alias(item[0]) for item in df_obln.dtypes if (item[1]=='binary') ])
df_oblg = df_oblg.select(*[convToInteger(col(item[0])).alias(item[0]) for item in df_oblg.dtypes if (item[1]=='binary') ])
df_appl = df_appl.select(*[convToInteger(col(item[0])).alias(item[0]) for item in df_appl.dtypes if (item[1]=='binary') ])

//Passing dataframe to function
A=[df1,df2]
for i in range(0,len(A)):
    A[i] = your_func(A[i])

//Replace binary columns
l=[item[0] for  item in df_obln.dtypes if item[1] == 'binary' and item[0] not in ['risk_weight','mat_tol_amt']]
for i in l:
 i
 f = df_obln.withColumn(i,convToInteger(col(i)))
 f.show(1)

df_obln = df_obln.replace(".","",["new_obg_no","obl_no","tkd_obl","tkd_obg","renwl_prev_obl_no","renwl_to_obl_no"])

//replace
def replaceString(dfList,columList):
 DataFrameList=[]
 for df in dfList:
   df = df.replace(".","",columList)
   DataFrameList.append(df)
   print DataFrameList

replaceString(dfList,columList)

def trimColumns(df):
 for c in df.columns:
  trim(col(c)).alias(c)

// get dataType of colum

for i in df_obln.schema.fields:
 if ("ArrayType" in str(i.dataType)):
  i.name

x.replace(".","",[columList]) for x in df for df in dfList
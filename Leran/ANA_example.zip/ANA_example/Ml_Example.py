#https://stackoverflow.com/questions/35205865/what-is-the-difference-between-hashingtf-and-countvectorizer-in-spark
from pyspark.ml.feature import HashingTF, IDF, Tokenizer
from pyspark.ml.feature import CountVectorizer
import pickle as pk
from pyspark.sql import *
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
from pyspark.sql import Row
from pyspark.sql.types import DataType,ArrayType,FloatType,StringType
from pyspark.sql.functions import *
from pyspark.sql.functions import size
from pyspark.sql import functions as F
from pyspark.sql.functions import col 
from pyspark.mllib.classification import  SVMModel,SVMWithSGD
from pyspark.mllib.regression import LabeledPoint


sc = SparkContext()
spark = SQLContext(sc)
sentenceData = spark.createDataFrame([
    (1, "Hi I heard about Spark"),
    (2, "I wish Java could use case classes"),
    (3, "Logistic regression models are neat")],
 ["label", "sentence"])

tokenizer = Tokenizer(inputCol="sentence", outputCol="words")
wordsData = tokenizer.transform(sentenceData)

hashingTF = HashingTF(inputCol="words", outputCol="Features", numFeatures=100)
hashingTF_model = hashingTF.transform(wordsData)
print "Out of hashingTF function"
hashingTF_model.select('words',col('Features').alias('Features(vocab_size,[index],[tf])')).show(truncate=False)
hashingTF_model.show(truncate=False)


# fit a CountVectorizerModel from the corpus.
cv = CountVectorizer(inputCol="words", outputCol="Features", vocabSize=20)
cv_model = cv.fit(wordsData)
cv_result = cv_model.transform(wordsData)
print "Out of CountVectorizer function"
cv_result.select('words',col('Features').alias('Features(vocab_size,[index],[tf])')).show(truncate=False)
print "Vocabulary from CountVectorizerModel is \n" + str(cv_model.vocabulary)


# fit a tf-idf Model
idf = IDF(inputCol="Features", outputCol="features")
rescaledData = idf.fit(cv_result).transform(cv_result)
print "Out of TF-IDF function"
rescaledData.select('words',col('features').alias('features(vocab_size,[index],[tf])')).show(truncate=False)
rescaledData.show(truncate=False)

# Load and parse the data
def parsePoint(line):
    values = [float(x) for x in line.split(' ')]
    return LabeledPoint(values[0], values[1:])

data = sc.textFile("./ANA/sample_svm_data.txt")
parsedData = data.map(parsePoint)
print "Parsed Data"
print parsedData.collect()

training_raw = sc.parallelize([
    {"text": "foo foo foo bar bar protein", "label": 1.0},
    {"text": "foo bar dna for bar", "label": 0.0},
    {"text": "foo bar foo dna foo", "label": 0.0},
    {"text": "bar foo protein foo ", "label": 1.0}])


# Split data into labels and features, transform
# preservesPartitioning is not really required
# since map without partitioner shouldn't trigger repartitiong
labels = training_raw.map(
    lambda doc: doc["label"],  # Standard Python dict access 
    preservesPartitioning=True # This is obsolete.
)

tf = HashingTF(numFeatures=100).transform( ## Use much larger number in practice
    training_raw.map(lambda doc: doc["text"].split()))

idf = IDF().fit(tf)
tfidf = idf.transform(tf)
tfidf.show()
# Combine using zip
training = labels.zip(tfidf).map(lambda x: LabeledPoint(x[0], x[1]))
print "taining \n" + training 
#SVMLinearModel
#svm =SVMWithSGD.train((rescaledData.select(col('features').alias('features([tf])'))),iterations=10)


rd = ([(1, "Hi I heard about Spark".split(" ")),(2, "I wish Java could use case classes".split(" ")),(3, "Logistic regression models are neat".split(" "))])
rdd = sc.parallelize(rd)
df = rdd.toDF(["label", "sentence"])
cv = CountVectorizer(inputCol="sentence", outputCol="features", vocabSize=3, minDF=2.0)
model = cv.fit(df)
result = model.transform(df)
result.show(truncate=False)
idf = IDF(inputCol="features", outputCol="newfeatures")
rescaledData = idf.fit(result).transform(result)
rescaledData.show(truncate=False)

rescaledData.select('newfeatures').map(lambda x:[LabeledPoint(0,xs) for xs in x])
RDD = rescaledData.select('newfeatures').flatMap(lambda xs:[LabeledPoint(0,x) for x in xs])
svm =SVMWithSGD.train(RDD,iterations=10)
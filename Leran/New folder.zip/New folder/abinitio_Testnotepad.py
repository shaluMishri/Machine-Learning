from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
from pyspark.sql.types import IntegerType
import re
import struct
from pyspark.sql.functions import udf




//FuctionConvert Binary To Integer
convToInteger = udf( lambda x: struct.unpack('i',bytes(x))[0], IntegerType())

sc = new SparkContext()
sqlContext = new SQLContext(sc)
df_obln = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load('hdfs:///ai/raw/ln/monthly/obln_monthly/ln.obln_monthly.000000.20171227085253.snappy.avro')
df_oblg = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/oblg_monthly/ln.oblg_monthly.000000.20171227085253.snappy.avro")
df_appl = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/appl_monthly/ln.appl_monthly.000000.20171227085253.snappy.avro")
df_t_obln_comp = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/t_obln_comp_monthly/ln.t_obln_comp_monthly.000000.20171227085253.snappy.avro")
df_obln_part_data = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/obln_part_data_monthly/ln.obln_part_data_monthly.000000.20171227085253.snappy.avro")


df_obln_new = df_obln.withColumn("new_obg_no",convToInteger(df_obln.obg_no))
df_oblg_new = df_oblg.withColumn("new_obg_no",convToInteger(df_oblg.obg_no))
df_appl_new = df_appl.withColumn("new_obg_no",convToInteger(df_appl.obg_no))
df_t_obln_comp_new=df_t_obln_comp.withColumn("new_obg_no",convToInteger(df_t_obln_comp.obg_no))
df_obln_part_data_new = df_obln_part_data.withColumn("new_obg_no",convToInteger( df_obln_part_data.obg_no))


df_join1 = df_obln_new.join(df_oblg_new,df_obln_new.new_obg_no == df_oblg_new.new_obg_no,'inner').drop(df_oblg_new['new_obg_no']).join(df_appl_new,df_obln_new.new_obg_no == df_appl_new.new_obg_no,'inner').drop(df_appl_new['new_obg_no'])
df_join2 = df_join1.join(df_t_obln_comp_new,df_obln_new.new_obg_no == df_t_obln_comp_new.new_obg_no,'leftouter')
df_join3 = df_join2.join(df_obln_part_data_new,df_obln_new.new_obg_no == df_obln_part_data_new.new_obg_no,'leftouter')
 
df_join1.show(1)



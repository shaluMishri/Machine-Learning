from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext,Column
from pyspark.sql.types import IntegerType,StringType,ArrayType
import struct
from pyspark.sql.functions import udf,trim,col,asc

#spark-submit --packages com.databricks:spark-csv_2.11:1.3.0 

sc = SparkContext()
sqlContext = SQLContext(sc)

#FuctionConvert Binary To Integer
convToInteger = udf( lambda x: struct.unpack('i',bytes(x))[0], IntegerType())
#findBinaryCol = udf( lambda df: [item[0] for item in df_obln.dtypes if (item[1]!='binary')],ArrayType(StringType()))

df_obln = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load('hdfs:///ai/raw/ln/monthly/obln_monthly/ln.obln_monthly.000000.20171227085253.snappy.avro')
df_oblg = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/oblg_monthly/ln.oblg_monthly.000000.20171227085253.snappy.avro")
df_appl = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/appl_monthly/ln.appl_monthly.000000.20171227085253.snappy.avro")
#df_t_obln_comp = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/t_obln_comp_monthly/ln.t_obln_comp_monthly.000000.20171227085253.snappy.avro")
#df_obln_part_data = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/obln_part_data_monthly/ln.obln_part_data_monthly.000000.20171227085253.snappy.avro")
#df_obln_trbldbt_data = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/obln_trbldbt_data_monthly/ln.obln_trbldbt_data_monthly.000000.20171227085253.snappy.avro")
#df_future = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/future_monthly/ln.future_monthly.000000.20171227085253.snappy.avro")
#df_header = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/header_monthly/ln.header_monthly.000000.20171227085253.snappy.avro")
#df_obln_user_data = sqlContext.read.format("com.databricks.spark.avro").option("inferSchema","true").load("hdfs:///ai/raw/ln/monthly/obln_user_data_monthly/ln.obln_user_data_monthly.000000.20171227085253.snappy.avro")



#df_obln = df_obln.select(convToInteger(df_obln.obg_no).alias("obg_no"),convToInteger(df_obln.pur_cd).alias("pur_cd"),convToInteger(df_obln.obl_no).alias("obl_no"))

df_obln = df_obln.withColumn("obg_no",convToInteger(df_obln.obg_no))
df_oblg = df_oblg.withColumn("obg_no",convToInteger(df_oblg.obg_no))
df_appl = df_appl.withColumn("obg_no",convToInteger(df_appl.obg_no))

df_obln = df_obln.select(*[trim(col(item[0])).alias(item[0]) for item in df_obln.dtypes if (item[1]!='array<string>' and item[1]!='binary' )  ])
df_oblg = df_oblg.select(*[trim(col(item[0])).alias(item[0]) for item in df_oblg.dtypes if (item[1]!='array<string>' and item[1]!='binary' ) ])
df_appl = df_appl.select(*[trim(col(item[0])).alias(item[0]) for item in df_appl.dtypes if (item[1]!='array<string>' and item[1]!='binary' )  ])
 
df_obln = df_obln.replace(".","",["obg_no","obl_no","tkd_obl","tkd_obg","renwl_prev_obl_no","renwl_to_obl_no"]).sort(asc("obg_no"))
df_oblg = df_oblg.replace(".","","obg_no").sort(asc("obg_no"))
df_appl = df_appl.replace(".","","obg_no").sort(asc("obg_no"))

#df_t_obln_comp = df_t_obln_comp.replace(".","",["obg_no","obl_no"]).sort(asc("obg_no"))
#df_obln_part_data = df_obln_part_data.replace(".","",["new_obg_no","obl_no"])
#df_obln_trbldbt_data = df_obln_trbldbt_data.replace(".","",["new_obg_no","obl_no"])
df_obln.show(1)


#,'df_appl_new.srv
#columList_join1=['df_obln_new.obg_no','df_obln_new.obl_no','df_obln_new.pur_cd','df_obln_new.gl_cd','df_obln_new.dt_outdbt','df_obln_new.proc_tp','df_obln_new.net_book_bal','df_obln_new.tkd_obg','df_obln_new.tkd_obl','df_obln_new.assn','df_obln_new.eff_dt','df_obln_new.mat_dt','df_obln_new.est_mat_dt','df_obln_new.dur_cd','df_obln_new.legal_status','df_obln_new.legal_status_dt','df_obln_new.obl_naics','df_obln_new.exm_cls_1','df_obln_new.exm_cls_dt_1','df_obln_new.renwl_prev_obl_no','df_obln_new.renwl_to_obl_no','df_obln_new.no_tms_ren','df_obln_new.st_cd','df_obln_new.recovery_amt_itd','df_obln_new.obl_pst_dt','df_obln_new.lst_12_mth_avg_bal','df_obln_new.orig_bal','df_obln_new.fed_cd','df_obln_new.dte_nxt_due','df_obln_new.prepay_code','df_obln_new.bk_no','df_obln_new.div','df_obln_new.snc_identifier','df_obln_new.snc_indicator','df_obln_new.short_name','df_obln_new.regu_u_z_ind','df_obln_new.no_mnths_extd','df_obln_new.no_times_ext','df_obln_new.mgn_cd','df_obln_new.ren_pst_dt','df_obln_new.sec_cd','df_obln_new.dt_lst_ren','df_obln_new.pd_days','df_obln_new.obl_col_tp','df_obln_new.col_mgn_pct','df_obln_new.charge_off_amt','df_obln_new.orig_mat_dt','df_obln_new.st_eff_dt','df_obln_new.obl_tp','df_obln_new.cur_bal','df_obln_new.obln_srv','df_obln_new.orig_obl_dt','df_obln_new.pledged_loan_ind','df_obln_new.obl_col_val','df_obln_new.cr_scr','df_obln_new.cusip_number','df_obln_new.interest_reserve','df_obln_new.prepay_penalty_ind','df_oblg_new.obg_tp']
df_join1 = df_obln.alias('df_obln_new').join(df_oblg.alias('df_oblg_new'),df_obln.obg_no == df_oblg.obg_no,'leftouter').select('df_obln_new.*','df_oblg_new.obg_tp').dropDuplicates()
df_join2 = df_join1.alias('df_join1_new').join(df_appl.alias('df_appl_new'),df_obln.obg_no == df_appl.obg_no,'leftouter').select('df_join1_new.*').dropDuplicates()
df_join2.show(1)



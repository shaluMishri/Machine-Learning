from pyspark import SparkConf,SparkContext
from pyspark.sql import SQLContext
from pyspark.sql.functions import sum,regexp_replace
import sys

# Cmd : spark-submit --packages com.databricks:spark-csv_2.11:1.3.0 Transaction.py

sc = SparkContext()
sqlContext = SQLContext(sc)

#Read file
df_transactions =  sqlContext.load(source="csv",path ='hdfs:///user/uism172/Trifacta_Transactions/*transactions.csv',header = True,inferSchema = True )

df_lab_customers = sqlContext.load(source="csv",path='hdfs:///user/uism172/Trifacta_Transactions/lab_customers.csv',header = True,inferSchema = True )

#Transform to find actual price
df_transactions = df_transactions.withColumn('discount',regexp_replace("discount","%","")).replace("","0","discount")
df_transactions = df_transactions.withColumn('actual_price',df_transactions['ticket_price'] * ( df_transactions['ticket_price']-( df_transactions['discount'].cast("decimal") )/100 ))

df_join = df_transactions.alias('df_trans').join(df_lab_customers.alias('df_cust'), "customer_id",'inner').select('df_cust.*','df_trans.actual_price').dropDuplicates()
df = df_join.groupBy('address_state').agg({'actual_price': 'sum'})
df.show()

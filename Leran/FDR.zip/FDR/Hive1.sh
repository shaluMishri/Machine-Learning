beeline << EOF
!connect jdbc:hive2://qbda1node04:10000/eir_sas_shared;principal=hive/qbda1node04.suntrust.com@CORP.SUNTRUST.COM
show tables;
select count(*) from eir_sas_shared.cli_mny_trn_dcx_rcrd_final_parq;
EOF


#!/bin/sh

<<COMMENT

Created by - INFOSYS - 
Created date -
Created Version - 
Script Parameters:
Description: 

COMMENT


filepath=xxxxxxTable Details file
counter_var=0
date=0
email_ids=Mail Id
hcat_metastore_uri=xxxxxx
hcat_metastore_principal=xxxxxx
hive2_jdbc_url=xxxxxx
hive2_server_principal=xxxxxx
hive=xxxxxx
counter=0

#Counter Check

if [ counter<=counter_var ] ; then

while read line;
do 
        
     driver="$(echo "$line"|cut -d, -f1)";
	 jdbc_Connect_String="$(echo "$line"|cut -d, -f2)";
	 username="$(echo "$line" |cut -d, -f3)";
	 password_Alias="$(echo "$line" |cut -d, -f4)"
	 mapper="$(echo "$line" |cut -d, -f5)"  
	 schema_Name="$(echo "$line" |cut -d, -f6)"  
	 source_Table_Name="$(echo "$line"|cut -d, -f7)"   
     target_Directory="$(echo "$line"|cut -d, -f8)"   
     target_Table_Name="$(echo "$line"|cut -d, -f9)"   
	 key="$(echo "$line"|cut -d, -f10)"   
     key_datatype="$(echo "$line"|cut -d, -f11)"   
	 database_name="$(echo "$line"|cut -d, -f12)"   
     fetch_size="$(echo "$line"|cut -d, -f13)"
         

done < ${FILEPATH}

#Staging Text Table
staging_Table_Name={$target_Table_Name}_STAG_TXT
#Max Partition Date available in Target Table
        

    beeline -u "xxxxx" -n xxxx -e 'xxxxx' --outputformat csv2 >max_Date_Partition.csv
	value="$(<max_Date_Partition.csv)"

	
#Increment date field to next date
      
     next_Date=date -d "${max_Date_Partition} 1 month" +%Y-%m-%d
	 
	 
#Sqoop from source to Staging Text Table

    echo "-----IMPORTING TABLE $TABLENAME----------" ;
	
    sqoop import -xxxxxx
	--driver ${driver} \
	--connect ${jdbc_Connect_String} \
	--username ${username} -password-alias ${password_Alias} -m${mapper} \  
	--table ${schema_Name}.${source_Table_Name} -where ${key}=${next_Date} --target-dir ${target_Directory} \ 
	--hive-table ${staging_Table_Name} --as-textfile \ 
	--create-hive-table --map-column-hive ${key}=${key_datatype} \  
	--hive-database ${database_Name} --hive-import --split-by ${key} \ 
	--fetch-size ${fetch_Size} --delete-target-dir
 
    echo "------SUCCESSFULLY IMPORTED $TABLENAME-------" ;	
	
#Compare Source and target Counts
    query_criteria="creat_ts between trunc_timestamp('$max_creat_ts','SS') + 1 second and '$end_date' and src_chnl_cd NOT IN ('CME', 'CMU')"
    echo "query_criteria"=$query_criteria
	
	source_Count= sqoop eval -xxx \
	              --driver ${driver} \
	              --connect ${jdbc_Connect_String} \
	              --username ${username} -password-alias ${password_Alias} \ 
	              --query "select count(*) from ${schema_Name}.${source_Table_Name} where $key=${next_Date}"

    target_Count= sqoop eval -xxxx \ 
	              --driver ${driver} \ 
	              --connect ${jdbc_Connect_String} \
	              --username ${username} -password-alias ${password_Alias} \ 
	              --query "select count(*) from ${schema_Name}.${staging_Table_Name}"
	
	if [ source_Count eq target_Count ];then
	  echo $source_Count > /home/uism172/count_sqoop.txt
	  hadoop fs -put /home/uism172/count_sqoop.txt /user/uism172/count/count_${next_Date}
	  
	  #Sending mail if counts fail and exit
	  mail -s "Counts" ${email_ids} < /home/uism172/count_sqoop.txt
	  
	  exit 1;
	
	else
	  
       #hive insert command to append to final table
	   insert into table ${target_Table_Name} partition ${key} select
       xxxxxx,cast(dte_tme_row_added  as date) as 
       ${key} from ${staging_Table_Name}
	   
	   #Sending end mail and exit
	   echo "This will go into the body of the mail." | mail -s "Hello world" ${email_ids}
	   
	   COUNTER=COUNTER+1
	  
	fi
COMMENT

#fi
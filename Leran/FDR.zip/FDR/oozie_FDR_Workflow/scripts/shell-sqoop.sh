#!/bin/sh


USERNAME=$1
MAPPER=$2
TARGET_DIRECTORY=$3
DATABASE_NAME=$4
FETCH_SIZE=$5
PATH=$6

while read line ; 
do 

	#TABLENAME=`echo "$line" | cut  -f1  -d,`
	#CONDITION=`echo "$line" | cut  -f2  -d,`
	#KEY=`echo "$line" | cut  -f3  -d,`
        #DATATYPE=`echo "$line" | cut  -f4  -d,`
       	
TABLENAME=CLI_MNY_TRN_DCX_RCRD    
 CONDITION="DTE_TME_ROW_ADDED='10/3/2013'"
 KEY=DTE_TME_ROW_ADDED  
DATATYPE=TIMESTAMP
	echo "-----IMPORTING TABLE $TABLENAME----------" ;


echo $TABLENAME , $CONDITION, $KEY, $DATATYPE
sqoop version
eval = `sqoop import -Dhadoop.security.credential.provider.path=jceks://hdfs/user/a8gg7/cme.password.jceks --driver com.ibm.db2.jcc.DB2Driver --connect jdbc:db2://bidb.suntrust.com:50000/dpd01cdw --username $USERNAME -password-alias cme3.password.alias -m$MAPPER  --table RDX_STG_FDR.$TABLENAME -where $CONDITION --target-dir $TARGET_DIRECTORY --hive-table ${TABLENAME}_Corp_txt --as-textfile --create-hive-table --map-column-hive $KEY=$DATATYPE --hive-database $DATABASE_NAME --hive-import --split-by $KEY --fetch-size $FETCH_SIZE --delete-target-dir`
 echo "$eval"

	sqoop eval -Dhadoop.security.credential.provider.path=jceks://hdfs/user/a8gg7/cme.password.jceks --driver com.ibm.db2.jcc.DB2Driver --connect jdbc:db2://bidb.suntrust.com:50000/dpd01cdw --username $USERNAME -password-alias cme3.password.alias -m$MAPPER  --table RDX_STG_FDR.$TABLENAME -where $CONDITION --target-dir $TARGET_DIRECTORY --hive-table ${TABLENAME}_Corp_txt --as-textfile --create-hive-table --map-column-hive $KEY=$DATATYPE --hive-database $DATABASE_NAME --hive-import --split-by $KEY --fetch-size $FETCH_SIZE --delete-target-dir
       
       #sqoop import -Dhadoop.security.credential.provider.path=jceks://hdfs/user/a8gg7/cme.password.jceks --driver com.ibm.db2.jcc.DB2Driver --connect jdbc:db2://bidb-qa.suntrust.com:50000/dqa01cdw --username "a8gg7" -password-alias cme3.password.alias -m90 --table RDX_STG_FDR.CLI_MNY_TRN_DCX_RCRD -where "DTE_TME_ROW_ADDED='10/3/2013'" --target-dir /user/uism172/fdr/ --hive-table FDR_CLI_MNY_TRN_DCX_RCRD_Corp_txt --as-textfile --create-hive-table --map-column-hive DTE_TME_ROW_ADDED=TIMESTAMP --hive-database eir_sas_shared --hive-import --split-by DTE_TME_ROW_ADDED --fetch-size 9000 

       echo "------SUCCESSFULLY IMPORTED $TABLENAME-------" ;
done < $PATH



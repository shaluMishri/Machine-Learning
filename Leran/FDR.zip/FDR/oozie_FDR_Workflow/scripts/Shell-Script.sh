#!/bin/bash

CONNECTION_DRIVER=jdbc:db2://bidb-qa.suntrust.com:50000/dqa01cdw
USERNAME="a8gg7"
MAPPER=90
TARGET_DIRECTORY=/user/uism172/fdr/
DATABASE_NAME=eir_sas_shared
FETCH_SIZE=90000
echo abc
while read line ; 
do 
    echo abc
	TABLENAME=`echo $line | cut  -f1  -d ','`
	CONDITION=`echo $line | cut  -f2  -d ','`
	KEY=`echo $line | cut  -f3  -d ','`
    DATATYPE=`echo $line | cut  -f4  -d ','`
     
    echo $DATATYPE, $KEY
	
	echo "-----IMPORTING TABLE $TABLENAME----------" ;
	echo "sqoop import -Dhadoop.security.credential.provider.path=jceks://hdfs/user/a8gg7/cme.password.jceks --driver com.ibm.db2.jcc.DB2Driver --connect $CONNECTION_DRIVER --username $USERNAME -password-alias cme3.password.alias -m$MAPPER --table RDX_STG_FDR.$TABLENAME -where $CONDITION --target-dir $TARGET_DIRECTORY --delete-target-dir --hive-table $TABLENAME_txt --as-textfile --create-hive-table --hive-database $DATABASE_NAME --hive-import --split-by $KEY --map-column-hive $KEY=$DATATYPE --fetch-size $FETCH_SIZE"
	echo "------SUCCESSFULLY IMPORTED $TABLENAME-------" ;

done < TableDetails.csv

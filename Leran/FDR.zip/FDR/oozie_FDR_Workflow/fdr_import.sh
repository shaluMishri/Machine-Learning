#!/bin/sh

<<COMMENT

Created by - INFOSYS - 
Created date -
Created Version - 

Script Parameters:

Description: 

COMMENT


FILEPATH="/home/uism172/FDR_Sqoop/table_details.csv"
COUNTER_VAR=0
DATE=0
email_ids=Shalu.Mishra@SunTrust.com
hcat_metastore_uri=thrift://qbda1node04.suntrust.com:9083
hcat_metastore_principal=hive/qbda1node04.suntrust.com@CORP.SUNTRUST.COM
hive2_jdbc_url=jdbc:hive2://qbda1node04.suntrust.com:10000/default
hive2_server_principal=hive/qbda1node04.suntrust.com@CORP.SUNTRUST.COM
hive=/user/uism172/FDR/hive-site.xml
logs="/home/uism172/FDR_Sqoop/Logs/"
counter=0
echo hello

#if [ counter<=COUNTER_VAR ] ; then

while read line;
do 
        echo hello2
        driver="$(echo "$line"|cut -d, -f1)";
	 jdbc_Connect_String="$(echo "$line"|cut -d, -f2)";
	 username="$(echo "$line" |cut -d, -f3)";
	 password_Alias="$(echo "$line" |cut -d, -f4)"
	 mapper="$(echo "$line" |cut -d, -f5)"  
	 schema_Name="$(echo "$line" |cut -d, -f6)"  
	 source_Table_Name="$(echo "$line"|cut -d, -f7)"   
        target_Directory="$(echo "$line"|cut -d, -f8)"   
        target_Table_Name="$(echo "$line"|cut -d, -f9)"   
	 key="$(echo "$line"|cut -d, -f10)"   
        key_datatype="$(echo "$line"|cut -d, -f11)"   
	 database_name="$(echo "$line"|cut -d, -f12)"   
        fetch_size="$(echo "$line"|cut -d, -f13)"
         

done < ${FILEPATH}

staging_Table_Name=${source_Table_Name}_STAG_TEST
echo $staging_Table_Name

#Max Partition Date available in Target Table
        
       beeline -u "jdbc:hive2://qbda1node04:10000/eir_sas_shared;principal=hive/qbda1node04.suntrust.com@CORP.SUNTRUST.COM" -n uism172 -e 'select max(DTE_TME_ROW_ADDED) from CLI_MNY_TRN_DCX_RCRD_final_parq' >"./max_partition.csv"
       max_Date_Partition=$(awk '{ print $2 }' max_partition.csv|tail -2 |head -1)
       echo "-------${max_Date_Partition}"
       	
#Increment date field to next date
      
     next_Date=$(date -d "${max_Date_Partition} 1 month" +%Y-%m-%d)

	 
#Sqoop from source to Staging Text Table

    echo "-----IMPORTING TO STAGING TABLE $TABLENAME----------" ;

    value_where_clause=${key}\=\'${next_Date}\'
    value_map_column=${key}\=${key_datatype}
    echo "--------------------${value_where_clause}"
    echo "--------------------${value_map_column}"
    beeline -u "jdbc:hive2://qbda1node04:10000/eir_sas_shared;principal=hive/qbda1node04.suntrust.com@CORP.SUNTRUST.COM" -n uism172 -e "drop table ${database_name}.${staging_Table_Name}" 2>"${logs}/logs.txt"
    sqoop import -Dhadoop.security.credential.provider.path=jceks://hdfs/user/a8gg7/cme.password.jceks --driver ${driver} --connect ${jdbc_Connect_String} --username ${username} -password-alias ${password_Alias} -m${mapper} -table ${schema_Name}.${source_Table_Name} -where ${value_where_clause} --target-dir ${target_Directory} --hive-table ${staging_Table_Name} --as-textfile --create-hive-table --map-column-hive ${value_map_column} --hive-database ${database_name} --hive-import --split-by ${key} --fetch-size ${fetch_size} --delete-target-dir 2>"${logs}sqoop.logs"
 
    echo "------SUCCESSFULLY IMPORTED $TABLENAME-------" ;	
	
#Compare Source and target Counts
     

       query_criteria=${key}\=\'${next_Date}\'
       echo "--------------------${query_criteria}"
	
	sqoop eval -Dhadoop.security.credential.provider.path=jceks://hdfs/user/a8gg7/cme.password.jceks --driver ${driver} --connect ${jdbc_Connect_String} --username ${username} -password-alias ${password_Alias} --query "select count(*) from ${schema_Name}.${source_Table_Name} where ${query_criteria}" >"${logs}source_table_Count.txt"
       beeline -u "jdbc:hive2://qbda1node04:10000/eir_sas_shared;principal=hive/qbda1node04.suntrust.com@CORP.SUNTRUST.COM" -n uism172 -e "select count(*) from ${database_name}.${staging_Table_Name}" >"${logs}staging_table_Count.txt" 
       
       source_Count=$(awk '{print $2}' ${logs}source_table_Count.txt |tail -2|head -1)	
       target_Count=$(awk '{print $2}' ${logs}staging_table_Count.txt |tail -2|head -1)
	echo "------${source_Count}"
       echo "------${target_Count}"

       if [ ${source_Count} == ${target_Count} ];then
	  echo "${source_Count}" > ${logs}count_sqoop.txt
	  #hadoop fs -put ${logs}count_sqoop.txt /user/uism172/FDR_sqoop/count/count_${next_Date}

         #hive insert command to append to final table
	 beeline -u "jdbc:hive2://qbda1node04:10000/eir_sas_shared;principal=hive/qbda1node04.suntrust.com@CORP.SUNTRUST.COM" -n uism172 -e 'insert overwrite table ${target_Table_Name} partition ${key} select RDT_MONETARY_DCX_SEQ_NBR,RDT_REC_CODE_KEY,RDT_REC_TYPE_CONTROL,RDT_NO_POST_REASON,RDT_SC_1,RDT_SC_2,RDT_SC_3,RDT_SC_4,RDT_SC_5,RDT_SC_6,RDT_SC_7,RDT_SC_8,RDT_CHD_SYSTEM_NO,RDT_CHD_PRIN_BANK,RDT_CHD_AGENT_BANK ,RDT_CHD_ACCOUNT_NUMBER,RDT_TRANSACTION_CODE,RDT_MRCH_SYSTEM_NO,RDT_MRCH_PRIN_BANK,RDT_MRCH_AGENT_NO,RDT_MRCH_ACCOUNT_NUMBER,RDT_CHD_EXT_STATUS,RDT_CHD_INT_STATUS,\
RDT_TANI,RDT_TRANSFER_FLAG ,RDT_ITEM_ASSES_CODE_NUM,RDT_MRCH_SIC_CODE,RDT_TRANSACTION_DATE,RDT_DCX_BATCH_TYPE,RDT_DCX_JULIAN_DATE,RDT_DCX_TYPE,RDT_DCX_SYS_4,RDT_DCX_SYS_2,RDT_DCX_DATE ,RDT_DCX_2 ,RDT_DCX_LAST_6,RDT_DCX_ADJ_SALE_FEE_AM ,FILLER_2,RDT_DCX_MON_TRAN_JOURNAL_AMT,RDT_DCX_AUDIT_TRAIL_DATE ,RDT_DCX_PRIN_TOTAL,RDT_DCX_PRIN_CASH,RDT_DCX_PRIN_MRCH,RDT_DCX_STMT_FIN_CHG_OFF,RDT_DCX_MTJ_FIN_CHG_OFF,RDT_DCX_BAL_TRAN_DUAL_FLAG\
,RDT_DCX_PRIN_MISC_CHGS,RDT_DCX_CR_LIFE_CHG_OFF,RDT_DCX_ACCRUED_CASHINT,RDT_DCX_ACCRUED_MRCHINT,RDT_DCX_BALANCE_CHG_OFF,RDT_DCX_OLD_OPEN_BALANCE,RDT_DCX_ACCRUED_CRDINT,FILLER_3,\
RDT_DCX_ADDL,FILLER_3A,FILLER_4,cast(dte_tme_row_added  as date) as ${key} from ${staging_Table_Name}' 2>"${logs}insert_logs.txt"

         #Sending mail if counts fail and exit
	  mail -s "Counts" ${email_ids} < ${logs}count_sqoop.txt
	  
	  exit 1;
	
	else
	      
	   #Sending end mail and exit
	   #echo "This will go into the body of the mail." | mail -s "Hello world" ${email_ids}
	   
	   COUNTER=COUNTER+1
	  
	fi


#fi
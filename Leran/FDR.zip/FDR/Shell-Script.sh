#!/bin/bash

CONNECTION_DRIVER =$1
USERNAME=$2
MAPPER=$3
TARGET_DIRECTORY=$4
DATABASE_NAME=$5
FETCH_SIZE=$6
while read line ; 
do 

	TABLENAME=`echo $line | cut  -f1  -d ','`
	CONDITION=`echo $line | cut  -f2  -d ','`
	KEY=`echo $line | cut  -f3  -d ','`
	
	echo "-----IMPORTING TABLE $TABLENAME---" ;
	sqoop import --connect $CONNECTION_DRIVER --username $USERNAME -P -m$MAPPER 
	--table RDX_STG_FDR.$TABLENAME -where $CONDITION 
	--target-dir $TARGET_DIRECTORY --hive-table $TABLENAME_corp --as-parquetfile 
	--create-hive-table --hive-database $DATABASE_NAME  --split-by $KEY --fetch-size $FETCH_SIZE
	echo "------SUCCESSFULLY IMPORTED $TABLENAME-------" ;
done < $FILE


 <action name="shell-eval" cred="hcat,hive2">
        <shell xmlns="uri:oozie:shell-action:0.1">
            <job-tracker>${jobTracker}</job-tracker>
            <name-node>${nameNode}</name-node>
            <exec>Shell-Script.sh</exec>
            <argument>${connection_driver}</argument>
            <argument>${username}</argument>
            <argument>${number_mapper}</argument>
            <argument>${target_dir}</argument>
            <argument>${hive_database}</argument>
            <argument>${fetch_size}</argument>
            <file>scripts/Shell-Script.sh#Shell-Script.sh</file>
            <file>scripts/file.CSV#file.CSV</file>
              <capture-output/>
        </shell>
        <ok to="email-end"/>
        <error to="email-fail"/>
    </action>
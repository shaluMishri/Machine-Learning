#!/bin/sh


start_date="$(date -u +"%Y-%m-%d")T05:00Z"
end_date="$(date  -u +"%Y-%m-%d"T05:00Z --date="next year")"
logfile="/home/uism172/FDR_Sqoop/FDR_LOAD/log/FDR_"$(date -u +"%Y-%m-%d")_test".log"
oozie_url="http://qbda1node04.suntrust.com:11000/oozie"
job_properties="/home/uism172/FDR_Sqoop/FDR_LOAD/oozie/job.properties"
current_time="$(date)"
echo "------------------------------ " >> $logfile
echo "current_time="$current_time >> $logfile
echo "start_date="$start_date >> $logfile
echo "end_date="$end_date >> $logfile

echo " ------------------ Initializing load of FDR Table ------------------ "
echo "current_time="$current_time

oozie job -oozie ${oozie_url} -config ${job_properties} -run >> $logfile


